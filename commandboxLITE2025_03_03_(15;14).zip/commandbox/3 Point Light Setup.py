#https://www.youtube.com/watch?v=Rcgu_myl8XA
# #① Select Object To be Lightened. ② Run This Command. ③ Press F3 And Type partial keywords of Operator "3 Point Light Setup". ④ Press Enter
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 
import bpy
import mathutils

class LIGHT_OT_SetupOperator(bpy.types.Operator):
    bl_idname = "light.setup_operator"
    bl_label = "3 Point Light Setup"
    bl_description = "Setup 3-point lighting for the selected object"
    bl_options = {'REGISTER', 'UNDO'}

    light_type: bpy.props.EnumProperty(
        name="Light Type",
        description="Choose the type of lights to create",
        items=[
            ('POINT', "Point", "Point Light"),
            ('SPOT', "Spot", "Spot Light"),
            ('AREA', "Area", "Area Light"),
        ],
        default='AREA',
    )

    key_light_color: bpy.props.FloatVectorProperty(
        name="Key Light Color",
        subtype='COLOR',
        default=(1.0, 0.8, 0.6),
        min=0.0, max=1.0,
        description="Color of the Key Light"
    )

    fill_light_color: bpy.props.FloatVectorProperty(
        name="Fill Light Color",
        subtype='COLOR',
        default=(0.6, 0.8, 1.0),
        min=0.0, max=1.0,
        description="Color of the Fill Light"
    )

    back_light_color: bpy.props.FloatVectorProperty(
        name="Back Light Color",
        subtype='COLOR',
        default=(0.8, 0.6, 1.0),
        min=0.0, max=1.0,
        description="Color of the Back Light"
    )

    base_light_intensity: bpy.props.FloatProperty(
        name="Base Light Intensity",
        default=1000.0,
        min=0.0,
        description="Base brightness value for lights"
    )

    key_light_ratio: bpy.props.FloatProperty(
        name="Key Light Ratio",
        default=1.0,
        min=0.0,
        description="Relative brightness of Key Light"
    )

    fill_light_ratio: bpy.props.FloatProperty(
        name="Fill Light Ratio",
        default=0.5,
        min=0.0,
        description="Relative brightness of Fill Light"
    )

    back_light_ratio: bpy.props.FloatProperty(
        name="Back Light Ratio",
        default=0.3,
        min=0.0,
        description="Relative brightness of Back Light"
    )

    distance_factor: bpy.props.FloatProperty(
        name="Distance Factor",
        default=3.0,
        min=1.0,
        description="Factor to multiply object size for light distance"
    )
    
    adapt_intensity: bpy.props.BoolProperty(
        name="Adapt Intensity to Distance",
        default=True,
        description="Automatically adjust light intensity based on distance"
    )

    def execute(self, context):
        # Ensure viewport shading is set to Rendered
        area = next((a for a in context.screen.areas if a.type == 'VIEW_3D'), None)
        if area:
            shading = area.spaces.active.shading
            if shading.type in {'WIREFRAME', 'SOLID'}:
                shading.type = 'RENDERED'

        # Get the active object
        target_obj = context.active_object
        if not target_obj:
            self.report({'WARNING'}, "No active object selected.")
            return {'CANCELLED'}

        # Calculate object dimensions and center
        if target_obj.type == 'MESH':
            # Get object dimensions
            dimensions = target_obj.dimensions
            max_dim = max(dimensions)
            
            # Get object world position
            obj_location = target_obj.matrix_world.translation
            
            # Calculate light distance based on object size
            light_distance = max_dim * self.distance_factor
            
            # Calculate light positions relative to the object
            light_positions = [
                (obj_location.x + light_distance, obj_location.y + light_distance, obj_location.z + light_distance),  # Key Light
                (obj_location.x - light_distance, obj_location.y + light_distance, obj_location.z + light_distance * 0.4),  # Fill Light
                (obj_location.x, obj_location.y - light_distance, obj_location.z + light_distance)  # Back Light
            ]
        else:
            # Fallback for non-mesh objects
            obj_location = target_obj.matrix_world.translation
            light_distance = 5.0  # Default distance
            max_dim = 1.0  # Default size
            
            light_positions = [
                (obj_location.x + light_distance, obj_location.y + light_distance, obj_location.z + light_distance),
                (obj_location.x - light_distance, obj_location.y + light_distance, obj_location.z + light_distance * 0.4),
                (obj_location.x, obj_location.y - light_distance, obj_location.z + light_distance)
            ]

        light_colors = [
            self.key_light_color,
            self.fill_light_color,
            self.back_light_color
        ]
        
        # Calculate light intensities based on distance if enabled
        base_intensity = self.base_light_intensity
        ratios = [self.key_light_ratio, self.fill_light_ratio, self.back_light_ratio]
        
        if self.adapt_intensity:
            # Adjust base intensity by square of distance (inverse square law)
            # We use the distance factor and object size
            intensity_factor = (max_dim * self.distance_factor) ** 2
            base_intensity = self.base_light_intensity * intensity_factor / 100
            
        light_intensities = [
            base_intensity * ratios[0],
            base_intensity * ratios[1],
            base_intensity * ratios[2]
        ]

        light_names = ["Key Light", "Fill Light", "Back Light"]
        
        # Check if the lights already exist and update them
        existing_lights = {obj.name: obj for obj in bpy.data.objects if obj.type == 'LIGHT' and obj.name in light_names}
        
        for i in range(3):
            light_name = light_names[i]
            
            if light_name in existing_lights:
                # Update existing light
                light_obj = existing_lights[light_name]
                light = light_obj.data
                
                # Update light properties
                light.type = self.light_type
                light.energy = light_intensities[i]
                light.color = light_colors[i]
                
                # Update position
                light_obj.location = light_positions[i]
                
                # Check if constraint exists, add if not
                constraint_exists = False
                for constraint in light_obj.constraints:
                    if constraint.type == 'TRACK_TO' and constraint.target == target_obj:
                        constraint_exists = True
                        break
                
                if not constraint_exists:
                    constraint = light_obj.constraints.new(type='TRACK_TO')
                    constraint.target = target_obj
                    constraint.track_axis = 'TRACK_NEGATIVE_Z'
                    constraint.up_axis = 'UP_Y'
            else:
                # Create new light
                light = bpy.data.lights.new(name=light_name, type=self.light_type)
                light.energy = light_intensities[i]
                light.color = light_colors[i]

                light_obj = bpy.data.objects.new(light_name, light)
                context.collection.objects.link(light_obj)
                light_obj.location = light_positions[i]
                light_obj.show_name = True

                constraint = light_obj.constraints.new(type='TRACK_TO')
                constraint.target = target_obj
                constraint.track_axis = 'TRACK_NEGATIVE_Z'
                constraint.up_axis = 'UP_Y'

        self.report({'INFO'}, "3-point lighting setup updated.")
        return {'FINISHED'}

classes = [LIGHT_OT_SetupOperator]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
    bpy.ops.light.setup_operator()