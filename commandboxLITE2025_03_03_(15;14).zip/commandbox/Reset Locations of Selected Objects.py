# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Reset Positions of Selected Objects.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def reset_locations():
    """Reset the transforms (location, rotation, scale) of selected objects."""
    for obj in bpy.context.selected_objects:
        # Sıfırla: Konum
        if hasattr(obj, "location"):
            obj.location = (0.0, 0.0, 0.0)
# Call the function
reset_locations()
