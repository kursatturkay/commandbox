# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Random Grease Pencil Viewport Background Color.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy


colors = [
    (0, 0, 0),          
    (1, 1, 1),          
    (0.5, 0.5, 0.5),    
    (0.529, 0.808, 0.922),  
    (0.0, 0.467, 0.714),  
    (0.710, 0.592, 0.839),  
    (0.961, 0.961, 0.863),  
    (1.0, 0.435, 0.0),      
    (0.173, 0.419, 0.184),  
    (0.0, 0.2, 0.4),        
    (1.0, 0.843, 0.0),      
]

for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':  # Alan 3D Viewport ise
        space = area.spaces.active
        
        if space.shading.type in ['WIREFRAME','SOLID','MATERIAL']:  # Eğer wireframe modundaysa
            print("WIREFRAME MODDA")
            space.shading.background_type = 'VIEWPORT'
            space.shading.use_scene_world = True


            current_index = bpy.context.scene.get("color_index", 0)
            current_color = colors[current_index]
            space.shading.background_color = current_color
            

world = bpy.data.worlds.get("World")

if world and world.node_tree:
    
    bg_node = world.node_tree.nodes.get("Background")
    
    if bg_node:
        current_index = bpy.context.scene.get("color_index", 0)  
        current_color = colors[current_index]
        bg_node.inputs[0].default_value = (current_color[0], current_color[1], current_color[2], 1)
        next_index = (current_index + 1) % len(colors)  
        bpy.context.scene["color_index"] = next_index
        
        textinfo_=f"New GP Background Color: {current_color}"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
    else:
        textinfo_="Background node not found!"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
else:
        textinfo_="World node tree not found!"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
