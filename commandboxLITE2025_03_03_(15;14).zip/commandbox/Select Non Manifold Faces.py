#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Select Non Manifold Faces.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)


import bpy,bmesh


bpy.ops.object.mode_set(mode='OBJECT')


obj = bpy.context.active_object


bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_mode(type='EDGE')
bpy.ops.mesh.select_all()
bpy.ops.mesh.select_non_manifold()

#bpy.ops.object.mode_set(mode='OBJECT')
bmesh.update_edit_mesh(obj.data)

selected_edges = len([e for e in obj.data.edges if e.select])
selected_faces = len([f for f in obj.data.polygons if f.select])

textinfo_=f"non-manifold edges: {selected_edges} |non-manifold  faces:{selected_faces}" 
bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)