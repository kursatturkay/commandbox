# https://www.youtube.com/watch?v=I-dyLUyIKZI
# Select Objects to be group colorized depending vertex count. unselect all and apply to remove colors.
import bpy
import random


selected_objects = bpy.context.selected_objects


if not selected_objects:
    all_mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
    for obj in all_mesh_objects:
        obj.color = (1.0, 1.0, 1.0, 1.0)  
    selected_objects = []


for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active
        if space.shading.type != 'SOLID':
            space.shading.type = 'SOLID'
        space.shading.light = 'STUDIO'

bpy.context.space_data.shading.color_type = 'OBJECT'


if selected_objects:
    vertex_groups = {}
    for obj in selected_objects:
        if obj.type == 'MESH':
            num_verts = len(obj.data.vertices)
            if num_verts not in vertex_groups:
                vertex_groups[num_verts] = []
            vertex_groups[num_verts].append(obj)

    for group in vertex_groups.values():
        random_color = (random.random(), random.random(), random.random(), 1.0)
        for obj in group:
            obj.color = random_color
            obj.show_wire = False
            obj.show_all_edges = False
            obj.show_in_front = False
