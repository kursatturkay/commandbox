#https://www.youtube.com/watch?v=YBoYhN_WEDo
#Toggles Viewport Shadow And Cavity
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def toggle_shading_settings():
    
    for area in bpy.context.window.screen.areas:
        if area.type == 'VIEW_3D':
            shading = area.spaces[0].shading  
            
            shading.show_shadows = not shading.show_shadows
            shading.show_cavity = not shading.show_cavity
            shading.curvature_valley_factor = 1 if shading.curvature_valley_factor != 1 else 0
            shading.curvature_ridge_factor = 2 if shading.curvature_ridge_factor != 2 else 0
            
            if shading.cavity_type == 'BOTH':
                shading.cavity_type = 'WORLD'
            else:
                shading.cavity_type = 'BOTH'

    textinfo_="Shading settings toggled for all 3D View areas."
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

toggle_shading_settings()
