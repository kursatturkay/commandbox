#  https://www.youtube.com/watch?v=61dng-tY0rI
import bpy
import bmesh

import bpy
import bmesh

obj = bpy.context.object

if obj and obj.type == 'MESH':
    
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type="VERT")
    
    bm = bmesh.from_edit_mesh(obj.data)
    
    
    selected_verts = [v for v in bm.verts if v.select]
    for vert in selected_verts:
        new_vert = bm.verts.new(vert.co)  
    
    
    edges_to_delete = [e for e in bm.edges if e.select]
    faces_to_delete = [f for f in bm.faces if f.select]
    verts_to_delete = [v for v in bm.verts if v.select]
    
    
    bmesh.ops.delete(bm, geom=edges_to_delete + faces_to_delete + verts_to_delete, context='VERTS')
    
    bmesh.update_edit_mesh(obj.data)
    bpy.context.view_layer.update()
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select a mesh object", duration=5)
