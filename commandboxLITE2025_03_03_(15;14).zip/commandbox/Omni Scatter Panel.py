 #https://www.youtube.com/watch?v=bjXAJ2e7Q2c
# 
import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import (
    StringProperty, 
    CollectionProperty, 
    FloatProperty,
    FloatVectorProperty,
    BoolProperty,
    PointerProperty
)

class SeparateLoosePartsOperator(bpy.types.Operator):
    bl_idname = "object.separate_loose_parts"
    bl_label = "Separate Loose Parts and Adjust Pivot"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        for obj in selected_objects:
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')  
            bpy.ops.mesh.separate(type='LOOSE')  
            bpy.ops.object.mode_set(mode='OBJECT')

            # Pivotları ayarla
            context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
            obj.select_set(False)
        
        return {'FINISHED'}
    
class ScatterMeshProperty(PropertyGroup):
    mesh: PointerProperty(type=bpy.types.Object, name="")
    density: FloatProperty(name="Density", default=10.0, min=0.0)
    #scale: FloatVectorProperty(name="Scale", default=(0.1, 0.1, 0.1), subtype='XYZ')
    scale: FloatProperty(name="Scale", default=0.1, min=0.1)

    random_rotation: BoolProperty(name="Random Rotation", default=True)

class SCATTER_OT_setup_nodes(Operator):
    bl_idname = "scatter.setup_nodes"
    bl_label = "Setup Scatter Nodes"
    
    def execute(self, context):
        target = context.active_object
        if not target:
            self.report({'ERROR'}, "No active object selected")
            return {'CANCELLED'}
            
        # Create new node group if it doesn't exist
        if "ScatterSystem" not in bpy.data.node_groups:
            node_group = bpy.data.node_groups.new(type='GeometryNodeTree', name="ScatterSystem")
        else:
            node_group = bpy.data.node_groups["ScatterSystem"]
            node_group.nodes.clear()
            node_group.interface.clear()
            
        # Create input/output sockets
        group_input = node_group.interface.new_socket(name="Target Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
        group_output = node_group.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
        
        # Create nodes
        group_in = node_group.nodes.new('NodeGroupInput')
        group_out = node_group.nodes.new('NodeGroupOutput')
        
        # Create a collection instance node
        collection_info = node_group.nodes.new('GeometryNodeJoinGeometry')
        
        # Link input geometry to output directly first
        node_group.links.new(group_in.outputs[0], collection_info.inputs[0])
        
        # Create scatter system for each scatter object
        scattered_geometries = []
        
        for scatter_item in context.scene.scatter_meshes:
            if not scatter_item.mesh:
                continue
                
            # Create Object Info node
            obj_info = node_group.nodes.new('GeometryNodeObjectInfo')
            obj_info.inputs["Object"].default_value = scatter_item.mesh
            obj_info.transform_space = 'ORIGINAL'
            
            # Create nodes for this scatter object
            distribute = node_group.nodes.new('GeometryNodeDistributePointsOnFaces')
            distribute.distribute_method = 'POISSON'
            
            # Create Value node for density
            density = node_group.nodes.new('ShaderNodeValue')
            density.outputs[0].default_value = scatter_item.density
            
            # Create Vector node for scale
            scale_vec = node_group.nodes.new('ShaderNodeCombineXYZ')
            scale_vec.inputs[0].default_value = scatter_item.scale
            scale_vec.inputs[1].default_value = scatter_item.scale
            scale_vec.inputs[2].default_value = scatter_item.scale
            
            # Instance on points node
            instance = node_group.nodes.new('GeometryNodeInstanceOnPoints')
            
            # Link nodes
            # 1. Input geometry to distribute points
            node_group.links.new(group_in.outputs[0], distribute.inputs["Mesh"])
            
            # 2. Link density
            node_group.links.new(density.outputs[0], distribute.inputs["Density Max"])
            
            # 3. Link instance mesh
            node_group.links.new(obj_info.outputs["Geometry"], instance.inputs["Instance"])
            node_group.links.new(distribute.outputs["Points"], instance.inputs["Points"])
            
            # First align to surface normal
            align_rotation = node_group.nodes.new("FunctionNodeAlignRotationToVector")
            align_rotation.name = "Align Rotation to Vector"
            align_rotation.axis = 'Z'
            align_rotation.pivot_axis = 'AUTO'
            align_rotation.inputs[0].default_value = (0.0, 0.0, 0.0)
            align_rotation.inputs[1].default_value = 1.0
            
            # Connect normal to alignment
            node_group.links.new(distribute.outputs[1], align_rotation.inputs[2])
            
            if scatter_item.random_rotation:
                # Get position for noise input
                position = node_group.nodes.new('GeometryNodeInputPosition')
                
                # Create noise texture nodes for each axis
                noise_tex = node_group.nodes.new('ShaderNodeTexNoise')
                noise_tex.inputs["Scale"].default_value = 5.0
                
                # Map noise to rotation range (for Z axis only since we want to keep surface alignment)
                map_range = node_group.nodes.new('ShaderNodeMapRange')
                map_range.inputs['From Min'].default_value = -1.0
                map_range.inputs['From Max'].default_value = 1.0
                map_range.inputs['To Min'].default_value = 0.0
                map_range.inputs['To Max'].default_value = 6.28318  # 2*pi
                
                # Create Combine XYZ for final rotation
                combine_rot = node_group.nodes.new('ShaderNodeCombineXYZ')
                
                # Link position to noise texture
                node_group.links.new(position.outputs[0], noise_tex.inputs["Vector"])
                
                # Link noise to range mapping
                node_group.links.new(noise_tex.outputs["Fac"], map_range.inputs["Value"])
                
                # Get aligned rotation components
                separate_rot = node_group.nodes.new('ShaderNodeSeparateXYZ')
                node_group.links.new(align_rotation.outputs[0], separate_rot.inputs[0])
                
                # Keep X and Y from alignment, only randomize Z
                node_group.links.new(separate_rot.outputs[0], combine_rot.inputs[0])
                node_group.links.new(separate_rot.outputs[1], combine_rot.inputs[1])
                node_group.links.new(map_range.outputs[0], combine_rot.inputs[2])
                
                # Link final rotation to instance
                node_group.links.new(combine_rot.outputs[0], instance.inputs["Rotation"])
            else:
                # Use only aligned rotation when random is disabled
                node_group.links.new(align_rotation.outputs[0], instance.inputs["Rotation"])
            
            # Apply scale
            scale_instances = node_group.nodes.new('GeometryNodeScaleInstances')
            node_group.links.new(instance.outputs[0], scale_instances.inputs["Instances"])
            node_group.links.new(scale_vec.outputs["Vector"], scale_instances.inputs["Scale"])
            
            scattered_geometries.append(scale_instances.outputs[0])
        
        # Connect all scattered geometries to the join node
        for idx, geom in enumerate(scattered_geometries):
            node_group.links.new(geom, collection_info.inputs[-1])
        
        # Realize instances
        realize_instances = node_group.nodes.new("GeometryNodeRealizeInstances")
        realize_instances.name = "Realize Instances"
        realize_instances.inputs[1].default_value = True
        realize_instances.inputs[2].default_value = True
        realize_instances.inputs[3].default_value = 0
        
        # Connect final nodes
        node_group.links.new(collection_info.outputs[0], realize_instances.inputs[0])
        node_group.links.new(realize_instances.outputs[0], group_out.inputs[0])
        
        # Add modifier to target object
        if "Scatter" in target.modifiers:
            mod = target.modifiers["Scatter"]
            mod.node_group = node_group
        else:
            mod = target.modifiers.new(name="Scatter", type='NODES')
            mod.node_group = node_group
        
        return {'FINISHED'}

class SCATTER_OT_apply_nodes(Operator):
    bl_idname = "scatter.apply_nodes"
    bl_label = "Apply Scatter"
    
    def execute(self, context):
        target = context.active_object
        if not target:
            return {'CANCELLED'}
            
        if "Scatter" in target.modifiers:
            bpy.ops.object.modifier_apply(modifier="Scatter")
        
        return {'FINISHED'}

class OBJECT_PT_toggle_omni_scatter_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_omni_scatter_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.omni_scatter_panel_visible = not context.window_manager.omni_scatter_panel_visible

        if(context.window_manager.omni_scatter_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class SCATTER_PT_panel(Panel):
    bl_label = "Omni Scatter"
    bl_idname = "SCATTER_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'
    
    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "omni_scatter_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_omni_scatter_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        target = context.active_object
        has_scatter = target and any(mod for mod in target.modifiers if mod.type == 'NODES' and mod.node_group and mod.node_group.name == "ScatterSystem")

        # Scatter Meshes List
        #layout.label(text="Scatter Meshes:")
        for i, item in enumerate(scene.scatter_meshes):
            box = layout.box()
            
            col=box.column_flow(columns=2)
            #box.label(text=f"Scatter Object {i+1}")
            col.prop(item, "mesh")
            col.prop(item, "random_rotation")

            col=box.column_flow(columns=2)

            col.prop(item, "density")
            #row = box.row(align=True)
            col.prop(item, "scale")
          

        # Add/Remove scatter mesh buttons
        row = layout.row()
        row.operator("scatter.add_mesh", text="📦 Add Mesh")
        row.operator("scatter.remove_mesh", text="🗑️ Remove Mesh")

        layout.separator(type="LINE")

        # Setup Scatter System
        layout.operator("scatter.setup_nodes", text="🍂 Scatter Over The Target")

        layout.separator(type="LINE")

        # ScatterSystem var mı kontrol et
        

        # "Bake Scatter" ve "Separate By Loose Parts" butonlarını bir kutuya koy
        box = layout.box()
        
        # "Bake Scatter" için etkinlik durumu
        box.enabled = has_scatter
        box.operator("scatter.apply_nodes", text="🍞 Bake Scatter")

        box = layout.box()
        # "Separate By Loose Parts" için etkinlik durumu (Bake Scatter'in tersine olacak)
        box.enabled = not has_scatter
        box.operator("object.separate_loose_parts", text="🧩 Seperate By Loose Parts")



class SCATTER_OT_add_mesh(Operator):
    bl_idname = "scatter.add_mesh"
    bl_label = "Add Scatter Mesh"
    
    def execute(self, context):
        item = context.scene.scatter_meshes.add()
        return {'FINISHED'}

class SCATTER_OT_remove_mesh(Operator):
    bl_idname = "scatter.remove_mesh"
    bl_label = "Remove Scatter Mesh"
    
    def execute(self, context):
        if len(context.scene.scatter_meshes) > 0:
            context.scene.scatter_meshes.remove(len(context.scene.scatter_meshes) - 1)
        return {'FINISHED'}

classes = (
    OBJECT_PT_toggle_omni_scatter_panel,
    SeparateLoosePartsOperator,
    ScatterMeshProperty,
    SCATTER_OT_setup_nodes,
    SCATTER_OT_apply_nodes,
    SCATTER_PT_panel,
    SCATTER_OT_add_mesh,
    SCATTER_OT_remove_mesh,
)

def register():
    bpy.types.WindowManager.omni_scatter_panel_visible = bpy.props.BoolProperty(default=False)
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.scatter_meshes = CollectionProperty(type=ScatterMeshProperty)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.scatter_meshes
    del bpy.types.WindowManager.omni_scatter_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_omni_scatter_panel()