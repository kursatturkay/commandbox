#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Statistics.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class ToggleStatisticsOperator(bpy.types.Operator):
    """Toggle 3D View Statistics"""
    bl_idname = "view3d.toggle_statistics"
    bl_label = "Toggle Statistics"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                for space in area.spaces:
                    if space.type == "VIEW_3D":
                        space.overlay.show_stats = not space.overlay.show_stats
                        break
        return {'FINISHED'}


def register():
    bpy.utils.register_class(ToggleStatisticsOperator)

def unregister():
    bpy.utils.unregister_class(ToggleStatisticsOperator)

if __name__ == "__main__":
    register()
    bpy.ops.view3d.toggle_statistics()