#https://www.youtube.com/watch?v=k24l5sPC71E
#Select Similar Objects By Name.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class SelectSimilarObjectsByNameOperator(bpy.types.Operator):
    bl_idname = "object.select_similar_objects_by_name"
    bl_label = "Select Similar Objects By Name"

    def execute(self, context):
        
        selected_objects = bpy.context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "No selected objects.")
            return {'CANCELLED'}

        
        selected_mesh_count = 0
        prefixes = set()

        for obj in selected_objects:
            if obj.type == 'MESH':  
                selected_mesh_count += 1
                name_length_half = len(obj.name) // 2
                prefix = obj.name[:name_length_half]
                prefixes.add(prefix)

                for candidate in bpy.context.scene.objects:
                    if candidate != obj and candidate.type == 'MESH' and candidate.name[:name_length_half] == obj.name[:name_length_half]:
                        candidate.select_set(True)
        
        textinfo_ = f"Selected Mesh Count: {selected_mesh_count}, Prefixes: {', '.join(prefixes)}"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(SelectSimilarObjectsByNameOperator)

def unregister():
    bpy.utils.unregister_class(SelectSimilarObjectsByNameOperator)

if __name__ == "__main__":
    register()

    bpy.ops.object.select_similar_objects_by_name()
