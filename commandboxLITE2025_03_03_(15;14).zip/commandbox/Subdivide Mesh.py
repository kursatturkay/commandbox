#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Subdivide Selected Meshes without going in edit mode.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class ApplySubdivideToSelectedMeshes(bpy.types.Operator):
    bl_idname = "object.apply_subdivide_to_selected"
    bl_label = "Apply Subdivide to Selected Meshes"

    def execute(self, context):
        
        selected_objects = bpy.context.selected_objects

        for obj in selected_objects:
            
            if obj.type == 'MESH':
                
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')
                
                bpy.ops.mesh.select_mode(type='FACE')
                
                bpy.ops.mesh.select_all(action='SELECT')
                
                bpy.ops.mesh.subdivide(number_cuts=1)  
                
                bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}

def register():
    bpy.utils.register_class(ApplySubdivideToSelectedMeshes)

def unregister():
    bpy.utils.unregister_class(ApplySubdivideToSelectedMeshes)

if __name__ == "__main__":
    register()
    bpy.ops.object.apply_subdivide_to_selected()
