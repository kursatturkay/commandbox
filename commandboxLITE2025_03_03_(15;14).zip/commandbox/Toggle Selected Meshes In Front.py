#Toggle Selected Meshes In Front
import bpy

for obj in bpy.context.selected_objects:
    if obj.type == 'MESH':
        obj.show_in_front = not obj.show_in_front
