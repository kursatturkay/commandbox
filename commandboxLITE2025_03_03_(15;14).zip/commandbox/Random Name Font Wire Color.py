# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Random Name Font Wire Color.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

# Renk listesi
colors = [
    (0, 0, 0),          
    (1, 1, 1),          
    (0.5, 0.5, 0.5),    
    (0.529, 0.808, 0.922),  
    (0.0, 0.467, 0.714),  
    (0.710, 0.592, 0.839),  
    (0.961, 0.961, 0.863),  
    (1.0, 0.435, 0.0),      
    (0.173, 0.419, 0.184),  
    (0.0, 0.2, 0.4),        
    (1.0, 0.843, 0.0),      
]

# Temayı al
theme = bpy.context.preferences.themes[0]

# Geçerli renk indeksini al (PlayerPrefs veya benzeri bir sistemle saklanabilir)
current_index = bpy.context.scene.get("current_wire_color_index", 0)

# Yeni renk seç
new_color = colors[current_index]

# Z Wire rengini değiştir
theme.view_3d.wire = new_color
theme.view_3d.light= (*new_color,1)
theme.view_3d.camera=new_color
print(f"Yeni Z Wire rengi: {new_color}")

# Sonraki renk için indeksi güncelle (döngüsel olarak geri sarar)
new_index = (current_index + 1) % len(colors)
bpy.context.scene["current_wire_color_index"] = new_index

print("Z Wire rengi döngüsel olarak değiştirildi!")
