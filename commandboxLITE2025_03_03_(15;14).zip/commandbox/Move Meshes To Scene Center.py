import bpy

def move_selected_to_center():
    for obj in bpy.context.selected_objects:
        
        obj.location.x = 0
        obj.location.y = 0
        obj.location.z = 0


move_selected_to_center()
