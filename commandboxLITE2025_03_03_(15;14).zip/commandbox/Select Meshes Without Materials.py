
import bpy


bpy.ops.object.select_all(action='DESELECT')


for obj in bpy.data.objects:
    if obj.type == 'MESH':  
        if not obj.data.materials:  
            obj.select_set(True)  

bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="All Meshes Without Materials Selected.", duration=5)
