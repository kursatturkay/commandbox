# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Clear Grease Pencil Strokes.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

# Aktif Grease Pencil objesini al
grease_pencil_obj = bpy.context.active_object

# Eğer aktif obje Grease Pencil değilse, işlem yapma
if grease_pencil_obj and grease_pencil_obj.type == 'GREASEPENCIL':
    # Edit Mode'a geç
    bpy.ops.object.mode_set(mode='EDIT')

    # Tüm strokeleri seç
    bpy.ops.grease_pencil.select_all(action='SELECT')

    # Seçilen strokeleri sil
    bpy.ops.grease_pencil.delete()

    # Draw Mode'a geri dön
    bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')

    print("Tüm strokeler silindi ve Draw Mode'a geçildi.")
else:
    print("Aktif obje GREASEPENCIL değil!")
