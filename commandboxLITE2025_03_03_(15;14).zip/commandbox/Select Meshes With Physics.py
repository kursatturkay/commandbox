# 1st or 2nd line for add a youtube url link, and other line as description for Select Meshes With Physics.
#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 

import bpy

# Deselect all objects
bpy.ops.object.select_all(action='DESELECT')

# Loop through all objects in the scene
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        # Check for physics modifiers or rigid body properties
        if obj.rigid_body or any(mod.type in {'COLLISION', 'CLOTH', 'SOFT_BODY', 'FLUID'} for mod in obj.modifiers):
            obj.select_set(True)

# Ensure the selected objects are in the active view layer
bpy.context.view_layer.objects.active = bpy.context.selected_objects[0] if bpy.context.selected_objects else None
