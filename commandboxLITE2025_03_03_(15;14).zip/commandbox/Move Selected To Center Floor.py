#https://www.youtube.com/watch?v=-PZQEes1Aas
# Moves Selected Meshes to Top Of Center Floor
import bpy
import bmesh

def set_origin_to_bottom_vertex_and_place_on_scene_top():
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            # Nesneyi aktif yap
            bpy.context.view_layer.objects.active = obj
            
            # Edit mode'a geç
            bpy.ops.object.mode_set(mode='EDIT')
            
            # BMesh veri yapısını oluştur
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            
            # Vertex'lerin dünya uzayındaki Z koordinatlarını al
            world_coords = [obj.matrix_world @ v.co for v in bm.verts]
            min_z = min(coord.z for coord in world_coords)
            
            # Edit mode'dan çık
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME', center='BOUNDS')
            # Orijini nesnenin en altına taşı
            obj.location = (0, 0, obj.location.z-min_z)
       
            
            # Yeni orijini ayarla
            bpy.context.view_layer.objects.active = obj
            #bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
            
            # Nesneyi sahnenin üstüne yerleştir
            #height = obj.dimensions.z
            #obj.location = (0, 0, 0)

set_origin_to_bottom_vertex_and_place_on_scene_top()
