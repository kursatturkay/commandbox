# https://www.youtube.com/watch?v=fFaVtxX0SdA

import bpy
import random

# CAD uygulamaları için uygun renkler (RGB)
colors = [
    (0.1, 0.1, 0.1),  # Koyu Gri (Maya'nın varsayılan arka planı)
    (0.1, 0.2, 0.3),  # mavimsi
    (0.2, 0.2, 0.2),  # mavimsi
    (0.3, 0.3, 0.3),  # Daha açık gri
    (0.5, 0.5, 0.5),  # Orta gri
    (0.7, 0.7, 0.7),  # Açık gri
    (0.5, 0.7, 1.0)
]

# İlk rengi rastgele seç
base_color_high = random.choice(colors)

# İkinci rengi seçerken, ilk renkten farklı olmasına dikkat et
base_color_gradient = base_color_high
while base_color_gradient == base_color_high:
    base_color_gradient = random.choice(colors)

# Blender Preferences'ı al
prefs = bpy.context.preferences

# Varsayılan tema ayarlarına eriş
theme = prefs.themes[0]  # Genellikle ilk tema varsayılan temadır
view_3d_theme = theme.view_3d  # 3D Viewport teması

# Arka plan türünü "RADIAL" olarak ayarlayın
view_3d_theme.space.gradients.background_type = 'LINEAR'

# Rastgele seçilen renk tonlarını ayarla
view_3d_theme.space.gradients.high_gradient = base_color_high  # Yüksek renk
view_3d_theme.space.gradients.gradient = base_color_gradient     # Gradient rengi

bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Suitable colors have been set for the 3D Viewport gradient background for CAD applications.", duration=5)
