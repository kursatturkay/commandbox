# https://www.youtube.com/watch?t=70&v=WLNkrGUP-Hs
import bpy
import bmesh

# import os
# import sys

# current_dir = os.path.dirname(__file__)

# if current_dir not in sys.path:
#     sys.path.append(current_dir)

# import _modal_draw_operator

# if not hasattr(_modal_draw_operator, 'is_registered') or not _modal_draw_operator.is_registered:
#     _modal_draw_operator.register()
#     _modal_draw_operator.is_registered = True


# Aktif objeyi al
obj = bpy.context.object

if obj and obj.type == 'MESH':
    # Edit moda geç
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')

    # BMesh veri yapısını oluştur
    bm = bmesh.from_edit_mesh(obj.data)

    # Tüm vertex seçimlerini temizle
    for v in bm.verts:
        v.select = False

    # Her vertex için bağlı edge'leri kontrol et
    for v in bm.verts:
        connected_edges = len(v.link_edges)
        if connected_edges in {0, 1, 2}:  # 1 veya 2 edge bağlıysa
            v.select = True

    # BMesh verilerini güncelle
    bmesh.update_edit_mesh(obj.data)

    # Seçimi göstermek için edit modunu yenile
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.mode_set(mode='EDIT')
    
    selected_vertices = [v for v in obj.data.vertices if v.select]
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=f"{len(selected_vertices)} Vertices Selected")


else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="NO Mesh Selected", duration=5)
    
    

    


