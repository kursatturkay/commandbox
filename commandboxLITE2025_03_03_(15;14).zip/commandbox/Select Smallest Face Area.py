# New python \n \n script file: Select Smallest Face Area
import bpy

def select_smallest_face_area():
    obj = bpy.context.object
    if obj and obj.type == 'MESH':
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

        smallest_face = min(obj.data.polygons, key=lambda face: face.area)
        smallest_face.select = True

        bpy.ops.object.mode_set(mode='EDIT')

select_smallest_face_area()

# Aktif 3D Viewport'ta seçilen objeyi görüntüle
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        # Aktif olan VIEW_3D region'ını bul
        for region in area.regions:
            if region.type == 'WINDOW':
                # Geçici context ile view_selected'ı çalıştır
                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
                break

#-------------------------------------------------------------------------
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':  # 3D Viewport alanını bul
        space = area.spaces.active
        if hasattr(space, 'shading'):  # Shading özelliği var mı diye kontrol et
            space.shading.show_xray = True
#return {'FINISHED'}