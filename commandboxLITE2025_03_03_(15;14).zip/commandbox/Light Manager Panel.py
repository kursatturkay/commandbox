#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Light Manager.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
bl_info = {
    "name": "Light Manager",
    "author": "Claude (Updated)",
    "version": (1, 2),
    "blender": (4, 3, 2),
    "location": "View3D > Sidebar > Light Manager",
    "description": "Manage lights in your scene easily",
    "category": "Lighting",
}

import bpy
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import BoolProperty, FloatProperty, FloatVectorProperty, StringProperty, EnumProperty, PointerProperty, CollectionProperty

# Per-Light UI State
class LightUIState(PropertyGroup):
    is_expanded: BoolProperty(
        name="Expanded",
        description="Whether this light's UI is expanded",
        default=True
    )

# Light Settings Property Group
class LightSettings(PropertyGroup):
    edit_name: StringProperty(
        name="Edit Name",
        description="Temporary storage for editing light names",
        default=""
    )
    
    active_light: StringProperty(
        name="Active Light",
        description="Currently selected light for editing",
        default=""
    )

# Operators
class LIGHT_OT_add_light(Operator):
    bl_idname = "light.add_light"
    bl_label = "Add Light"
    bl_description = "Add a new light to the scene"
    bl_options = {'REGISTER', 'UNDO'}
    
    light_type: EnumProperty(
        name="Light Type",
        description="Type of light to add",
        items=[
            ('POINT', "Point", "Omnidirectional point light"),
            ('SUN', "Sun", "Directional light with parallel rays"),
            ('SPOT', "Spot", "Directional cone light"),
            ('AREA', "Area", "Directional area light")
        ],
        default='POINT'
    )
    
    @classmethod
    def description(cls, context, properties):
        if properties.light_type == 'POINT':
            return 'Omnidirectional point light'
        elif properties.light_type == 'SUN':
            return 'Directional light with parallel rays'
        elif properties.light_type == 'SPOT':
            return 'Directional cone light'
        elif properties.light_type == 'AREA':
            return 'Directional area light'      

    def execute(self, context):
        # Add a new light
        bpy.ops.object.light_add(type=self.light_type)
        # Initialize expanded state for the new light
        new_light = context.active_object
        new_light["lm_expanded"] = True
        return {'FINISHED'}

class LIGHT_OT_remove_light(Operator):
    bl_idname = "light.remove_light"
    bl_label = "Remove Light"
    bl_description = "Remove the selected light"
    bl_options = {'REGISTER', 'UNDO'}
    
    light_name: StringProperty(
        name="Light Name",
        description="Name of the light to remove"
    )
    
    def execute(self, context):
        light = bpy.data.objects.get(self.light_name)
        if light:
            bpy.data.objects.remove(light)
        return {'FINISHED'}

class LIGHT_OT_duplicate_light(Operator):
    bl_idname = "light.duplicate_light"
    bl_label = "Duplicate Light"
    bl_description = "Duplicate the selected light"
    bl_options = {'REGISTER', 'UNDO'}
    
    light_name: StringProperty(
        name="Light Name",
        description="Name of the light to duplicate"
    )
    
    def execute(self, context):
        light = bpy.data.objects.get(self.light_name)
        if light:
            # Deselect all objects first
            bpy.ops.object.select_all(action='DESELECT')
            
            # Set the active object and select it
            context.view_layer.objects.active = light
            light.select_set(True)
            
            # Get expanded state of the original light
            is_expanded = light.get("lm_expanded", True)
            
            # Duplicate the light
            bpy.ops.object.duplicate()
            
            # Set expanded state on the new light
            if context.active_object:
                context.active_object["lm_expanded"] = is_expanded
            
            # Move the duplicated light slightly
            bpy.ops.transform.translate('INVOKE_DEFAULT')
        return {'FINISHED'}

class LIGHT_OT_toggle_all(Operator):
    bl_idname = "light.toggle_all"
    bl_label = "Toggle All Lights"
    bl_description = "Toggle visibility of all lights"
    bl_options = {'REGISTER', 'UNDO'}
    
    show: BoolProperty(
        name="Show",
        description="Show or hide all lights",
        default=True
    )
    
    def execute(self, context):
        for obj in bpy.data.objects:
            if obj.type == 'LIGHT':
                obj.hide_viewport = not self.show
                obj.hide_render = not self.show
        return {'FINISHED'}

class LIGHT_OT_toggle_expand_all(Operator):
    bl_idname = "light.toggle_expand_all"
    bl_label = "Toggle Expand All"
    bl_description = "Expand or collapse all light sections"
    bl_options = {'REGISTER', 'UNDO'}
    
    expand: BoolProperty(
        name="Expand",
        description="Expand or collapse all lights",
        default=True
    )
    
    def execute(self, context):
        for obj in bpy.data.objects:
            if obj.type == 'LIGHT':
                # Only set the custom property in execute, not in draw
                obj["lm_expanded"] = self.expand
        return {'FINISHED'}

class LIGHT_OT_toggle_expand(Operator):
    bl_idname = "light.toggle_expand"
    bl_label = "Toggle Expand"
    bl_description = "Expand or collapse this light section"
    bl_options = {'REGISTER', 'UNDO'}
    
    light_name: StringProperty(
        name="Light Name",
        description="Name of the light to toggle"
    )
    
    def execute(self, context):
        light = bpy.data.objects.get(self.light_name)
        if light:
            # Toggle the custom property
            current = light.get("lm_expanded", True)
            light["lm_expanded"] = not current
        return {'FINISHED'}

class LIGHT_OT_start_rename(Operator):
    bl_idname = "light.start_rename"
    bl_label = "Edit Light Name"
    bl_description = "Start editing the light name"
    bl_options = {'REGISTER', 'UNDO'}
    
    light_name: StringProperty(
        name="Light Name",
        description="Name of the light to rename"
    )
    
    def execute(self, context):
        scene = context.scene
        scene.light_settings.active_light = self.light_name
        scene.light_settings.edit_name = self.light_name
        return {'FINISHED'}

class LIGHT_OT_apply_rename(Operator):
    bl_idname = "light.apply_rename"
    bl_label = "Apply Name"
    bl_description = "Apply the new name to the light"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        light = bpy.data.objects.get(scene.light_settings.active_light)
        if light and scene.light_settings.edit_name:
            # Store expanded state before renaming
            is_expanded = light.get("lm_expanded", True)
            
            # Rename the light
            light.name = scene.light_settings.edit_name
            
            # Restore expanded state
            light["lm_expanded"] = is_expanded
            
            scene.light_settings.active_light = ""
        return {'FINISHED'}
        
class LIGHT_OT_cancel_rename(Operator):
    bl_idname = "light.cancel_rename"
    bl_label = "Cancel"
    bl_description = "Cancel renaming"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        scene = context.scene
        scene.light_settings.active_light = ""
        return {'FINISHED'}

# Function to get light type icon
def get_light_type_icon(light_type):
    if light_type == 'POINT':
        return 'LIGHT_POINT'
    elif light_type == 'SUN':
        return 'LIGHT_SUN'
    elif light_type == 'SPOT':
        return 'LIGHT_SPOT'
    elif light_type == 'AREA':
        return 'LIGHT_AREA'
    return 'LIGHT'

# Get property safely (without writing) 
def get_light_expanded(light):
    return light.get("lm_expanded", True)


class OBJECT_PT_toggle_light_manager_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_light_manager_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.light_manager_panel_visible = not context.window_manager.light_manager_panel_visible

        if(context.window_manager.light_manager_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
# GUI Panel
class LIGHT_PT_manager(Panel):
    bl_label = "Light Manager"
    bl_idname = "LIGHT_PT_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "light_manager_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_light_manager_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        light_settings = scene.light_settings
        
        # Add Light Section
        box = layout.box()
        grd=box.grid_flow(align=True,columns=9)
        op = grd.operator("light.add_light", text="", icon='LIGHT_POINT')
        op.light_type = 'POINT'
        op = grd.operator("light.add_light", text="", icon='LIGHT_SUN')
        op.light_type = 'SUN'
        op = grd.operator("light.add_light", text="", icon='LIGHT_SPOT')
        op.light_type = 'SPOT'
        op = grd.operator("light.add_light", text="", icon='LIGHT_AREA')
        op.light_type = 'AREA'
        
        grd.separator()
        grd.operator("light.toggle_expand_all", text="",icon="TRIA_DOWN_BAR").expand = True
        grd.operator("light.toggle_expand_all", text="",icon="TRIA_UP_BAR").expand = False

        grd.operator("light.toggle_all", text="",icon="HIDE_OFF").show = True
        grd.operator("light.toggle_all", text="",icon="HIDE_ON").show = False
        

        
        # Lights List Section
        box = layout.box()
        #box.label(text="Scene Lights")
        
        # List all lights in the scene
        for obj in bpy.data.objects:
            if obj.type == 'LIGHT':
                light = obj.data
                box_light = box.box()
                
                # Get the expanded state safely without trying to write to it
                is_expanded = get_light_expanded(obj)
                
                # Light name (editable or not based on active state)
                is_active = (light_settings.active_light == obj.name)
                
                # Light header row with expand/collapse toggle
                header_row = box_light.row(align=True)
                
                # Add expand/collapse toggle
                expand_icon = 'TRIA_DOWN' if is_expanded else 'TRIA_RIGHT'
                op = header_row.operator("light.toggle_expand", text="", icon=expand_icon, emboss=False)
                op.light_name = obj.name
                
                # Add light type icon
                light_icon = get_light_type_icon(light.type)
                header_row.label(text="", icon=light_icon)
                
                if is_active:
                    # Show editing interface
                    header_row.prop(light_settings, "edit_name", text="")
                    header_row.operator("light.apply_rename", text="", icon='CHECKMARK')
                    header_row.operator("light.cancel_rename", text="", icon='X')
                else:
                    # Show light name with edit button
                    header_row.label(text=obj.name)
                    op = header_row.operator("light.start_rename", text="", icon='GREASEPENCIL')
                    op.light_name = obj.name
                
                # Only show details if expanded
                if is_expanded:
                    # Light visibility toggle
                    row = box_light.row()
                    row.prop(obj, "hide_viewport", text="Viewport", toggle=True, invert_checkbox=True)
                    row.prop(obj, "hide_render", text="Render", toggle=True, invert_checkbox=True)
                    
                    # Light properties - Intensity and Color in a single row
                    prop_row = box_light.row(align=True)
                    # In Blender 4.x energy is called power for some light types
                    if hasattr(light, "energy"):
                        prop_row.prop(light, "energy", text="Intensity")
                    else:
                        prop_row.prop(light, "power", text="Power")
                    
                    prop_row.prop(light, "color", text="")  # Empty text to save space
                    
                    # Type-specific properties
                    if light.type == 'SPOT':
                        spot_row = box_light.row(align=True)
                        if hasattr(light, "spot_size"):
                            spot_row.prop(light, "spot_size", text="Size")
                        else:
                            spot_row.prop(light, "spot_angle", text="Angle")
                        spot_row.prop(light, "spot_blend", text="Blend")
                    elif light.type == 'AREA':
                        box_light.prop(light, "shape", text="Shape")
                        size_row = box_light.row(align=True)
                        if hasattr(light, "size"):
                            size_row.prop(light, "size", text="Size X")
                            if light.shape in {'RECTANGLE', 'ELLIPSE'}:
                                size_row.prop(light, "size_y", text="Y")
                        else:
                            # Handle new naming scheme in Blender 4.x if applicable
                            size_row.prop(light, "width", text="Width")
                            if light.shape in {'RECTANGLE', 'ELLIPSE'}:
                                size_row.prop(light, "height", text="Height")
                    
                    # Add additional Blender 4.x specific settings
                    if light.type in {'POINT', 'SPOT', 'AREA'}:
                        # Add radius property for certain light types if available
                        if hasattr(light, "radius"):
                            box_light.prop(light, "radius", text="Radius")
                    
                    # Add node-based settings if applicable
                    if hasattr(light, "use_nodes") and light.use_nodes:
                        node_row = box_light.row()
                        node_row.label(text="Uses nodes", icon='NODETREE')
                    
                    # Operations for this light
                    row = box_light.row(align=True)
                    op = row.operator("light.duplicate_light", text="Duplicate")
                    op.light_name = obj.name
                    op = row.operator("light.remove_light", text="Remove")
                    op.light_name = obj.name

# Registration
classes = (
    OBJECT_PT_toggle_light_manager_panel,
    LightSettings,
    LightUIState,
    LIGHT_OT_add_light,
    LIGHT_OT_remove_light,
    LIGHT_OT_duplicate_light,
    LIGHT_OT_toggle_all,
    LIGHT_OT_toggle_expand_all,
    LIGHT_OT_toggle_expand,
    LIGHT_OT_start_rename,
    LIGHT_OT_apply_rename,
    LIGHT_OT_cancel_rename,
    LIGHT_PT_manager,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.light_settings = PointerProperty(type=LightSettings)
    
    # Initialize custom properties for existing lights
    for obj in bpy.data.objects:
        if obj.type == 'LIGHT' and "lm_expanded" not in obj:
            obj["lm_expanded"] = True

    bpy.types.WindowManager.light_manager_panel_visible = bpy.props.BoolProperty(default=False)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.light_settings
    del bpy.types.WindowManager.light_manager_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_light_manager_panel()