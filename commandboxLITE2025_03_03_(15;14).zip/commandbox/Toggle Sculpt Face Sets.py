# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Sculpt Face Sets.

import bpy

for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        for space in area.spaces:
            if space.type == 'VIEW_3D':
                try:
                    space.overlay.show_sculpt_face_sets = not space.overlay.show_sculpt_face_sets
                    
                    textinfo_="Toggled Visiblity Of Facesets If Sculpt Mode Draw Face Sets Active."
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                    
                except AttributeError:
                    textinfo_='''The 'show_sculpt_face_sets' property was not found in the Overlay.
                    "This property may have been changed in the Blender API.'''
                    
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        break
