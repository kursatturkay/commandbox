#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Delete All Lights.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class DeleteAllLights(bpy.types.Operator):
    bl_idname = "object.delete_all_lights"
    bl_label = "Delete All Lights"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        lights = [obj for obj in bpy.data.objects if obj.type == 'LIGHT']
        
        light_count = len(lights)
        
        bpy.ops.object.select_all(action='DESELECT')
        for light in lights:
            light.select_set(True)
        
        bpy.ops.object.delete()
        
        textinfo_ = f"{light_count} lights deleted."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        
        return {'FINISHED'}

def register():
    bpy.utils.register_class(DeleteAllLights)

def unregister():
    bpy.utils.unregister_class(DeleteAllLights)

if __name__ == "__main__":
    register()
    bpy.ops.object.delete_all_lights()