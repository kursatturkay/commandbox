#Rename Prefix Armature Bones
import bpy

class RenameBonesPopup(bpy.types.Operator):
    bl_idname = "object.rename_bones_popup"
    bl_label = "Rename Bones"
    
    prefix: bpy.props.StringProperty(name="Prefix", default="Bone_")

    def execute(self, context):
        for obj in bpy.context.selected_objects:
            if obj.type == 'ARMATURE':
                for i, bone in enumerate(obj.data.bones):
                    bone.name = f"{self.prefix}{i + 1}"

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)


def register():
    bpy.utils.register_class(RenameBonesPopup)
    bpy.types.Scene.bone_prefix = bpy.props.StringProperty(name="Prefix", default="Bone_")
    
    bpy.ops.object.rename_bones_popup('INVOKE_DEFAULT')

def unregister():
    bpy.utils.unregister_class(RenameBonesPopup)
    del bpy.types.Scene.bone_prefix


if __name__ == "__main__":
    register()
