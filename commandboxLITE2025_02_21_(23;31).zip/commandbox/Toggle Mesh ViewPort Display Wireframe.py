# https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggles Meshes' ViewPort Display of Color Alpha / Opaque.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def adjust_wireframe_for_selected_meshes():
    selected_objects = bpy.context.selected_objects

    if selected_objects:
        
        for obj in selected_objects:
            if obj.type == 'MESH':
                if obj.display_type in ['SOLID', 'TEXTURED']:
                    obj.show_wire = not obj.show_wire
    else:
        
        all_meshes = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH' and obj.display_type in ['SOLID', 'TEXTURED']]
        
        if all(mesh.show_wire for mesh in all_meshes):  
            for obj in all_meshes:
                obj.show_wire = False
        elif all(not mesh.show_wire for mesh in all_meshes):  
            for obj in all_meshes:
                obj.show_wire = True

adjust_wireframe_for_selected_meshes()
