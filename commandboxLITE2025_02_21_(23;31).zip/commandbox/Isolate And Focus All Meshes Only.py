# Deselects All, Selects and Focuses to Only Objects Type of Meshes 
import bpy

def select_meshes_and_focus():
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.select_set(True)  # Sadece mesh nesnelerini seç
    
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'WINDOW':
                    with bpy.context.temp_override(area=area, region=region):
                        bpy.ops.view3d.view_selected(use_all_regions=False)  # Seçilen mesh nesnelerine odaklan
                    return

for obj in bpy.data.objects:
    obj.hide_set(False)


select_meshes_and_focus()
