#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Unsubdivide Mesh.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_UnsubdivideOperator(bpy.types.Operator):
    """Seçili nesnelere Un-Subdivide uygulayan bir operatör."""
    bl_idname = "object.unsubdivide_operator"
    bl_label = "Apply Un-Subdivide Decimate"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Seçili nesneleri döngüyle işleme al
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                # Decimate modifiye edici ekle
                decimate_mod = obj.modifiers.new(name="Unsubdivide", type='DECIMATE')
                decimate_mod.decimate_type = 'UNSUBDIV'
                decimate_mod.iterations = 2

                # Modifiye ediciyi uygulama
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.modifier_apply(modifier=decimate_mod.name)

        return {'FINISHED'}

# Eklentiyi kaydet ve menüye ekle
def menu_func(self, context):
    self.layout.operator(OBJECT_OT_UnsubdivideOperator.bl_idname)

def register():
    bpy.utils.register_class(OBJECT_OT_UnsubdivideOperator)
    bpy.types.VIEW3D_MT_object.append(menu_func)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_UnsubdivideOperator)
    bpy.types.VIEW3D_MT_object.remove(menu_func)

if __name__ == "__main__":
    register()
    bpy.ops.object.unsubdivide_operator()
