# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Class Lister.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

# _OT_, _MT_, _PT_, _HT_ takılarını içeren tüm sınıfları listelemek için fonksiyon
def get_classes_with_tag(tag):
    return [cls for cls in dir(bpy.types) if tag in cls]

# UIList sınıfı tanımlamak
class ClassItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()

class ClassList(bpy.types.UIList):
    bl_idname = "VIEW3D_UL_class_list"
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_prop):
        self.use_filter_show = True
        layout.label(text=item.name)

class VIEW3D_PT_class_lister(bpy.types.Panel):
    bl_label = "Class Lister"
    bl_idname = "VIEW3D_PT_class_lister"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Command Box"  # Kategori adı değiştirildi

    def draw(self, context):
        layout = self.layout
        
        # Butonları ekleyelim (kullanıcı dostu isimlerle)
        row = layout.row()
        row.operator("view3d.update_ot_classes", text="List Operator Classes (_OT_)")
        row = layout.row()
        row.operator("view3d.update_mt_classes", text="List Menu Classes (_MT_)")
        row = layout.row()
        row.operator("view3d.update_pt_classes", text="List Panel Classes (_PT_)")
        row = layout.row()
        row.operator("view3d.update_ht_classes", text="List Header Classes (_HT_)")

        # UIList için tek bir liste kullanıyoruz
        row = layout.row()
        row.template_list("VIEW3D_UL_class_list", "", context.scene, "class_list", context.scene, "class_index")

# Operator sınıfı, sınıfları almak ve listeyi güncellemek için
class VIEW3D_OT_update_ot_classes(bpy.types.Operator):
    bl_idname = "view3d.update_ot_classes"
    bl_label = "Update _OT_ Classes"
    
    def execute(self, context):
        # _OT_ sınıflarını al
        class_list = get_classes_with_tag("_OT_")

        # Sahnedeki sınıf listesine ekleyelim
        context.scene.class_list.clear()
        for cls in class_list:
            new_item = context.scene.class_list.add()
            new_item.name = cls

        return {'FINISHED'}

class VIEW3D_OT_update_mt_classes(bpy.types.Operator):
    bl_idname = "view3d.update_mt_classes"
    bl_label = "Update _MT_ Classes"
    
    def execute(self, context):
        # _MT_ sınıflarını al
        class_list = get_classes_with_tag("_MT_")

        # Sahnedeki sınıf listesine ekleyelim
        context.scene.class_list.clear()
        for cls in class_list:
            new_item = context.scene.class_list.add()
            new_item.name = cls

        return {'FINISHED'}

class VIEW3D_OT_update_pt_classes(bpy.types.Operator):
    bl_idname = "view3d.update_pt_classes"
    bl_label = "Update _PT_ Classes"
    
    def execute(self, context):
        # _PT_ sınıflarını al
        class_list = get_classes_with_tag("_PT_")

        # Sahnedeki sınıf listesine ekleyelim
        context.scene.class_list.clear()
        for cls in class_list:
            new_item = context.scene.class_list.add()
            new_item.name = cls

        return {'FINISHED'}

class VIEW3D_OT_update_ht_classes(bpy.types.Operator):
    bl_idname = "view3d.update_ht_classes"
    bl_label = "Update _HT_ Classes"
    
    def execute(self, context):
        # _HT_ sınıflarını al
        class_list = get_classes_with_tag("_HT_")

        # Sahnedeki sınıf listesine ekleyelim
        context.scene.class_list.clear()
        for cls in class_list:
            new_item = context.scene.class_list.add()
            new_item.name = cls

        return {'FINISHED'}

# Verileri sahnede tutmak için yeni özellikler eklemek
def register():
    bpy.utils.register_class(ClassItem)  # Yeni veri tipi
    bpy.utils.register_class(ClassList)
    bpy.utils.register_class(VIEW3D_PT_class_lister)
    bpy.utils.register_class(VIEW3D_OT_update_ot_classes)
    bpy.utils.register_class(VIEW3D_OT_update_mt_classes)
    bpy.utils.register_class(VIEW3D_OT_update_pt_classes)
    bpy.utils.register_class(VIEW3D_OT_update_ht_classes)
    
    # Sahnede liste özelliklerini ekleyelim
    bpy.types.Scene.class_list = bpy.props.CollectionProperty(type=ClassItem)  # Veri tipi burada değişiyor
    bpy.types.Scene.class_index = bpy.props.IntProperty()

def unregister():
    bpy.utils.unregister_class(ClassItem)
    bpy.utils.unregister_class(ClassList)
    bpy.utils.unregister_class(VIEW3D_PT_class_lister)
    bpy.utils.unregister_class(VIEW3D_OT_update_ot_classes)
    bpy.utils.unregister_class(VIEW3D_OT_update_mt_classes)
    bpy.utils.unregister_class(VIEW3D_OT_update_pt_classes)
    bpy.utils.unregister_class(VIEW3D_OT_update_ht_classes)

    del bpy.types.Scene.class_list
    del bpy.types.Scene.class_index

# if __name__ == "__main__":
#     register()


def toggle():
    
    if hasattr(bpy.types, "VIEW3D_PT_class_lister"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented  
        bpy.utils.unregister_class(bpy.types.VIEW3D_PT_class_lister)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
        register()

if __name__ == "__main__":
    toggle()
