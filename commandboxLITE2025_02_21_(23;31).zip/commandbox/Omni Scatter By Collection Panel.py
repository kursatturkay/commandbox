#https://www.youtube.com/watch?v=HDsrraU-7gE

import bpy
import random
import math
from mathutils import Vector, Matrix
import bmesh
from mathutils.kdtree import KDTree

class ScatterSettings(bpy.types.PropertyGroup):
    # Temel ayarlar
    target: bpy.props.PointerProperty(
        name="Target Surface",
        type=bpy.types.Object,
        description="Surface to scatter objects on"
    )
    collection: bpy.props.PointerProperty(
        name="Scatter Objects",
        type=bpy.types.Collection,
        description="Collection containing objects to scatter"
    )
    count: bpy.props.IntProperty(
        name="Count",
        description="Number of objects to scatter",
        default=10,
        min=1
    )
    
    # Gelişmiş ayarlar
    min_distance: bpy.props.FloatProperty(
        name="Minimum Distance",
        description="Minimum distance between scattered objects",
        default=0.5,
        min=0.0
    )
    random_rotation_x: bpy.props.BoolProperty(
        name="X",
        description="Enable random rotation on X axis",
        default=False
    )
    random_rotation_y: bpy.props.BoolProperty(
        name="Y",
        description="Enable random rotation on Y axis",
        default=False
    )
    random_rotation_z: bpy.props.BoolProperty(
        name="Z",
        description="Enable random rotation on Z axis",
        default=True
    )
    align_to_normal: bpy.props.BoolProperty(
        name="Align to Normal",
        description="Align objects to surface normal",
        default=True
    )
    scale_random: bpy.props.BoolProperty(
        name="Random Scale",
        description="Enable random scaling",
        default=False
    )
    scale_min: bpy.props.FloatProperty(
        name="Min Scale",
        description="Minimum scale factor",
        default=0.8,
        min=0.01
    )
    scale_max: bpy.props.FloatProperty(
        name="Max Scale",
        description="Maximum scale factor",
        default=1.2,
        min=0.01
    )
    use_vertex_weight: bpy.props.BoolProperty(
        name="Use Vertex Weight",
        description="Use vertex weight to influence distribution",
        default=False
    )
    vertex_group: bpy.props.StringProperty(
        name="Vertex Group",
        description="Vertex group to use for distribution"
    )
    seed: bpy.props.IntProperty(
        name="Seed",
        description="Seed for random generation",
        default=1
    )


class OBJECT_PT_toggle_omni_scatter_by_collection_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_omni_scatter_by_collectio_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.omni_scatter_by_collection_panel_visible = not context.window_manager.omni_scatter_by_collection_panel_visible

        if(context.window_manager.omni_scatter_by_collection_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    

class SCATTER_BY_COLLECION_PT_Panel(bpy.types.Panel):
    bl_label = "Omni Scatter By Collection"
    bl_idname = "SCATTER_BY_COLLECION_PT_Panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "omni_scatter_by_collection_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_omni_scatter_by_collectio_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        settings = context.scene.scatter_settings
        
        # Temel ayarlar
        box = layout.box()
        #box.label(text="Basic Settings:")
        box.prop_search(settings, "target", bpy.data, "objects")
        box.prop_search(settings, "collection", bpy.data, "collections")

        col=box.column_flow(columns=2)
        col.prop(settings, "count")
        col.prop(settings, "seed")
        
        # Mesafe ayarları
        box = layout.box()
        #box.label(text="Distance Settings:")
        box.prop(settings, "min_distance")
        
        # Rotasyon ayarları
        # box = layout.box()
        
        # box.prop(settings, "align_to_normal")

        # box.label(text="Random Rotation Settings:",align='CENTER')
        # col=box.column_flow(columns=3)
        # col.prop(settings, "random_rotation_x")
        # col.prop(settings, "random_rotation_y")
        # col.prop(settings, "random_rotation_z")
        
        box = layout.box()
        row = box.row(align=True)
        row.alignment = 'CENTER'  #Etiketi ortalamak için
        row.label(text="Random Rotation Settings")
        box.prop(settings, "align_to_normal")
        
        col=box.column_flow(columns=4)
        col.prop(settings, "random_rotation_x")
        col.prop(settings, "random_rotation_y")
        col.prop(settings, "random_rotation_z")

        # Ölçek ayarları
        box = layout.box()
        #box.label(text="Scale Settings:")
        box.prop(settings, "scale_random")
        if settings.scale_random:
            box.prop(settings, "scale_min")
            box.prop(settings, "scale_max")
        
        # Vertex weight ayarları
        box = layout.box()
        #box.label(text="Vertex Weight Settings:")
        box.prop(settings, "use_vertex_weight")
        if settings.use_vertex_weight and settings.target:
            box.prop_search(settings, "vertex_group", settings.target, "vertex_groups")
        
        # Scatter butonu
        layout.operator("object.advanced_surface_scatter")

class OBJECT_OT_AdvancedSurfaceScatter(bpy.types.Operator):
    bl_idname = "object.advanced_surface_scatter"
    bl_label = "Scatter Objects"
    bl_options = {'REGISTER', 'UNDO'}

    def get_random_point_on_face(self, face):
        # Üçgen yüzeyde random nokta
        verts = face.verts
        a = random.random()
        b = random.random()
        if a + b > 1:
            a = 1 - a
            b = 1 - b
        point = (verts[0].co * (1 - a - b) +
                verts[1].co * a +
                verts[2].co * b)
        return point, face.normal

    def check_distance(self, point, points_list, min_distance):
        if not points_list:
            return True
        for p in points_list:
            if (point - p).length < min_distance:
                return False
        return True

    def execute(self, context):
        settings = context.scene.scatter_settings
        
        if not settings.target or not settings.collection:
            self.report({'ERROR'}, "Please select both target surface and collection")
            return {'CANCELLED'}
            
        # Random seed ayarı
        random.seed(settings.seed)
        
        # Target mesh'i hazırla
        target = settings.target
        bm = bmesh.new()
        bm.from_mesh(target.data)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        bm.faces.ensure_lookup_table()
        
        # Vertex weight için hazırlık
        vertex_weights = None
        if settings.use_vertex_weight and settings.vertex_group:
            vertex_group = target.vertex_groups.get(settings.vertex_group)
            if vertex_group:
                vertex_weights = [0] * len(bm.verts)
                for v in bm.verts:
                    try:
                        vertex_weights[v.index] = vertex_group.weight(v.index)
                    except:
                        vertex_weights[v.index] = 0
        
        # Yüz alanlarını hesapla
        total_area = sum(f.calc_area() for f in bm.faces)
        
        # Scatter noktalarını oluştur
        scattered_points = []
        created_objects = []
        attempts = settings.count * 10  # Maximum deneme sayısı
        
        while len(scattered_points) < settings.count and attempts > 0:
            attempts -= 1
            
            # Random yüz seç
            rand_area = random.uniform(0, total_area)
            current_area = 0
            selected_face = None
            
            for face in bm.faces:
                current_area += face.calc_area()
                if current_area >= rand_area:
                    selected_face = face
                    break
                    
            if not selected_face:
                continue
                
            # Yüzde random nokta bul
            point, normal = self.get_random_point_on_face(selected_face)
            
            # Vertex weight kontrolü
            if vertex_weights:
                weight = sum(vertex_weights[v.index] for v in selected_face.verts) / len(selected_face.verts)
                if random.random() > weight:
                    continue
            
            # Mesafe kontrolü
            if settings.min_distance > 0:
                if not self.check_distance(point, scattered_points, settings.min_distance):
                    continue
            
            # Nokta ve normal'i dünya koordinatlarına çevir
            world_point = target.matrix_world @ point
            world_normal = target.matrix_world.to_3x3() @ normal
            
            # Random obje seç
            objects = [obj for obj in settings.collection.objects if obj.type == 'MESH']
            if not objects:
                continue
                
            scatter_obj = random.choice(objects)
            new_obj = scatter_obj.copy()
            new_obj.data = scatter_obj.data.copy()
            bpy.context.scene.collection.objects.link(new_obj)
            
            # Pozisyon ayarla
            new_obj.location = world_point
            
            # Rotasyon ayarla
            if settings.align_to_normal:
                rot = world_normal.to_track_quat('-Z', 'Y')
                new_obj.rotation_euler = rot.to_euler()
            
            # Random rotasyon ekle
            if settings.random_rotation_x:
                new_obj.rotation_euler.x += random.uniform(0, 2 * math.pi)
            if settings.random_rotation_y:
                new_obj.rotation_euler.y += random.uniform(0, 2 * math.pi)
            if settings.random_rotation_z:
                new_obj.rotation_euler.z += random.uniform(0, 2 * math.pi)
            
            # Ölçek ayarla
            if settings.scale_random:
                scale = random.uniform(settings.scale_min, settings.scale_max)
                new_obj.scale = (scale, scale, scale)
            
            scattered_points.append(point)
            created_objects.append(new_obj)
        
        bm.free()
        
        if len(created_objects) < settings.count:
            self.report({'WARNING'}, f"Only placed {len(created_objects)} objects due to space constraints")
        
        return {'FINISHED'}

classes = (
    ScatterSettings,
    SCATTER_BY_COLLECION_PT_Panel,
    OBJECT_OT_AdvancedSurfaceScatter,
    OBJECT_PT_toggle_omni_scatter_by_collection_panel,
)

def register():
    bpy.types.WindowManager.omni_scatter_by_collection_panel_visible = bpy.props.BoolProperty(default=False)

    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.scatter_settings = bpy.props.PointerProperty(type=ScatterSettings)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.scatter_settings
    del bpy.types.WindowManager.omni_scatter_by_collection_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_omni_scatter_by_collectio_panel()