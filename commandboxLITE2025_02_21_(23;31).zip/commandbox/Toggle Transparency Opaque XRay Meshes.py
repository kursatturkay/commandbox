#https://www.youtube.com/watch?v=040BD5yNSwQ
import bpy


for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active

        
        if space.shading.type != 'SOLID':
            space.shading.type = 'SOLID'

        space.shading.light = 'STUDIO'

        if space.shading.color_type != 'OBJECT':
            space.shading.color_type = 'OBJECT'

selected_objects = bpy.context.selected_objects

if not selected_objects:  
    all_meshes = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']

    
    any_transparent = any(obj.color[3] < 1 for obj in all_meshes if len(obj.color) > 3)

    if any_transparent:
        
        for obj in all_meshes:
            if len(obj.color) > 3:
                obj.color[3] = 1  
    else:
        
        for obj in all_meshes:
            if len(obj.color) > 3:
                obj.color[3] = 0.1  
else:
    
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH' and obj not in selected_objects:
            if len(obj.color) > 3:  
                alpha = obj.color[3]  

                if alpha == 1:
                    obj.color[3] = 0.1  
                else:
                    obj.color[3] = 1  


# for area in bpy.context.screen.areas:
#     if area.type == 'VIEW_3D':
#         space = area.spaces.active
        
#         # Viewport Shading tipini 'SOLID' olarak ayarla
#         if space.shading.type != 'SOLID':
#             space.shading.type = 'SOLID'
        
#         space.shading.light = 'STUDIO'
        
#         if space.shading.color_type != 'OBJECT':
#             space.shading.color_type = 'OBJECT'

            
# selected_objects = bpy.context.selected_objects

# if not selected_objects:  # Eğer hiçbiri seçili değilse
#     for obj in bpy.context.scene.objects:
#         if obj.type == 'MESH' and obj.display_type in ['SOLID', 'TEXTURED']:  # Solid veya Textured objeler
#             if len(obj.color) > 3:  # Eğer renk verisi varsa (alpha dahil)
#                 obj.color[3] = 1  # Alpha değerini 1 yap
# else:
#     for obj in bpy.context.scene.objects:
#         if obj.type == 'MESH' and obj not in selected_objects:  # Seçili olmayan objeler
#             if obj.display_type in ['SOLID', 'TEXTURED']:  # Solid veya Textured objeler
#                 alpha = obj.color[3] if len(obj.color) > 3 else 1  # Alpha değeri kontrolü (varsayılan 1)
                
#                 if alpha == 1:
#                     obj.color[3] = 0.1
#                 else:
#                     obj.color[3] = 1

