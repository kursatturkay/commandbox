# https://www.youtube.com/watch?v=b0N9-lngOos
#Packet Collision Hull for Selected Meshes.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy,mathutils,random,colorsys

def clone_and_join_selected_objects():
    # Seçili objeleri al
    selected_objects = bpy.context.selected_objects
    
    # Eğer hiçbir obje seçilmemişse işlemi iptal et
    if not selected_objects:
        print("Hiçbir obje seçilmedi!")
        return
    
    # Klonları depolamak için bir liste
    cloned_objects = []
    
    # Her objeyi kopyala ve sahneye ekle
    for obj in selected_objects:
        cloned_object = obj.copy()
        cloned_object.data = obj.data.copy()  # Mesh verisini de kopyala
        bpy.context.collection.objects.link(cloned_object)  # Klonu sahneye ekle
        cloned_objects.append(cloned_object)
    
    # Orijinal objelerin seçimini kaldır
    for obj in selected_objects:
        obj.select_set(False)
    
    # Klonları seçili hale getir
    for cloned_obj in cloned_objects:
        cloned_obj.select_set(True)
    
    # İlk klonu aktif obje olarak ayarla ve birleştir
    bpy.context.view_layer.objects.active = cloned_objects[0]
    bpy.ops.object.join()
    
    print("Klonlar birleştirildi ve orijinal objelere dokunulmadı!")

# Scripti çalıştır
clone_and_join_selected_objects()

def convex_hull_geonodestree_node_group():
    convex_hull_geonodestree = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "CONVEX_HULL_GEONODESTREE")

    convex_hull_geonodestree.color_tag = 'NONE'
    convex_hull_geonodestree.description = ""
    convex_hull_geonodestree.default_group_node_width = 140

    convex_hull_geonodestree.is_modifier = True
    #convex_hull_geonodestree interface
    #Socket Geometry
    geometry_socket = convex_hull_geonodestree.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_1 = convex_hull_geonodestree.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'

    #Socket Scale
    scale_socket = convex_hull_geonodestree.interface.new_socket(name = "Scale", in_out='INPUT', socket_type = 'NodeSocketFloat')
    scale_socket.default_value = 1.05
    scale_socket.min_value = 0.0
    scale_socket.max_value = 3.4028234663852886e+38
    scale_socket.subtype = 'NONE'
    scale_socket.attribute_domain = 'POINT'
    #initialize convex_hull_geonodestree nodes
    #node Group Input
    group_input = convex_hull_geonodestree.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Group Output
    group_output = convex_hull_geonodestree.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Merge by Distance
    merge_by_distance = convex_hull_geonodestree.nodes.new("GeometryNodeMergeByDistance")
    merge_by_distance.name = "Merge by Distance"
    merge_by_distance.mode = 'CONNECTED'
    #Selection
    merge_by_distance.inputs[1].default_value = True
    #Distance
    merge_by_distance.inputs[2].default_value = 0.2

    #node Convex Hull
    convex_hull = convex_hull_geonodestree.nodes.new("GeometryNodeConvexHull")
    convex_hull.name = "Convex Hull"

    #node Scale Elements
    scale_elements = convex_hull_geonodestree.nodes.new("GeometryNodeScaleElements")
    scale_elements.name = "Scale Elements"
    scale_elements.domain = 'FACE'
    scale_elements.scale_mode = 'UNIFORM'
    #Selection
    scale_elements.inputs[1].default_value = True
    #Center
    scale_elements.inputs[3].default_value = (0.0, 0.0, 0.0)

    #Set locations
    group_input.location = (-214, -9)
    group_output.location = (1011, -73)
    merge_by_distance.location = (318, -13)
    convex_hull.location = (252, 117)
    scale_elements.location = (44, -69)

    #Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    merge_by_distance.width, merge_by_distance.height = 140.0, 100.0
    convex_hull.width, convex_hull.height = 140.0, 100.0
    scale_elements.width, scale_elements.height = 140.0, 100.0

    #initialize convex_hull_geonodestree links
    #group_input.Geometry -> scale_elements.Geometry
    convex_hull_geonodestree.links.new(group_input.outputs[0], scale_elements.inputs[0])
    #group_input.Scale -> scale_elements.Scale
    convex_hull_geonodestree.links.new(group_input.outputs[1], scale_elements.inputs[2])
    #scale_elements.Geometry -> convex_hull.Geometry
    convex_hull_geonodestree.links.new(scale_elements.outputs[0], convex_hull.inputs[0])
    #convex_hull.Convex Hull -> merge_by_distance.Geometry
    convex_hull_geonodestree.links.new(convex_hull.outputs[0], merge_by_distance.inputs[0])
    #merge_by_distance.Geometry -> group_output.Geometry
    convex_hull_geonodestree.links.new(merge_by_distance.outputs[0], group_output.inputs[0])
    return convex_hull_geonodestree

convex_hull_geonodestree = convex_hull_geonodestree_node_group()

#-----------------------------------------------------------------------------------------------------------------

#initialize onlyfaces_geonodestree node group
def onlyfaces_geonodestree_node_group():
    onlyfaces_geonodestree = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "ONLYFACES_GEONODESTREE")

    onlyfaces_geonodestree.color_tag = 'NONE'
    onlyfaces_geonodestree.description = ""
    onlyfaces_geonodestree.default_group_node_width = 140
    

    onlyfaces_geonodestree.is_modifier = True

    #onlyfaces_geonodestree interface
    #Socket Geometry
    geometry_socket = onlyfaces_geonodestree.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_1 = onlyfaces_geonodestree.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'


    #initialize onlyfaces_geonodestree nodes
    #node Group Input
    group_input = onlyfaces_geonodestree.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Group Output
    group_output = onlyfaces_geonodestree.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Delete Geometry
    delete_geometry = onlyfaces_geonodestree.nodes.new("GeometryNodeDeleteGeometry")
    delete_geometry.name = "Delete Geometry"
    delete_geometry.domain = 'FACE'
    delete_geometry.mode = 'ONLY_FACE'
    #Selection
    delete_geometry.inputs[1].default_value = True

    #Set locations
    group_input.location = (-340.0, 0.0)
    group_output.location = (200.0, 0.0)
    delete_geometry.location = (-78.83158111572266, -14.087467193603516)

    #Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    delete_geometry.width, delete_geometry.height = 140.0, 100.0

    #initialize onlyfaces_geonodestree links
    #delete_geometry.Geometry -> group_output.Geometry
    onlyfaces_geonodestree.links.new(delete_geometry.outputs[0], group_output.inputs[0])
    #group_input.Geometry -> delete_geometry.Geometry
    onlyfaces_geonodestree.links.new(group_input.outputs[0], delete_geometry.inputs[0])
    return onlyfaces_geonodestree

onlyfaces_geonodestree = onlyfaces_geonodestree_node_group()
#-----------------------------------------------------------------------------------------------------------------

def create_geonodes_modifier(obj, geonodes_tree_name):
    # Geometri Düğüm Ağı olup olmadığını kontrol et
    if geonodes_tree_name not in bpy.data.node_groups:
        print(f"'{geonodes_tree_name}' adlı bir Geometry Nodes ağacı bulunamadı!")
        return
    
    # Objeye Geometry Nodes modifier ekle
    modifier = obj.modifiers.new(name="GeometryNodes", type='NODES')
    
    # Geometri düğüm ağacını bağla
    modifier.node_group = bpy.data.node_groups[geonodes_tree_name]
#-----------------------------------------------------------------------------------------------------------------
selected_objects = bpy.context.selected_objects
for obj in selected_objects:
        create_geonodes_modifier(obj, "CONVEX_HULL_GEONODESTREE")
        
#-----------------------------------------------------------------------------------------------------------------
def add_decimate_modifier(obj, ratio=1.0):
    # Decimate modifier ekle
    modifier = obj.modifiers.new(name="Decimate", type='DECIMATE')
    
    # Collapse modunu seç ve Ratio ayarla
    modifier.decimate_type = 'COLLAPSE'
    modifier.ratio = ratio
    
for obj in selected_objects:
        add_decimate_modifier(obj)

#-----------------------------------------------------------------------------------------------------------------
#for obj in selected_objects:
#        create_geonodes_modifier(obj, "ONLYFACES_GEONODESTREE")
        
#----------------------------------------------------------------------------------------------------------------- 
def bake_geometry_nodes(obj):
    # Tüm Geometry Nodes modifier'larını bul
    for modifier in obj.modifiers:
        if modifier.type in ['NODES','DECIMATE']:
            # Geometry Nodes modifier'ını bake et
            bpy.ops.object.modifier_apply(modifier=modifier.name)

    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')


def remove_geometry_nodes_tree(obj, tree_names):
    # Belirtilen Geometry Nodes ağaçlarını sil
    for modifier in obj.modifiers:
        if modifier.type == 'NODES' and modifier.node_group:
            if modifier.node_group.name in tree_names:
                # Node grubu varsa, bu node ağacını sil
                obj.modifiers.remove(modifier)
                print(f"'{obj.name}' objesinden {modifier.node_group.name} Geometry Nodes ağacı silindi.")
                
                if modifier.node_group:
                    bpy.data.node_groups.remove(modifier.node_group)

tree_names = ['CONVEX_HULL_GEONODESTREE', 'ONLYFACES_GEONODESTREE']

# Her bir node grubu için kontrol et ve sil
# for node_group in bpy.data.node_groups:
#     if node_group.name in tree_names:
#         bpy.data.node_groups.remove(node_group)
        
for obj in selected_objects:
    bake_geometry_nodes(obj)
    
tree_names = ['CONVEX_HULL_GEONODESTREE', 'ONLYFACES_GEONODESTREE']

# Her bir node grubu için kontrol et ve sil
for node_group in bpy.data.node_groups:
    if node_group.name in tree_names:
        bpy.data.node_groups.remove(node_group)
        
#        # 'CONVEX_HULL_GEONODESTREE' ve 'ONLYFACES_GEONODESTREE' ağaçlarını sil
#        remove_geometry_nodes_tree(obj, ['CONVEX_HULL_GEONODESTREE', 'ONLYFACES_GEONODESTREE'])
    
#-----------------------------------------------------------------------------------------------------------------
    
def assign_random_rainbow_viewport_color(obj):
    # Rastgele bir gökkuşağı rengi oluştur
    hue = random.uniform(0, 1)  # Renk tonunu belirle (0-1 arasında rastgele bir değer)
    saturation = 1.0  # Doygunluk
    value = 1.0  # Parlaklık
    
    # HSV'yi RGB'ye dönüştür
    rgb = colorsys.hsv_to_rgb(hue, saturation, value)
    color = rgb + (0.3,)  # Alpha eklenir (RGBA)
    
    # Viewport Display > Color ayarını değiştir
    obj.color = color
    
    print(f"'{obj.name}' objesine rastgele bir gökkuşağı rengi atandı: {color}")
    
for obj in selected_objects:
        assign_random_rainbow_viewport_color(obj)
        
#--------------------------------------------------------------------------------------
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active
        if space.shading.type != 'SOLID':
            space.shading.type = 'SOLID'
        space.shading.light = 'STUDIO'

bpy.context.space_data.shading.color_type = 'OBJECT'