#Show All Meshes Only
import bpy

for obj in bpy.context.scene.objects:
    if obj.type != 'MESH':
        obj.hide_set(True)
    else:
        obj.hide_set(False)