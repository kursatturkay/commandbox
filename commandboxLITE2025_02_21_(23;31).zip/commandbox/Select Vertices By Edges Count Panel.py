#https://www.youtube.com/watch?v=hZn1z-Sdvt0
#Select Vertices By Edges Panel.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh

class SelectVerticesProperties(bpy.types.PropertyGroup):
    edge_count_0: bpy.props.BoolProperty(name="0 Edges", default=False)
    edge_count_1: bpy.props.BoolProperty(name="1 Edge", default=False)
    edge_count_2: bpy.props.BoolProperty(name="2 Edges", default=False)
    edge_count_3: bpy.props.BoolProperty(name="3 Edges", default=False)
    edge_count_4: bpy.props.BoolProperty(name="4 Edges", default=False)
    edge_count_5_or_more: bpy.props.BoolProperty(name="5 or More Edges", default=False)

class SelectVerticesByEdgesOperator(bpy.types.Operator):
    bl_idname = "mesh.select_vertices_by_edges"
    bl_label = "Select Vertices by Edge Count"
    bl_description = "Select vertices based on the number of connected edges"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        props = context.scene.select_vertices_props

        if obj and obj.type == 'MESH':
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='VERT') 
            bpy.ops.mesh.select_all(action='DESELECT')

            bm = bmesh.from_edit_mesh(obj.data)

            for v in bm.verts:
                v.select = False

            selected_count = 0

            for v in bm.verts:
                connected_edges = len(v.link_edges)
                if (props.edge_count_0 and connected_edges == 0) or \
                   (props.edge_count_1 and connected_edges == 1) or \
                   (props.edge_count_2 and connected_edges == 2) or \
                   (props.edge_count_3 and connected_edges == 3) or \
                   (props.edge_count_4 and connected_edges == 4) or \
                   (props.edge_count_5_or_more and connected_edges >= 5):
                    v.select = True
                    selected_count += 1

            bmesh.update_edit_mesh(obj.data)
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='VERT') 

            textinfo_=f"{selected_count} vertices selected."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        else:
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="No mesh object selected.", duration=5)

        return {'FINISHED'}

# Operator for toggling panel visibility
class SCENE_OT_toggle_vertices_by_edges_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_vertices_by_edges_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.show_select_vertices_by_edges_panel = not context.scene.show_select_vertices_by_edges_panel

        if(context.scene.show_select_vertices_by_edges_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()        
        return {'FINISHED'}
    
class SelectVerticesPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_select_vertices"
    bl_label = "Select Vertices by Edges Count"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
    
        return context.scene.show_select_vertices_by_edges_panel

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_vertices_by_edges_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        props = context.scene.select_vertices_props

        col = layout.column()
        col.label(text="Edge Count Selection:")
        col.prop(props, "edge_count_0")
        col.prop(props, "edge_count_1")
        col.prop(props, "edge_count_2")
        col.prop(props, "edge_count_3")
        col.prop(props, "edge_count_4")
        col.prop(props, "edge_count_5_or_more")
        col.operator(SelectVerticesByEdgesOperator.bl_idname, text="Select Vertices")

classes = [
    SelectVerticesProperties,
    SelectVerticesByEdgesOperator,
    SelectVerticesPanel,
    SCENE_OT_toggle_vertices_by_edges_panel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.select_vertices_props = bpy.props.PointerProperty(type=SelectVerticesProperties)

    bpy.types.Scene.show_select_vertices_by_edges_panel = bpy.props.BoolProperty(
    name="Show Select Vertices By Edges Panel",
    default=False)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.select_vertices_props
    del bpy.types.Scene.show_select_vertices_by_edges_panel

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_vertices_by_edges_panel()

# def toggle():
    
#     if hasattr(bpy.types, "VIEW3D_PT_select_vertices"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
#         #unregister() throws mRNA error ? couldnt resolve so commented  
#         bpy.utils.unregister_class(bpy.types.VIEW3D_PT_select_vertices)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
#         register()

# İlk çalıştırma (register yapılacak)
# if __name__ == "__main__":
#     toggle()