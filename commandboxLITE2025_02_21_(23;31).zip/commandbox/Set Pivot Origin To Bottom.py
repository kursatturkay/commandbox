#https://www.youtube.com/watch?v=VULz9kd7vDY
#Set Pivot Origin To Bottom.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh
from mathutils import Vector, Matrix

def set_origin_to_bottom_vertex_without_moving():
    
    selected_objects = list(bpy.context.selected_objects)

    for obj in selected_objects:
        if obj.type == 'MESH':
            
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            bpy.context.view_layer.objects.active = obj  

            bpy.ops.object.mode_set(mode='EDIT')
            
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()

            world_coords = [obj.matrix_world @ v.co for v in bm.verts]
            min_z = min(coord.z for coord in world_coords)
            
            bpy.ops.object.mode_set(mode='OBJECT')

            bpy.context.scene.cursor.location = Vector((obj.location.x, obj.location.y, min_z)) 
            
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

            
            obj.location.z -= (min_z - obj.location.z) 


set_origin_to_bottom_vertex_without_moving()