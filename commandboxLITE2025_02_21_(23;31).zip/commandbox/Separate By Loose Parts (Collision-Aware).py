#https://www.youtube.com/watch?v=7l3fyNRagfU
#Separate By Loose Parts (Collision-Aware).
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh
from mathutils.bvhtree import BVHTree

def get_bvh(obj):
    """Objenin BVH ağacını oluşturur."""
    depsgraph = bpy.context.evaluated_depsgraph_get()
    eval_obj = obj.evaluated_get(depsgraph)

    mesh = eval_obj.to_mesh()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bvh = BVHTree.FromBMesh(bm)
    bm.free()
    eval_obj.to_mesh_clear()

    return bvh

def separate_loose_parts(obj):
    """Seçili mesh'i Loose Parts olarak ayırır."""
    bpy.ops.object.select_all(action='DESELECT')
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    
    bpy.ops.object.mode_set(mode='EDIT')  
    bpy.ops.mesh.separate(type='LOOSE')  
    bpy.ops.object.mode_set(mode='OBJECT')

def find_connected_groups(meshes):
    """Çakışan meshleri tamamen bağlı olan gruplara böler (Zincirleme bağlantılar dahil)."""
    bvh_map = {obj: get_bvh(obj) for obj in meshes}  

    groups = []
    visited = set()

    def traverse_group(start_obj):
        """Zincirleme olarak bağlı tüm meshleri bulur."""
        queue = [start_obj]
        group = []

        while queue:
            obj = queue.pop(0)
            if obj in visited:
                continue

            visited.add(obj)
            group.append(obj)

            
            for other in meshes:
                if other not in visited and bvh_map[obj].overlap(bvh_map[other]):
                    queue.append(other)

        return group

    
    for obj in meshes:
        if obj not in visited:
            groups.append(traverse_group(obj))

    return groups

def process_selected_object():
    """Seçili objeyi Loose Parts'a ayırır ve çarpışanları tekrar birleştirir."""
    selected_obj = bpy.context.object
    if not selected_obj or selected_obj.type != 'MESH':
        textinfo_="Please Select A Mesh."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return
    
    separate_loose_parts(selected_obj)

    new_meshes = [o for o in bpy.context.selected_objects if o.type == 'MESH']
    
    colliding_groups = find_connected_groups(new_meshes)
    
    for group in colliding_groups:
        if len(group) > 1:
            bpy.ops.object.select_all(action='DESELECT')
            for obj in group:
                obj.select_set(True)
            bpy.context.view_layer.objects.active = group[0]
            bpy.ops.object.join()

    # Pivotları ayarla (Tüm yeni meshler için)
    bpy.ops.object.select_all(action='DESELECT')  # Önce hiçbir şey seçili olmasın
    new_meshes = [o for o in bpy.context.scene.objects if o.type == 'MESH' and o.name not in [selected_obj.name]] #Yeni objeleri bul

    for obj in new_meshes:
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        obj.select_set(False)

    textinfo_=f"{len(colliding_groups)} groups created."
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

process_selected_object()