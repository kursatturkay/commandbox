#Isolate Objects By Face Count
import bpy

# Seçili objeleri al
selected_objects = bpy.context.selected_objects

# Hiçbir obje seçili değilse
if len(selected_objects) == 0:
    # Tüm objeleri görünür yap
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            obj.hide_set(False)  # Her şeyi görünür yap
else:
    # Seçili objelerden birinin face sayısını al
    for selected_obj in selected_objects:
        if selected_obj.type == 'MESH':
            face_count = len(selected_obj.data.polygons)
            bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Face count of the selected object: {face_count}", duration=5)

            # Sahnedeki tüm objeleri döngüye al
            for obj in bpy.context.scene.objects:
                if obj.type == 'MESH':
                    if len(obj.data.polygons) == face_count:
                        obj.hide_set(False)  # Görünür yap
                    else:
                        obj.hide_set(True)  # Gizle
            break  # İlk seçili obje ile işlem yaptıktan sonra döngüyü kır
