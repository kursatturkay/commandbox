#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Select all Meshes with Passive Rigidbody.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy


class SelectPassiveRigidBodyMeshesOperator(bpy.types.Operator):
    """Select all meshes with passive rigidbody"""
    bl_idname = "object.select_passive_rigidbody_meshes"
    bl_label = "Select Passive RigidBody Meshes"

    def execute(self, context):
        bpy.ops.object.select_all(action='DESELECT')
        for obj in context.scene.objects:
            if obj.type == 'MESH' and obj.rigid_body and obj.rigid_body.type == 'PASSIVE':
                obj.select_set(True)
        self.report({'INFO'}, "Passive RigidBody Meshes Selected")
        return {'FINISHED'}

# Register classes
def register():
    bpy.utils.register_class(SelectPassiveRigidBodyMeshesOperator)


def unregister():
    bpy.utils.unregister_class(SelectPassiveRigidBodyMeshesOperator)

if __name__ == "__main__":
    register()
    bpy.ops.object.select_passive_rigidbody_meshes()
