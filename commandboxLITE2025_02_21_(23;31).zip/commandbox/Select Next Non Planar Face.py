# https://www.youtube.com/watch?v=tj_PhNt8zAI
import bpy
import bmesh
import mathutils

# Function to check if a face is planar
def is_non_planar(face):
    # Get the vertices of the face
    verts = [v.co for v in face.verts]
    
    if len(verts) < 3:
        return False  # Faces with fewer than 3 vertices are not planar
    
    # Calculate the normal of the face from the first 3 vertices
    edge1 = verts[1] - verts[0]
    edge2 = verts[2] - verts[0]
    face_normal = edge1.cross(edge2).normalized()

    # Check if all vertices are within a small deviation from the plane of the first 3 vertices
    for v in verts[3:]:  # If the face has more than 3 vertices
        edge = v - verts[0]
        # Calculate the deviation of the vertex from the plane
        deviation = abs(face_normal.dot(edge))
        if deviation > 0.001:  # Threshold for non-planarity
            return True  # Non-planar if deviation is too large
    
    return False  # Planar face if no large deviation

# Get the active object and its mesh data
obj = bpy.context.object

# Ensure the object is in edit mode and has geometry data
if obj and obj.type == 'MESH':
    bpy.ops.object.mode_set(mode='EDIT')  # Ensure we're in edit mode
    bpy.ops.mesh.select_all(action='DESELECT')  # Deselect all
    
    # Switch to face selection mode
    bpy.ops.mesh.select_mode(type='FACE')

    # Get the BMesh representation of the object
    bm = bmesh.from_edit_mesh(obj.data)
    
    # Get the custom property for tracking the last selected face index
    if "last_selected_face" not in obj:
        obj["last_selected_face"] = -1  # Initialize with -1 if not set
    
    last_selected_index = obj["last_selected_face"]
    selected = False
    
    # Iterate through the faces starting from the last selected face
    for i, f in enumerate(bm.faces):
        if is_non_planar(f) and i > last_selected_index:  # Check if the face is non-planar
            f.select = True  # Select the non-planar face
            obj["last_selected_face"] = i  # Update the index of the last selected face
            selected = True
            break  # Stop after selecting the next non-planar face
    
    # If no new non-planar face was found, start from the first face again
    if not selected:
        for i, f in enumerate(bm.faces):
            if is_non_planar(f):  # Check if the face is non-planar
                f.select = True  # Select the first non-planar face
                obj["last_selected_face"] = i  # Update to the first face
                break  # Stop after selecting the first non-planar face
    
    # Update the mesh to reflect the changes in edit mode
    bmesh.update_edit_mesh(obj.data)
    
    # Switch back to object mode to update the selection visually
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # Switch back to edit mode to keep the object in edit mode
    bpy.ops.object.mode_set(mode='EDIT')
