#https://www.youtube.com/watch?v=7l3fyNRagfU
import bpy
class SeparateLoosePartsOperator(bpy.types.Operator):
    bl_idname = "object.separate_loose_parts"
    bl_label = "Separate Loose Parts and Adjust Pivot"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        for obj in selected_objects:
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')  
            bpy.ops.mesh.separate(type='LOOSE')  
            bpy.ops.object.mode_set(mode='OBJECT')

            # Pivotları ayarla
            context.view_layer.objects.active = obj
            obj.select_set(True)
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
            obj.select_set(False)
        
        return {'FINISHED'}

# Operatörü kaydet
def register():
    bpy.utils.register_class(SeparateLoosePartsOperator)

def unregister():
    bpy.utils.unregister_class(SeparateLoosePartsOperator)

if __name__ == "__main__":
    register()
    bpy.ops.object.separate_loose_parts()
    
