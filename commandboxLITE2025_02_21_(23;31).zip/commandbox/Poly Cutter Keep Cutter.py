#① Select CUTTER mesh  ② Select TARGET mesh. ③ Apply command. (be sure normals are correct) 
#https://www.youtube.com/watch?v=ZNE5mm4ttdc
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 
import bpy

def split_mesh_with_static_cutter():
    
    selected_objects = bpy.context.selected_objects
    if len(selected_objects) != 2:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select exactly two objects.", duration=5)
        return

    object_to_split = bpy.context.view_layer.objects.active  
    cutting_object = [obj for obj in selected_objects if obj != object_to_split][0]  

    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Object to split: {object_to_split.name}", duration=5)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Cutting object: {cutting_object.name}", duration=5)

    split_pieces = []

    bpy.ops.object.select_all(action='DESELECT')
    object_to_split.select_set(True)
    bpy.ops.object.duplicate()
    outer_piece = bpy.context.selected_objects[0]
    outer_piece.name = f"{object_to_split.name}_Outer"

    outer_mod = outer_piece.modifiers.new(name="Boolean_Difference", type='BOOLEAN')
    outer_mod.operation = 'DIFFERENCE'
    outer_mod.object = cutting_object
    bpy.context.view_layer.objects.active = outer_piece
    bpy.ops.object.modifier_apply(modifier=outer_mod.name)
    split_pieces.append(outer_piece)

    
    bpy.ops.object.select_all(action='DESELECT')
    object_to_split.select_set(True)
    bpy.ops.object.duplicate()
    inner_piece = bpy.context.selected_objects[0]
    inner_piece.name = f"{object_to_split.name}_Inner"

    inner_mod = inner_piece.modifiers.new(name="Boolean_Intersect", type='BOOLEAN')
    inner_mod.operation = 'INTERSECT'
    inner_mod.object = cutting_object
    bpy.context.view_layer.objects.active = inner_piece
    bpy.ops.object.modifier_apply(modifier=inner_mod.name)
    split_pieces.append(inner_piece)

    object_to_split.hide_set(True)
    
    cutting_object.select_set(False)

    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Split completed! Generated {len(split_pieces)} pieces.", duration=5)

split_mesh_with_static_cutter()
