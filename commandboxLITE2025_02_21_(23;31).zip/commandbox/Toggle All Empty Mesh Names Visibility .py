#  add a youtube url link to first line for Toggle All Empty Mesh Names Visibility 
import bpy


def toggle_name_visibility_for_empty_meshes():
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            
            if len(obj.data.polygons) == 0:
                
                obj.show_name = not obj.show_name


def set_name_visibility_for_empty_meshes():
    current_visibility = None
    
    
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH' and len(obj.data.polygons) == 0:
            current_visibility = obj.show_name
            break
    
    
    if current_visibility is not None:
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH' and len(obj.data.polygons) == 0:
                obj.show_name = not current_visibility  


set_name_visibility_for_empty_meshes()
