# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① Deselects All    ② Selects Only Meshes    ③ Frame Selected

import bpy

# Tüm Mesh objelerini seç
bpy.ops.object.select_all(action='DESELECT')

for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        obj.select_set(True)

# Aktif objeyi son seçilen objeye ayarla (isteğe bağlı)
bpy.context.view_layer.objects.active = bpy.context.selected_objects[-1]

##Frame Selected
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':

        for region in area.regions:
            if region.type == 'WINDOW':

                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
                break

textinfo_=f"Mesh Selected: {len(bpy.context.selected_objects)}"
bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
