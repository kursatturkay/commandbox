import bpy

if "toggle_ngon_visibility" not in bpy.context.scene:
    bpy.context.scene["toggle_ngon_visibility"] = True

toggle_ngon_visibility = bpy.context.scene["toggle_ngon_visibility"]

if toggle_ngon_visibility:
    
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            has_five_or_more = any(len(face.vertices) > 4 for face in obj.data.polygons)
            obj.hide_set(not has_five_or_more)
            obj.hide_viewport = not has_five_or_more
else:
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            obj.hide_set(False)
            obj.hide_viewport = False

bpy.context.scene["toggle_ngon_visibility"] = not toggle_ngon_visibility
