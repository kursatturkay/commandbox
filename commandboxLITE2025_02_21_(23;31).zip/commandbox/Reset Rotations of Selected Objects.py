# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Reset Rotations of Selected Objects.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def reset_rotations():
    """Reset the rotations of selected objects."""
    for obj in bpy.context.selected_objects:
        # Sıfırla: Rotasyon
        if hasattr(obj, "rotation_euler"):
            obj.rotation_euler = (0.0, 0.0, 0.0)
        
# Call the function
reset_rotations()
