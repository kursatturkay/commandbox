# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Select Siblings in Collection.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

def select_siblings_objects():
    # Aktif objeyi al
    active_object = bpy.context.object
    
    if active_object:
        # Aktif objenin bulunduğu koleksiyonu al
        collections = active_object.users_collection
        if collections:
            # İlk koleksiyonu al (bir obje birden fazla koleksiyona ait olabilir)
            collection = collections[0]
            
            # Koleksiyon içindeki tüm objeleri seç
            for obj in collection.objects:
                obj.select_set(True)
            
            # Aktif objeyi belirle
            bpy.context.view_layer.objects.active = active_object

# Operatör veya manuel kullanım için
select_siblings_objects()
