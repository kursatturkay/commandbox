# https://www.youtube.com/watch?v=fFaVtxX0SdA
import bpy
import random

# Gökkuşağının daha yumuşak pastel tonları (RGB)
kawaii_colors = [
    (0.8, 0.2, 0.4),  # Koyu Kawaii Pembe
    (1.0, 0.6, 0.0),  # Koyu Kawaii Sarı-Turuncu
    (0.3, 0.7, 0.3),  # Koyu Kawaii Yeşil
    (0.4, 0.6, 0.8),  # Koyu Kawaii Mavi
    (0.6, 0.3, 0.8),  # Koyu Kawaii Lavanta
    (0.8, 0.2, 0.8),  # Koyu Kawaii Mor
    (0.9, 0.9, 0.5),  # Koyu Kawaii Sarı
]




# Rastgele bir yumuşak gökkuşağı rengi seç
base_color_high = random.choice(kawaii_colors)
base_color_gradient = random.choice(kawaii_colors)

# Blender Preferences'ı al
prefs = bpy.context.preferences

# Varsayılan tema ayarlarına eriş
theme = prefs.themes[0]  # Genellikle ilk tema varsayılan temadır
view_3d_theme = theme.view_3d  # 3D Viewport teması

# Arka plan türünü "RADIAL" olarak ayarlayın
view_3d_theme.space.gradients.background_type = 'LINEAR'

# Rastgele pastel gökkuşağı renklerini ayarla
view_3d_theme.space.gradients.high_gradient = base_color_high  # Rastgele yüksek pastel renk
view_3d_theme.space.gradients.gradient = base_color_gradient     # Rastgele pastel gradient rengi

bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Soft rainbow colors have been set for the 3D Viewport gradient background.", duration=5)
