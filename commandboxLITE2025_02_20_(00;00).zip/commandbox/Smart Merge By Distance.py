#
# Merges By Distance depending on nearest vertices of Selected Mesh and each process tolreance will be gruadually increase.
import bpy

# import os
# import sys

# current_dir = os.path.dirname(__file__)

# if current_dir not in sys.path:
#     sys.path.append(current_dir)

# import _modal_draw_operator

# if not hasattr(_modal_draw_operator, 'is_registered') or not _modal_draw_operator.is_registered:
#     _modal_draw_operator.register()
#     _modal_draw_operator.is_registered = True



def smart_merge_vertices_of_selected_objects(initial_distance=0.0001, increment=0.0001):
    
    selected_objects = bpy.context.selected_objects
    if not selected_objects:
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="No Mesh Selected")
        return

    for obj in selected_objects:
        if obj.type == 'MESH':
            
            bpy.context.view_layer.objects.active = obj
            
            
            original_vertex_count = len(obj.data.vertices)
            distance = initial_distance
            has_changed = False  

            
            bpy.ops.object.mode_set(mode='EDIT')

            merging_active = True  

            while merging_active:
                bpy.ops.mesh.select_all(action='SELECT')  
                bpy.ops.mesh.remove_doubles(threshold=distance)  
                
                
                bpy.ops.object.mode_set(mode='OBJECT')
                new_vertex_count = len(obj.data.vertices)

                
                if new_vertex_count != original_vertex_count:
                    has_changed = True  

                    diff_=original_vertex_count-new_vertex_count 
                    info_=f"{diff_} Vertex Optimized. New Vertex Count: {new_vertex_count}"
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=info_)
                    
                    
                    merging_active = False  
                    break  

                original_vertex_count = new_vertex_count  
                distance += increment  
                
                bpy.ops.object.mode_set(mode='EDIT')

            if not has_changed:
                info_=f"'{obj.name}' vertex count '{original_vertex_count}' not changed."

                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=info_)

def main():
    smart_merge_vertices_of_selected_objects(initial_distance=0.0001, increment=0.0001)

if __name__ == "__main__":
    main()
