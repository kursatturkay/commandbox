#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Report Island Count for Selected Mesh.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh

# Aktif nesneyi al
obj = bpy.context.active_object

# Mesh ve UV kontrolü
if obj and obj.type == 'MESH' and obj.data.uv_layers.active:
    # BMesh oluştur
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    uv_layer = bm.loops.layers.uv.active

    # Ziyaret edilen yüzler
    visited_faces = set()
    islands = 0

    # Flood fill algoritması ile adaları tespit et
    def find_island(start_face):
        stack = [start_face]
        while stack:
            face = stack.pop()
            if face in visited_faces:
                continue
            visited_faces.add(face)
            for edge in face.edges:
                if not edge.seam:  # Dikiş (seam) değilse komşu yüzleri kontrol et
                    for linked_face in edge.link_faces:
                        if linked_face not in visited_faces:
                            stack.append(linked_face)

    # Tüm yüzleri tarayarak adaları say
    for face in bm.faces:
        if face not in visited_faces:
            find_island(face)
            islands += 1

    bm.free()

    textinfo_=f"UV Island Count: {islands}"
else:
    textinfo_="No active Mesh or no UV Map found."

bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)