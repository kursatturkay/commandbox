#https://www.youtube.com/watch?v=43vwGM8grPg
#Pipes From Faces Panel
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
from bpy.props import IntProperty, FloatProperty, PointerProperty, BoolProperty

def update_curve_bevel(context):
    selected_objects = context.selected_objects
    pipe_props = context.scene.pipe_props
    
    for obj in selected_objects:
        if obj.type == 'CURVE':
            obj.data.bevel_depth = pipe_props.curve_bevel_depth
            obj.data.bevel_resolution = pipe_props.curve_bevel_resolution
            
            if obj.data.bevel_object:
                bevel_obj = obj.data.bevel_object
                if bevel_obj.type == 'MESH':
                    bpy.context.view_layer.objects.active = bevel_obj
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.bevel(
                        offset=pipe_props.curve_bevel_depth * 0.1, 
                        segments=pipe_props.segments,
                        profile=pipe_props.shape,
                        affect='VERTICES',
                        clamp_overlap=True
                    )
                    bpy.ops.object.mode_set(mode='OBJECT')

class PipeProperties(bpy.types.PropertyGroup):
    def update_segments(self, context):
        update_curve_bevel(context)

    def update_shape(self, context):
        update_curve_bevel(context)

    def update_curve_bevel_depth(self, context):
        update_curve_bevel(context)

    def update_curve_bevel_resolution(self, context):
        update_curve_bevel(context)

    segments: IntProperty(
        name="Bevel Segments",
        description="Bevel segment sayısı",
        default=4,
        min=1,
        max=32,
        update=update_segments
    )
    shape: FloatProperty(
        name="Bevel Shape",
        description="Bevel şekli",
        default=0.5,
        min=0.0,
        max=1.0,
        update=update_shape
    )
    curve_bevel_depth: FloatProperty(
        name="Curve Bevel Depth",
        description="Curve bevel derinliği",
        default=0.1,
        min=0.0,
        max=1.0,
        update=update_curve_bevel_depth
    )
    curve_bevel_resolution: IntProperty(
        name="Curve Bevel Resolution",
        description="Curve bevel çözünürlüğü",
        default=4,
        min=1,
        max=32,
        update=update_curve_bevel_resolution
    )
    is_pipe_created: BoolProperty(
        name="Is Pipe Created",
        description="Pipe'ın oluşturulup oluşturulmadığını belirtir.",
        default=False
    )

class MESH_OT_CustomSeparateOperator(bpy.types.Operator):
    """Custom Operator: Separate Selected Faces into New Objects"""
    bl_idname = "mesh.custom_separate"
    bl_label = "Custom Separate"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        if not context.tool_settings.mesh_select_mode[2]:
            self.report({'WARNING'}, "This operation only works in Face Select mode. Please switch to Face Select mode.")
            return {'CANCELLED'}

        
        objects_before = set(obj.name for obj in context.scene.objects if obj.type == 'MESH')
        
        bpy.ops.mesh.region_to_loop()
        bpy.ops.mesh.duplicate()
        bpy.ops.mesh.separate(type='SELECTED')
        
        bpy.ops.object.mode_set(mode='OBJECT')

        objects_after = set(obj.name for obj in context.scene.objects if obj.type == 'MESH')

        new_objects = objects_after - objects_before

        if new_objects:
            
            bpy.ops.object.select_all(action='DESELECT')
            
            for obj_name in new_objects:
                obj = bpy.data.objects[obj_name]
                obj.select_set(True)
            
            context.view_layer.objects.active = bpy.data.objects[list(new_objects)[0]]

            self.report({'INFO'}, f"Selected new objects: {', '.join(new_objects)}")
        else:
            self.report({'WARNING'}, "No new objects were created.")

        return {'FINISHED'}

class MESH_OT_convertToPipe(bpy.types.Operator):
    bl_idname = "mesh.convert_to_pipe"
    bl_label = "Convert to Pipe"
    bl_description = "Seçili meshleri curve'e dönüştürüp bevel uygular."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "Lütfen en az bir mesh seçin.")
            return {'CANCELLED'}
        
        pipe_props = context.scene.pipe_props
        
        bpy.ops.mesh.custom_separate()
        
        selected_objects = context.selected_objects

        for obj in selected_objects:
            if obj.type == 'MESH':
                bpy.context.view_layer.objects.active = obj
                
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                
                bevel_depth = pipe_props.curve_bevel_depth * 0.1  
                
                bpy.ops.mesh.bevel(
                    offset=bevel_depth,
                    segments=pipe_props.segments,
                    profile=pipe_props.shape,
                    affect='VERTICES',
                    clamp_overlap=True
                )

                bpy.ops.object.mode_set(mode='OBJECT')

                bpy.ops.object.convert(target='CURVE')
                curve_obj = bpy.context.object
                
                curve_obj.data.bevel_depth = pipe_props.curve_bevel_depth
                curve_obj.data.bevel_resolution = pipe_props.curve_bevel_resolution

        pipe_props.is_pipe_created = True
        return {'FINISHED'}

class MESH_OT_bakePipe(bpy.types.Operator):
    bl_idname = "mesh.bake_pipe"
    bl_label = "Bake Pipe"
    bl_description = "Pipe şeklini mesh'e uygular."
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({'WARNING'}, "Lütfen en az bir curve seçin.")
            return {'CANCELLED'}
        
        for obj in selected_objects:
             if obj.type == 'CURVE':
                 bpy.context.view_layer.objects.active = obj
                 bpy.ops.object.convert(target='MESH')

        pipe_props = context.scene.pipe_props
        pipe_props.is_pipe_created = False  
        return {'FINISHED'}
    

# Operator for toggling panel visibility
class SCENE_OT_toggle_pipes_from_faces_panel(bpy.types.Operator):
    """Toggle the visibility of Faces To Pipes Panel"""
    bl_idname = "scene.toggle_pipes_from_faces_panel"
    bl_label = "Toggle Faces To Pipes Panel"

    def execute(self, context):
        context.scene.show_pipes_from_faces_panel = not context.scene.show_pipes_from_faces_panel

        if(context.scene.show_pipes_from_faces_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
    
class MESH_PT_pipePanel(bpy.types.Panel):
    bl_label = "Pipes From Faces Panel"
    bl_idname = "MESH_PT_pipe_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_pipes_from_faces_panel
    
    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_pipes_from_faces_panel", text="", icon ='CANCEL',emboss = False)

    def execute(self, context):
        context.scene.show_pipes_from_faces_panel = not context.scene.show_pipes_from_faces_panel
        return {'FINISHED'}
    
    def draw(self, context):
        layout = self.layout
        pipe_props = context.scene.pipe_props

        if not pipe_props.is_pipe_created:
            layout.prop(pipe_props, "curve_bevel_depth")
            layout.prop(pipe_props, "curve_bevel_resolution")
            layout.operator("mesh.convert_to_pipe", text="Create Pipe From Faces")
        else:
            
            layout.prop(pipe_props, "curve_bevel_depth")
            layout.prop(pipe_props, "curve_bevel_resolution")
            layout.operator("mesh.bake_pipe", text="Bake")

def register():

    bpy.types.Scene.show_pipes_from_faces_panel = bpy.props.BoolProperty(
        name="Show Pipes From Faces Panel",
        default=False
    )

    bpy.utils.register_class(PipeProperties)
    bpy.utils.register_class(MESH_OT_CustomSeparateOperator)
    bpy.utils.register_class(SCENE_OT_toggle_pipes_from_faces_panel)
    bpy.utils.register_class(MESH_OT_convertToPipe)
    bpy.utils.register_class(MESH_OT_bakePipe)
    bpy.utils.register_class(MESH_PT_pipePanel)
    bpy.types.Scene.pipe_props = PointerProperty(type=PipeProperties)

def unregister():
    bpy.utils.unregister_class(PipeProperties)
    bpy.utils.unregister_class(MESH_OT_CustomSeparateOperator)
    bpy.utils.unregister_class(SCENE_OT_toggle_pipes_from_faces_panel)
    bpy.utils.unregister_class(MESH_OT_convertToPipe)
    bpy.utils.unregister_class(MESH_OT_bakePipe)
    bpy.utils.unregister_class(MESH_PT_pipePanel)
    del bpy.types.Scene.pipe_props
    del bpy.types.Scene.show_pipes_from_faces_panel

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_pipes_from_faces_panel()