#https://www.youtube.com/watch?v=Rcgu_myl8XA
# #① Select Object To be Lightened. ② Run This Command. ③ Press F3 And Type partial keywords of Operator "3 Point Light Setup". ④ Press Enter
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 
import bpy

class LIGHT_OT_SetupOperator(bpy.types.Operator):
    bl_idname = "light.setup_operator"
    bl_label = "3 Point Light Setup"
    bl_description = "Setup 3-point lighting for the selected object"
    bl_options = {'REGISTER', 'UNDO'}

    light_type: bpy.props.EnumProperty(
        name="Light Type",
        description="Choose the type of lights to create",
        items=[
            ('POINT', "Point", "Point Light"),
            ('SPOT', "Spot", "Spot Light"),
            ('AREA', "Area", "Area Light"),
        ],
        default='AREA',
    )

    key_light_color: bpy.props.FloatVectorProperty(
        name="Key Light Color",
        subtype='COLOR',
        default=(1.0, 0.8, 0.6),
        min=0.0, max=1.0,
        description="Color of the Key Light"
    )

    fill_light_color: bpy.props.FloatVectorProperty(
        name="Fill Light Color",
        subtype='COLOR',
        default=(0.6, 0.8, 1.0),
        min=0.0, max=1.0,
        description="Color of the Fill Light"
    )

    back_light_color: bpy.props.FloatVectorProperty(
        name="Back Light Color",
        subtype='COLOR',
        default=(0.8, 0.6, 1.0),
        min=0.0, max=1.0,
        description="Color of the Back Light"
    )

    key_light_intensity: bpy.props.FloatProperty(
        name="Key Light Intensity",
        default=1000.0,
        min=0.0,
        description="Brightness of the Key Light"
    )

    fill_light_intensity: bpy.props.FloatProperty(
        name="Fill Light Intensity",
        default=500.0,
        min=0.0,
        description="Brightness of the Fill Light"
    )

    back_light_intensity: bpy.props.FloatProperty(
        name="Back Light Intensity",
        default=300.0,
        min=0.0,
        description="Brightness of the Back Light"
    )

    def execute(self, context):
        # Ensure viewport shading is set to Rendered
        area = next((a for a in context.screen.areas if a.type == 'VIEW_3D'), None)
        if area:
            shading = area.spaces.active.shading
            if shading.type in {'WIREFRAME', 'SOLID'}:
                shading.type = 'RENDERED'

        # Get the active object
        target_obj = context.active_object
        if not target_obj:
            self.report({'WARNING'}, "No active object selected.")
            return {'CANCELLED'}

        light_positions = [
            (5, 5, 5),    # Key Light
            (-5, 5, 2),   # Fill Light
            (0, -5, 5)    # Back Light
        ]

        light_colors = [
            self.key_light_color,
            self.fill_light_color,
            self.back_light_color
        ]

        light_intensities = [
            self.key_light_intensity,
            self.fill_light_intensity,
            self.back_light_intensity
        ]

        # Mevcut ışıkları temizle
        for light in bpy.data.lights:
            bpy.data.lights.remove(light, do_unlink=True)

        light_names = ["Key Light", "Fill Light", "Back Light"]

        for i in range(3):
            light = bpy.data.lights.new(name=light_names[i], type=self.light_type)
            light.energy = light_intensities[i]
            light.color = light_colors[i]

            light_obj = bpy.data.objects.new(light_names[i], light)
            context.collection.objects.link(light_obj)
            light_obj.location = light_positions[i]
            light_obj.show_name = True


            constraint = light_obj.constraints.new(type='TRACK_TO')
            constraint.target = target_obj
            constraint.track_axis = 'TRACK_NEGATIVE_Z'
            constraint.up_axis = 'UP_Y'

        self.report({'INFO'}, "3-point lighting setup created.")
        return {'FINISHED'}

classes = [LIGHT_OT_SetupOperator]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
    bpy.ops.light.setup_operator()
