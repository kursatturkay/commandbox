#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Delete Keyframes Keep Transforms. Deletes animation keyframes of all selected objects but keeps their current transform values
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class DeleteKeyframesKeepTransformsOperator(bpy.types.Operator):
    bl_idname = "object.delete_keyframes_keep_transforms"
    bl_label = "Delete Keyframes, Keep Transforms (All Selected)"
    bl_description = "Deletes animation keyframes of all selected objects but keeps their current transform values"

    def execute(self, context):
        # Seçili tüm objeleri al
        selected_objects = bpy.context.selected_objects

        # Her bir objeyi kontrol et
        for obj in selected_objects:
            # Eğer objede animasyon verisi varsa
            if obj.animation_data and obj.animation_data.action:
                # Şu anki transform değerlerini al
                current_location = obj.location.copy()
                current_rotation = obj.rotation_euler.copy()
                current_scale = obj.scale.copy()

                # Animasyon verisini al
                action = obj.animation_data.action

                # Keyframe'leri silmeden önce objeye mevcut transform değerlerini uygula
                for fcurve in action.fcurves:
                    if 'location' in fcurve.data_path:
                        fcurve.keyframe_points.insert(0, current_location[0])  # X
                        fcurve.keyframe_points.insert(0, current_location[1])  # Y
                        fcurve.keyframe_points.insert(0, current_location[2])  # Z
                    elif 'rotation' in fcurve.data_path:
                        fcurve.keyframe_points.insert(0, current_rotation[0])  # X
                        fcurve.keyframe_points.insert(0, current_rotation[1])  # Y
                        fcurve.keyframe_points.insert(0, current_rotation[2])  # Z
                    elif 'scale' in fcurve.data_path:
                        fcurve.keyframe_points.insert(0, current_scale[0])  # X
                        fcurve.keyframe_points.insert(0, current_scale[1])  # Y
                        fcurve.keyframe_points.insert(0, current_scale[2])  # Z

                # Keyframe'leri temizle
                obj.animation_data.action.fcurves.clear()

        self.report({'INFO'}, "Keyframes deleted for selected objects, but transforms were kept.")
        return {'FINISHED'}

# Operatörü kaydet
def register():
    bpy.utils.register_class(DeleteKeyframesKeepTransformsOperator)

def unregister():
    bpy.utils.unregister_class(DeleteKeyframesKeepTransformsOperator)

if __name__ == "__main__":
    register()
    bpy.ops.object.delete_keyframes_keep_transforms()