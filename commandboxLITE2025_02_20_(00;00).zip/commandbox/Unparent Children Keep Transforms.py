# https://www.youtube.com/watch?v=b0N9-lngOos
#Unparent Children Keep Transforms.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def unparent_children_without_transform():
    
    selected_object = bpy.context.active_object
    
    if selected_object and selected_object.children:
        for child in selected_object.children:
            
            world_location = child.matrix_world.translation.copy()
            world_rotation = child.matrix_world.to_euler()  
            world_scale = child.matrix_world.to_scale().copy()

            child.parent = None
            
            child.location = world_location
            child.rotation_euler = world_rotation
            child.scale = world_scale
            
            child.matrix_world = child.matrix_world  
        textinfo_=f"{len(selected_object.children)} children unparented with keeping transform values"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        
    else:
        textinfo_=f"selected object has no children to unparent or nothing selected"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

unparent_children_without_transform()