# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Resets / Clears Selected Armatures All Bone Transforms.
#Autorun=False
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

# Seçili nesneler arasında sadece armature'ları bul
selected_armatures = [obj for obj in bpy.context.selected_objects if obj.type == 'ARMATURE']

if selected_armatures:
# Eğer seçili armature varsa, Pose Mode'a geç
    for armature in selected_armatures:
        if armature.mode != 'POSE':
            bpy.context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='POSE')
            bpy.ops.pose.user_transforms_clear(only_selected=False)         

else:
    textinfo_="No any Armature Selected"
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)



