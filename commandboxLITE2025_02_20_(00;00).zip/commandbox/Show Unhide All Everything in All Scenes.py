#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Makes all objects visible in the active scene and view layer, focusing only on what the user is currently working with.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def unhide_all_objects():
    
    for obj in bpy.data.objects:
        
        obj.hide_viewport = False
        
        obj.hide_render = False
        obj.hide_set(False)


unhide_all_objects()

print("All objects are now visible.")
