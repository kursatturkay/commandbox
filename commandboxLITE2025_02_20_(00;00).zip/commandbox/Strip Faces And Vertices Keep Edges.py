#  https://www.youtube.com/watch?v=61dng-tY0rI
import bpy
import bmesh

# Aktif nesneyi al
obj = bpy.context.object

if obj and obj.type == 'MESH':
    # Edit moduna geç
    bpy.ops.object.mode_set(mode='EDIT')
    
    # Mesh verilerini düzenlemek için bmesh başlat
    bm = bmesh.from_edit_mesh(obj.data)
    
    # Seçili kenarları (edges) topla
    selected_edges = [e for e in bm.edges if e.select]
    
    # Klonlama: Seçili kenarları kopyala (Shift+D gibi davranış)
    cloned_verts = {}
    for edge in selected_edges:
        for vert in edge.verts:
            if vert not in cloned_verts:
                # Yeni vertex oluştur ve koordinatlarını aynı yap
                cloned_verts[vert] = bm.verts.new(vert.co)
    
    for edge in selected_edges:
        bm.edges.new([cloned_verts[vert] for vert in edge.verts])
    
    # Mesh'teki her şeyi sil (klonlanan hariç)
    all_verts = set(bm.verts)
    verts_to_keep = set(cloned_verts.values())
    verts_to_delete = all_verts - verts_to_keep
    
    bmesh.ops.delete(bm, geom=list(verts_to_delete), context='VERTS')
    
    # Bmesh'i güncelle ve değişiklikleri uygula
    bmesh.update_edit_mesh(obj.data)
    
    # Object moduna geç
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # Viewport'u güncelle
    bpy.context.view_layer.update()
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Select A Mesh or better Edges You wantto Keep.", duration=5)
