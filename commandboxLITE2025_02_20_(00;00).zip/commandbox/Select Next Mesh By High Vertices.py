    # 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① Selects Mesh by High Vertex Count in Scene

import bpy

# Scene'e özel bir custom property eklemek
if "last_selected_index_high" not in bpy.context.scene:
    bpy.context.scene["last_selected_index_high"] = -1

# Mesh objelerini listele ve vertex sayısına göre sırala
mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
sorted_meshes = sorted(mesh_objects, key=lambda obj: len(obj.data.vertices), reverse=True)

# Sayaç (last_selected_index_high) değeri
last_selected_index_high = bpy.context.scene["last_selected_index_high"]

# Tüm mesh'leri de-seç
bpy.ops.object.select_all(action='DESELECT')

# Seçilecek yeni objeyi belirle
if last_selected_index_high == -1:
    # İlk seçimde en yüksek vertex sayısına sahip objeyi seç
    next_selected_mesh = sorted_meshes[0]
    next_selected_index = 0
else:
    # Geçmiş seçimden sonra daha düşük vertex sayısına sahip objeyi seç
    next_selected_index = last_selected_index_high + 1
    if next_selected_index < len(sorted_meshes):
        next_selected_mesh = sorted_meshes[next_selected_index]
    else:
        # Daha düşük vertex sayısına sahip obje yoksa, en yüksek vertex sayısına sahip objeye geri dön
        next_selected_mesh = sorted_meshes[0]
        next_selected_index = 0

# Seçilen objeyi seç
next_selected_mesh.select_set(True)
bpy.context.view_layer.objects.active = next_selected_mesh

# Seçilen objeyi 'last_selected_index_high' olarak kaydet
bpy.context.scene["last_selected_index_high"] = next_selected_index

# Aktif 3D Viewport'ta seçilen objeyi görüntüle
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        # Aktif olan VIEW_3D region'ını bul
        for region in area.regions:
            if region.type == 'WINDOW':
                # Geçici context ile view_selected'ı çalıştır
                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
                break
