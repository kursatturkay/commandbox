# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
# Deletes All Geometry Nodes in Scene.


import bpy

# Track whether anything was deleted
modifiers_removed = 0
node_groups_removed = 0

# Remove Geometry Nodes modifiers from all objects in the file
for obj in bpy.data.objects:
    if obj.modifiers:
        for modifier in obj.modifiers:
            if modifier.type == 'NODES':  # Geometry Nodes modifier
                obj.modifiers.remove(modifier)
                modifiers_removed += 1

# Remove unused Geometry Nodes node groups
for node_tree in bpy.data.node_groups:
    if node_tree.bl_idname == 'GeometryNodeTree':  # Check if it's a Geometry Nodes tree
        bpy.data.node_groups.remove(node_tree, do_unlink=True)
        node_groups_removed += 1

# Output results
if modifiers_removed == 0 and node_groups_removed == 0:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Nothing was deleted.", duration=5)
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Deleted {modifiers_removed} Geometry Nodes modifiers.", duration=5)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Deleted {node_groups_removed} unused Geometry Nodes node groups.", duration=5)
