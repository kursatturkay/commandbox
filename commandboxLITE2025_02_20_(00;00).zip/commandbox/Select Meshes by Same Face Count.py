#https://www.youtube.com/watch?v=HCgtYPgYarg 
#Select Meshes by Same Face Count.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_select_same_face_count(bpy.types.Operator):
    """Select objects with the same face count"""
    bl_idname = "object.select_same_face_count"
    bl_label = "Select Same Face Count" 
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.object is not None and context.object.type == 'MESH')

    def execute(self, context):
        active_object = context.object
        if active_object is None or active_object.type != 'MESH':
            textinfo_ = "No active mesh object selected."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            return {'CANCELLED'}

        face_count = len(active_object.data.polygons)
        selected_count = 0

        for obj in bpy.context.view_layer.objects: 
            if obj.type == 'MESH' and obj != active_object:
                if len(obj.data.polygons) == face_count:
                    obj.select_set(True)
                    selected_count += 1
                else:
                    obj.select_set(False)  

        if selected_count > 0:
            textinfo_= f"Selected {selected_count} objects with {face_count} faces."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        else:
            textinfo_= "No objects found with the same face count."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}


def register():
    bpy.utils.register_class(OBJECT_OT_select_same_face_count)


def unregister():
    bpy.utils.unregister_class(OBJECT_OT_select_same_face_count)

if __name__ == "__main__":
    register()
    bpy.ops.object.select_same_face_count()