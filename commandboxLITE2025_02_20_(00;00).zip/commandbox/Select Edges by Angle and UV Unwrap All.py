# https://www.youtube.com/watch?v=ixyebNEiF8Q&t=204s
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Select Edges by Angle and UV Unwrap All.
bl_info = {
    "name": " Select Edges by Angle and UV Unwrap All",
    "blender": (4, 2, 2),
    "category": "Mesh",
}

import bpy
import bmesh
from math import radians
from bpy.props import FloatProperty

def select_edges_by_angle(context):
    obj = context.active_object
    angle_threshold = context.scene.angle_threshold

    if obj is None or obj.type != 'MESH':
        return

    
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='EDGE')  

    bm = bmesh.from_edit_mesh(obj.data)

    
    angle_radians = radians(angle_threshold)

    
    for vert in bm.verts:
        vert.select = False
    for edge in bm.edges:
        edge.select = False
    for face in bm.faces:
        face.select = False

    
    for edge in bm.edges:
        if not edge.is_boundary:
            faces = edge.link_faces
            if len(faces) == 2:  
                angle = faces[0].normal.angle(faces[1].normal)
                if angle > angle_radians:
                    edge.select = True

    
    bmesh.update_edit_mesh(obj.data)

class PANEL_PT_SelectEdgeByAngleAndUVUnwrapAll(bpy.types.Panel):
    """UI Panel for Select Edge by Angle and Unwrap All"""
    bl_label = "Select Edges by Angle and Unwrap All"
    bl_idname = "PANEL_PT_SelectEdgeByAngleAndUVUnwrapAll"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "angle_threshold", text="Angle Threshold")
        layout.separator(type="LINE")
        layout.operator("transform.select_uv_island_boundaries", text="Select UV Island Boundaries")
        layout.operator("transform.select_edges_by_seams", text="Select Edges By Seams")
        layout.operator("transform.apply_edge_seam", text="Apply Edge Seam")
        layout.operator("transform.clearseam_all", text="Clear Seam All")

class SCENE_OT_UpdateEdgeSelection(bpy.types.Operator):
    """Update edge selection when slider changes"""
    bl_idname = "scene.update_edge_selection"
    bl_label = "Update Edge Selection"

    def execute(self, context):
        select_edges_by_angle(context)
        return {'FINISHED'}

class TRANSFORM_OT_ApplyEdgeSeam(bpy.types.Operator):
    """Apply maximum edge seam to selected edges"""
    bl_idname = "transform.apply_edge_seam"
    bl_label = "Apply Edge Seam and Unwrap"

    def execute(self, context):
        obj = bpy.context.active_object

        bpy.ops.object.mode_set(mode='EDIT')

        bm = bmesh.from_edit_mesh(obj.data)

        selected_edges = [edge for edge in bm.edges if edge.select]

        for edge in bm.edges:
            edge.seam = False

        for edge in bm.edges:
            edge.select = edge in selected_edges  
            if edge.select:
                edge.seam = True

        bmesh.update_edit_mesh(obj.data)

        
        bpy.ops.mesh.select_all(action='DESELECT')  
        bpy.ops.mesh.select_mode(type='FACE')      
        bpy.ops.mesh.select_all(action='SELECT')   
        bpy.ops.uv.unwrap(method='ANGLE_BASED')    
        return {'FINISHED'}

class TRANSFORM_OT_ClearSeamAll(bpy.types.Operator):
    """Remove all edge creases from the mesh"""
    bl_idname = "transform.clearseam_all"
    bl_label = "clearseam All"

    def execute(self, context):
        
        obj = bpy.context.active_object
        
        if obj and obj.type == 'MESH':

            bpy.ops.object.mode_set(mode='EDIT')  # Edit moduna geç
            bpy.ops.mesh.select_mode(type='EDGE')  # Edge modunu etkinleştir
            bpy.ops.mesh.select_all(action='SELECT')  # Tüm kenarları seç

            bm = bmesh.from_edit_mesh(obj.data)

            for edge in bm.edges:
                edge.seam = False

            bmesh.update_edit_mesh(obj.data)

            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="All edge creases removed.", duration=5)

        return {'FINISHED'}

class TRANSFORM_OT_SelectUVIslandBoundaries(bpy.types.Operator):
    """Select edges at UV island boundaries"""
    bl_idname = "transform.select_uv_island_boundaries"
    bl_label = "Select UV Island Boundaries"

    def execute(self, context):
        obj = context.active_object

        if obj and obj.type == 'MESH':
            # Ensure the object is in edit mode
            bpy.ops.object.mode_set(mode='EDIT')

            # Create seams from UV islands
            bpy.ops.uv.seams_from_islands()

            # Switch to edge select mode
            bpy.ops.mesh.select_mode(type='EDGE')

            # Deselect all edges first
            bpy.ops.mesh.select_all(action='DESELECT')

            # Get the active object data in object mode to check for seams
            bpy.ops.object.mode_set(mode='OBJECT')

            # Iterate through the edges and select the ones marked as seams
            for edge in obj.data.edges:
                if edge.use_seam:  # Check if the edge is a seam
                    edge.select = True

            # Switch back to edit mode
            bpy.ops.object.mode_set(mode='EDIT')

            self.report({'INFO'}, "UV island boundary seams selected.")
        else:
            self.report({'WARNING'}, "Active object is not a mesh.")
        
        return {'FINISHED'}
        
def update_edge_selection(self, context):
    bpy.ops.scene.update_edge_selection()

classes = [
    PANEL_PT_SelectEdgeByAngleAndUVUnwrapAll,
    SCENE_OT_UpdateEdgeSelection,
    TRANSFORM_OT_ApplyEdgeSeam,
    TRANSFORM_OT_ClearSeamAll,
    TRANSFORM_OT_SelectUVIslandBoundaries
]

def register():
    bpy.types.Scene.angle_threshold = FloatProperty(
        name="Angle Threshold",
        description="The angle threshold in degrees",
        default=30.0,
        min=0.0,
        max=180.0,
        update=update_edge_selection
    )

    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.angle_threshold

# if __name__ == "__main__":
#     register()


def toggle():
    
    if hasattr(bpy.types, "PANEL_PT_SelectEdgeByAngleAndUVUnwrapAll"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        
        bpy.utils.unregister_class(bpy.types.PANEL_PT_SelectEdgeByAngleAndUVUnwrapAll)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
        register()
        bpy.ops.scene.update_edge_selection()


if __name__ == "__main__":
    toggle()

