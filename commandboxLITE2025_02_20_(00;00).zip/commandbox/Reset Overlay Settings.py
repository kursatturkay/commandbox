# Reset Viewport Overlay Settings When its getting confused.
import bpy

def reset_overlays():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
          
            space.overlay.show_overlays = True
            space.overlay.show_floor = True
            space.overlay.show_axis_x = True
            space.overlay.show_axis_y = True
            space.overlay.show_cursor = True
            space.overlay.show_outline_selected = True
            space.overlay.show_relationship_lines = True
            space.overlay.show_text = True
            space.overlay.show_extras = True
            space.overlay.show_object_origins = True
            space.overlay.show_object_origins_all = False
            space.overlay.show_annotation = True
            space.overlay.show_bones = True
            space.overlay.show_motion_paths = False

reset_overlays()
