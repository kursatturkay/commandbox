#https://www.youtube.com/watch?v=H2cAPNsjJAM
#Spherize Selected.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
import math
from mathutils import Vector
from bpy.props import FloatProperty

class SpherizeSelectedOperator(bpy.types.Operator):
    bl_idname = "mesh.spherize_selected"
    bl_label = "Spherize Selected"
    bl_options = {'REGISTER', 'UNDO'}
    
    factor: FloatProperty(
        name="Factor",
        description="Spherize factor",
        default=0.0,
        min=-2.0,
        max=2.0,
    )
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        
        # Edit mode'da BMesh oluştur
        bm = bmesh.from_edit_mesh(obj.data)
        
        # Seçili edge'leri al
        selected_edges = [e for e in bm.edges if e.select]
        if not selected_edges:
            return {'CANCELLED'}
            
        # Edge loop'daki vertexleri topla
        verts = []
        for edge in selected_edges:
            for vert in edge.verts:
                if vert not in verts:
                    verts.append(vert)
        
        # Merkez noktayı hesapla
        center = Vector((0, 0, 0))
        for v in verts:
            center += v.co
        center /= len(verts)
        
        # Ortalama yarıçap hesapla
        radius = 0
        for v in verts:
            radius += (v.co - center).length
        radius /= len(verts)
        
        # Vertexleri spherize et
        for v in verts:
            direction = (v.co - center).normalized()
            original_pos = v.co.copy()
            spherized_pos = center + (direction * radius)
            # Factor ile interpolate
            v.co = original_pos.lerp(spherized_pos, self.factor)
        
        # Mesh'i güncelle
        bmesh.update_edit_mesh(obj.data)
        return {'FINISHED'}


# Operator for toggling panel visibility
class SCENE_OT_toggle_spherize_selected_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_spherize_selected_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.spherize_selected_panel = not context.scene.spherize_selected_panel

        if(context.scene.spherize_selected_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class SpherizeSelectedPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_spherize_selected"
    bl_label = "Spherize Selected"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'
    
    @classmethod
    def poll(cls, context):
        
        return context.scene.spherize_selected_panel

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_spherize_selected_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.spherize_selected")

def register():
    bpy.utils.register_class(SpherizeSelectedOperator)
    bpy.utils.register_class(SpherizeSelectedPanel)
    bpy.utils.register_class(SCENE_OT_toggle_spherize_selected_panel)

    bpy.types.Scene.spherize_selected_panel = bpy.props.BoolProperty(
    default=False)

def unregister():
    bpy.utils.unregister_class(SpherizeSelectedOperator)
    bpy.utils.unregister_class(SpherizeSelectedPanel)
    bpy.utils.unregister_class(SCENE_OT_toggle_spherize_selected_panel)
    del bpy.types.Scene.spherize_selected_panel

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_spherize_selected_panel()