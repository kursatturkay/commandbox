import bpy, mathutils

#initialize rockshatter node group
def _rockshatter_node_group():
    rockshatter = bpy.data.node_groups.new(type = 'GeometryNodeTree', name = "RockShatter")

    rockshatter.color_tag = 'NONE'
    rockshatter.description = ""
    rockshatter.default_group_node_width = 140
    

    rockshatter.is_modifier = True

    #rockshatter interface
    #Socket Geometry
    geometry_socket = rockshatter.interface.new_socket(name = "Geometry", in_out='OUTPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    #Socket Geometry
    geometry_socket_1 = rockshatter.interface.new_socket(name = "Geometry", in_out='INPUT', socket_type = 'NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'


    #initialize rockshatter nodes
    #node Group Input
    group_input = rockshatter.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    #node Group Output
    group_output = rockshatter.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    #node Domain Size
    domain_size = rockshatter.nodes.new("GeometryNodeAttributeDomainSize")
    domain_size.label = "Dom"
    domain_size.name = "Domain Size"
    domain_size.component = 'POINTCLOUD'

    #node Repeat Input
    repeat_input = rockshatter.nodes.new("GeometryNodeRepeatInput")
    repeat_input.label = "RI"
    repeat_input.name = "Repeat Input"
    repeat_input.use_custom_color = True
    repeat_input.color = (0.61, 0.16, 0.18)
    #node Repeat Output
    repeat_output = rockshatter.nodes.new("GeometryNodeRepeatOutput")
    repeat_output.label = "RO"
    repeat_output.name = "Repeat Output"
    repeat_output.use_custom_color = True
    repeat_output.color = (0.61, 0.16, 0.18)
    repeat_output.active_index = 2
    repeat_output.inspection_index = 0
    repeat_output.repeat_items.clear()
    # Create item "Geometry"
    repeat_output.repeat_items.new('GEOMETRY', "Geometry")
    # Create item "Geo_original"
    repeat_output.repeat_items.new('GEOMETRY', "Geo_original")
    # Create item "Integer"
    repeat_output.repeat_items.new('INT', "Integer")

    #node Join Geometry.001
    join_geometry_001 = rockshatter.nodes.new("GeometryNodeJoinGeometry")
    join_geometry_001.label = "JG"
    join_geometry_001.name = "Join Geometry.001"

    #node Math
    math = rockshatter.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'
    math.use_clamp = False
    #Value_001
    math.inputs[1].default_value = 1.00

    #node Reroute.002
    reroute_002 = rockshatter.nodes.new("NodeReroute")
    reroute_002.name = "Reroute.002"
    reroute_002.socket_idname = "NodeSocketGeometry"
    #node Distribute Points on Faces
    distribute_points_on_faces = rockshatter.nodes.new("GeometryNodeDistributePointsOnFaces")
    distribute_points_on_faces.label = "DOF1_IO"
    distribute_points_on_faces.name = "Distribute Points on Faces"
    distribute_points_on_faces.use_custom_color = True
    distribute_points_on_faces.color = (0.04, 0.31, 0.61)
    distribute_points_on_faces.distribute_method = 'RANDOM'
    distribute_points_on_faces.use_legacy_normal = False
    #Selection
    distribute_points_on_faces.inputs[1].default_value = True
    #Density
    distribute_points_on_faces.inputs[4].default_value = 1
    #Seed
    distribute_points_on_faces.inputs[6].default_value = 0

    #node Scale Elements
    scale_elements = rockshatter.nodes.new("GeometryNodeScaleElements")
    scale_elements.label = "SE_IO"
    scale_elements.name = "Scale Elements"
    scale_elements.use_custom_color = True
    scale_elements.color = (0.04, 0.31, 0.61)
    scale_elements.domain = 'FACE'
    scale_elements.scale_mode = 'UNIFORM'
    #Selection
    scale_elements.inputs[1].default_value = True
    #Scale
    scale_elements.inputs[2].default_value = 0.9
    #Center
    scale_elements.inputs[3].default_value = (0.00, 0.00, 0.00)

    #node Repeat Input.001
    repeat_input_001 = rockshatter.nodes.new("GeometryNodeRepeatInput")
    repeat_input_001.label = "RI"
    repeat_input_001.name = "Repeat Input.001"
    repeat_input_001.use_custom_color = True
    repeat_input_001.color = (0.61, 0.16, 0.18)
    #node Repeat Output.001
    repeat_output_001 = rockshatter.nodes.new("GeometryNodeRepeatOutput")
    repeat_output_001.label = "RO"
    repeat_output_001.name = "Repeat Output.001"
    repeat_output_001.use_custom_color = True
    repeat_output_001.color = (0.61, 0.16, 0.18)
    repeat_output_001.active_index = 1
    repeat_output_001.inspection_index = 0
    repeat_output_001.repeat_items.clear()
    # Create item "Geometry"
    repeat_output_001.repeat_items.new('GEOMETRY', "Geometry")
    # Create item "Points"
    repeat_output_001.repeat_items.new('GEOMETRY', "Points")

    #node Sample Index
    sample_index = rockshatter.nodes.new("GeometryNodeSampleIndex")
    sample_index.name = "Sample Index"
    sample_index.clamp = False
    sample_index.data_type = 'FLOAT_VECTOR'
    sample_index.domain = 'POINT'

    #node Position
    position = rockshatter.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"

    #node Mesh Boolean
    mesh_boolean = rockshatter.nodes.new("GeometryNodeMeshBoolean")
    mesh_boolean.name = "Mesh Boolean"
    mesh_boolean.operation = 'DIFFERENCE'
    mesh_boolean.solver = 'EXACT'
    #Self Intersection
    mesh_boolean.inputs[2].default_value = False
    #Hole Tolerant
    mesh_boolean.inputs[3].default_value = True

    #node Transform Geometry
    transform_geometry = rockshatter.nodes.new("GeometryNodeTransform")
    transform_geometry.label = "TG"
    transform_geometry.name = "Transform Geometry"
    transform_geometry.mode = 'COMPONENTS'
    #Scale
    transform_geometry.inputs[3].default_value = (1.00, 50.00, 50.00)

    #node Sample Index.001
    sample_index_001 = rockshatter.nodes.new("GeometryNodeSampleIndex")
    sample_index_001.name = "Sample Index.001"
    sample_index_001.clamp = False
    sample_index_001.data_type = 'FLOAT_VECTOR'
    sample_index_001.domain = 'POINT'

    #node Pos
    pos = rockshatter.nodes.new("GeometryNodeInputPosition")
    pos.label = "Pos"
    pos.name = "Pos"

    #node Mix
    mix = rockshatter.nodes.new("ShaderNodeMix")
    mix.label = "Mix_IO"
    mix.name = "Mix"
    mix.use_custom_color = True
    mix.color = (0.04, 0.31, 0.61)
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'VECTOR'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.50

    #node Vector Math
    vector_math = rockshatter.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'SUBTRACT'

    #node Mesh Circle
    mesh_circle = rockshatter.nodes.new("GeometryNodeMeshCircle")
    mesh_circle.label = "MC"
    mesh_circle.name = "Mesh Circle"
    mesh_circle.fill_type = 'NGON'
    #Vertices
    mesh_circle.inputs[0].default_value = 5
    #Radius
    mesh_circle.inputs[1].default_value = 20.00

    #node Reroute.001
    reroute_001 = rockshatter.nodes.new("NodeReroute")
    reroute_001.name = "Reroute.001"
    reroute_001.socket_idname = "NodeSocketGeometry"
    #node Sample Nearest
    sample_nearest = rockshatter.nodes.new("GeometryNodeSampleNearest")
    sample_nearest.name = "Sample Nearest"
    sample_nearest.domain = 'POINT'

    #node Delete Geometry
    delete_geometry = rockshatter.nodes.new("GeometryNodeDeleteGeometry")
    delete_geometry.label = "remove closest"
    delete_geometry.name = "Delete Geometry"
    delete_geometry.domain = 'POINT'
    delete_geometry.mode = 'ALL'

    #node Compare.001
    compare_001 = rockshatter.nodes.new("FunctionNodeCompare")
    compare_001.name = "Compare.001"
    compare_001.data_type = 'INT'
    compare_001.mode = 'ELEMENT'
    compare_001.operation = 'EQUAL'

    #node Index
    index = rockshatter.nodes.new("GeometryNodeInputIndex")
    index.name = "Index"

    #node Math.001
    math_001 = rockshatter.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'SUBTRACT'
    math_001.use_clamp = False
    #Value_001
    math_001.inputs[1].default_value = 1.00

    #node Delete Geometry.001
    delete_geometry_001 = rockshatter.nodes.new("GeometryNodeDeleteGeometry")
    delete_geometry_001.label = "DG"
    delete_geometry_001.name = "Delete Geometry.001"
    delete_geometry_001.use_custom_color = True
    delete_geometry_001.color = (0.59, 0.17, 0.61)
    delete_geometry_001.domain = 'POINT'
    delete_geometry_001.mode = 'ALL'

    #node Compare.002
    compare_002 = rockshatter.nodes.new("FunctionNodeCompare")
    compare_002.name = "Compare.002"
    compare_002.data_type = 'INT'
    compare_002.mode = 'ELEMENT'
    compare_002.operation = 'EQUAL'

    #node Index.001
    index_001 = rockshatter.nodes.new("GeometryNodeInputIndex")
    index_001.name = "Index.001"

    #node Bounding Box
    bounding_box = rockshatter.nodes.new("GeometryNodeBoundBox")
    bounding_box.name = "Bounding Box"

    #node Vector Math.001
    vector_math_001 = rockshatter.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'SUBTRACT'

    #node Vector Math.002
    vector_math_002 = rockshatter.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'LENGTH'

    #node Vector Math.003
    vector_math_003 = rockshatter.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'LENGTH'

    #node Compare
    compare = rockshatter.nodes.new("FunctionNodeCompare")
    compare.name = "Compare"
    compare.data_type = 'FLOAT'
    compare.mode = 'ELEMENT'
    compare.operation = 'GREATER_THAN'

    #node Switch
    switch = rockshatter.nodes.new("GeometryNodeSwitch")
    switch.name = "Switch"
    switch.input_type = 'GEOMETRY'

    #node Align Rotation to Vector
    align_rotation_to_vector = rockshatter.nodes.new("FunctionNodeAlignRotationToVector")
    align_rotation_to_vector.name = "Align Rotation to Vector"
    align_rotation_to_vector.axis = 'Z'
    align_rotation_to_vector.pivot_axis = 'AUTO'
    #Rotation
    align_rotation_to_vector.inputs[0].default_value = (0.00, 0.00, 0.00)
    #Factor
    align_rotation_to_vector.inputs[1].default_value = 1.00

    #node Subdivide Mesh
    subdivide_mesh = rockshatter.nodes.new("GeometryNodeSubdivideMesh")
    subdivide_mesh.name = "Subdivide Mesh"
    #Level
    subdivide_mesh.inputs[1].default_value = 1


    #Process zone input Repeat Input
    repeat_input.pair_with_output(repeat_output)
    #Item_3
    repeat_input.inputs[3].default_value = 0


    #Process zone input Repeat Input.001
    repeat_input_001.pair_with_output(repeat_output_001)





    #Set locations
    group_input.location = (-366.93, 26.30)
    group_output.location = (2744.68, -36.47)
    domain_size.location = (751.07, -206.11)
    repeat_input.location = (1072.42, -168.13)
    repeat_output.location = (1921.95, 13.23)
    join_geometry_001.location = (1682.22, 133.11)
    math.location = (1657.24, -247.38)
    reroute_002.location = (584.62, 66.12)
    distribute_points_on_faces.location = (240.21, -300.74)
    scale_elements.location = (2232.82, -399.52)
    repeat_input_001.location = (573.90, 351.33)
    repeat_output_001.location = (2327.69, 371.93)
    sample_index.location = (1062.19, 162.09)
    position.location = (904.26, 274.67)
    mesh_boolean.location = (1962.03, 336.31)
    transform_geometry.location = (1681.09, 46.03)
    sample_index_001.location = (756.74, -3.38)
    pos.location = (521.14, -178.16)
    mix.location = (1348.24, -334.81)
    vector_math.location = (1276.68, 161.72)
    mesh_circle.location = (1430.29, -54.56)
    reroute_001.location = (1549.45, 311.75)
    sample_nearest.location = (898.23, 125.13)
    delete_geometry.location = (1966.72, 519.85)
    compare_001.location = (1770.82, 364.31)
    index.location = (1580.44, 368.20)
    math_001.location = (203.05, 520.39)
    delete_geometry_001.location = (342.64, 153.90)
    compare_002.location = (168.33, 77.81)
    index_001.location = (103.58, 188.66)
    bounding_box.location = (921.36, 549.46)
    vector_math_001.location = (1079.03, 568.97)
    vector_math_002.location = (1239.69, 566.13)
    vector_math_003.location = (1789.34, 572.30)
    compare.location = (1972.93, 708.80)
    switch.location = (2203.02, 677.52)
    align_rotation_to_vector.location = (1482.53, 197.46)
    subdivide_mesh.location = (2506.85, 301.04)

    #Set dimensions
    group_input.width, group_input.height = 140.00, 100.00
    group_output.width, group_output.height = 140.00, 100.00
    domain_size.width, domain_size.height = 143.87, 100.00
    repeat_input.width, repeat_input.height = 140.00, 100.00
    repeat_output.width, repeat_output.height = 140.00, 100.00
    join_geometry_001.width, join_geometry_001.height = 140.00, 100.00
    math.width, math.height = 140.00, 100.00
    reroute_002.width, reroute_002.height = 16.00, 100.00
    distribute_points_on_faces.width, distribute_points_on_faces.height = 170.00, 100.00
    scale_elements.width, scale_elements.height = 140.00, 100.00
    repeat_input_001.width, repeat_input_001.height = 140.00, 100.00
    repeat_output_001.width, repeat_output_001.height = 140.00, 100.00
    sample_index.width, sample_index.height = 140.00, 100.00
    position.width, position.height = 140.00, 100.00
    mesh_boolean.width, mesh_boolean.height = 140.00, 100.00
    transform_geometry.width, transform_geometry.height = 140.00, 100.00
    sample_index_001.width, sample_index_001.height = 140.00, 100.00
    pos.width, pos.height = 140.00, 100.00
    mix.width, mix.height = 140.00, 100.00
    vector_math.width, vector_math.height = 140.00, 100.00
    mesh_circle.width, mesh_circle.height = 140.00, 100.00
    reroute_001.width, reroute_001.height = 16.00, 100.00
    sample_nearest.width, sample_nearest.height = 140.00, 100.00
    delete_geometry.width, delete_geometry.height = 140.00, 100.00
    compare_001.width, compare_001.height = 140.00, 100.00
    index.width, index.height = 140.00, 100.00
    math_001.width, math_001.height = 140.00, 100.00
    delete_geometry_001.width, delete_geometry_001.height = 140.00, 100.00
    compare_002.width, compare_002.height = 140.00, 100.00
    index_001.width, index_001.height = 140.00, 100.00
    bounding_box.width, bounding_box.height = 140.00, 100.00
    vector_math_001.width, vector_math_001.height = 140.00, 100.00
    vector_math_002.width, vector_math_002.height = 140.00, 100.00
    vector_math_003.width, vector_math_003.height = 140.00, 100.00
    compare.width, compare.height = 140.00, 100.00
    switch.width, switch.height = 140.00, 100.00
    align_rotation_to_vector.width, align_rotation_to_vector.height = 140.00, 100.00
    subdivide_mesh.width, subdivide_mesh.height = 140.00, 100.00

    #initialize rockshatter links
    #reroute_002.Output -> domain_size.Geometry
    rockshatter.links.new(reroute_002.outputs[0], domain_size.inputs[0])
    #domain_size.Point Count -> repeat_input.Iterations
    rockshatter.links.new(domain_size.outputs[0], repeat_input.inputs[0])
    #group_input.Geometry -> repeat_input.Geo_original
    rockshatter.links.new(group_input.outputs[0], repeat_input.inputs[2])
    #repeat_input.Geometry -> join_geometry_001.Geometry
    rockshatter.links.new(repeat_input.outputs[1], join_geometry_001.inputs[0])
    #join_geometry_001.Geometry -> repeat_output.Geometry
    rockshatter.links.new(join_geometry_001.outputs[0], repeat_output.inputs[0])
    #repeat_input.Geo_original -> repeat_output.Geo_original
    rockshatter.links.new(repeat_input.outputs[2], repeat_output.inputs[1])
    #repeat_input.Integer -> math.Value
    rockshatter.links.new(repeat_input.outputs[3], math.inputs[0])
    #math.Value -> repeat_output.Integer
    rockshatter.links.new(math.outputs[0], repeat_output.inputs[2])
    #scale_elements.Geometry -> group_output.Geometry
    rockshatter.links.new(scale_elements.outputs[0], group_output.inputs[0])
    #group_input.Geometry -> distribute_points_on_faces.Mesh
    rockshatter.links.new(group_input.outputs[0], distribute_points_on_faces.inputs[0])
    #distribute_points_on_faces.Points -> reroute_002.Input
    rockshatter.links.new(distribute_points_on_faces.outputs[0], reroute_002.inputs[0])
    #repeat_output.Geometry -> scale_elements.Geometry
    rockshatter.links.new(repeat_output.outputs[0], scale_elements.inputs[0])
    #reroute_001.Output -> mesh_boolean.Mesh 1
    rockshatter.links.new(reroute_001.outputs[0], mesh_boolean.inputs[0])
    #sample_index.Value -> mix.A
    rockshatter.links.new(sample_index.outputs[0], mix.inputs[4])
    #position.Position -> sample_index.Value
    rockshatter.links.new(position.outputs[0], sample_index.inputs[1])
    #transform_geometry.Geometry -> mesh_boolean.Mesh 2
    rockshatter.links.new(transform_geometry.outputs[0], mesh_boolean.inputs[1])
    #mix.Result -> transform_geometry.Translation
    rockshatter.links.new(mix.outputs[1], transform_geometry.inputs[1])
    #sample_index.Value -> vector_math.Vector
    rockshatter.links.new(sample_index.outputs[0], vector_math.inputs[1])
    #sample_index_001.Value -> mix.B
    rockshatter.links.new(sample_index_001.outputs[0], mix.inputs[5])
    #sample_index_001.Value -> vector_math.Vector
    rockshatter.links.new(sample_index_001.outputs[0], vector_math.inputs[0])
    #pos.Position -> sample_index_001.Value
    rockshatter.links.new(pos.outputs[0], sample_index_001.inputs[1])
    #mesh_circle.Mesh -> transform_geometry.Geometry
    rockshatter.links.new(mesh_circle.outputs[0], transform_geometry.inputs[0])
    #repeat_input_001.Geometry -> reroute_001.Input
    rockshatter.links.new(repeat_input_001.outputs[1], reroute_001.inputs[0])
    #repeat_input_001.Points -> sample_index.Geometry
    rockshatter.links.new(repeat_input_001.outputs[2], sample_index.inputs[0])
    #sample_nearest.Index -> sample_index.Index
    rockshatter.links.new(sample_nearest.outputs[0], sample_index.inputs[2])
    #repeat_input_001.Points -> sample_nearest.Geometry
    rockshatter.links.new(repeat_input_001.outputs[2], sample_nearest.inputs[0])
    #sample_index_001.Value -> sample_nearest.Sample Position
    rockshatter.links.new(sample_index_001.outputs[0], sample_nearest.inputs[1])
    #repeat_input_001.Points -> delete_geometry.Geometry
    rockshatter.links.new(repeat_input_001.outputs[2], delete_geometry.inputs[0])
    #compare_001.Result -> delete_geometry.Selection
    rockshatter.links.new(compare_001.outputs[0], delete_geometry.inputs[1])
    #index.Index -> compare_001.A
    rockshatter.links.new(index.outputs[0], compare_001.inputs[2])
    #sample_nearest.Index -> compare_001.B
    rockshatter.links.new(sample_nearest.outputs[0], compare_001.inputs[3])
    #delete_geometry.Geometry -> repeat_output_001.Points
    rockshatter.links.new(delete_geometry.outputs[0], repeat_output_001.inputs[1])
    #math_001.Value -> repeat_input_001.Iterations
    rockshatter.links.new(math_001.outputs[0], repeat_input_001.inputs[0])
    #delete_geometry_001.Geometry -> repeat_input_001.Points
    rockshatter.links.new(delete_geometry_001.outputs[0], repeat_input_001.inputs[2])
    #compare_002.Result -> delete_geometry_001.Selection
    rockshatter.links.new(compare_002.outputs[0], delete_geometry_001.inputs[1])
    #index_001.Index -> compare_002.B
    rockshatter.links.new(index_001.outputs[0], compare_002.inputs[3])
    #repeat_input_001.Geometry -> bounding_box.Geometry
    rockshatter.links.new(repeat_input_001.outputs[1], bounding_box.inputs[0])
    #bounding_box.Min -> vector_math_001.Vector
    rockshatter.links.new(bounding_box.outputs[1], vector_math_001.inputs[0])
    #vector_math_001.Vector -> vector_math_002.Vector
    rockshatter.links.new(vector_math_001.outputs[0], vector_math_002.inputs[0])
    #vector_math.Vector -> vector_math_003.Vector
    rockshatter.links.new(vector_math.outputs[0], vector_math_003.inputs[0])
    #vector_math_003.Value -> compare.B
    rockshatter.links.new(vector_math_003.outputs[1], compare.inputs[1])
    #bounding_box.Max -> vector_math_001.Vector
    rockshatter.links.new(bounding_box.outputs[2], vector_math_001.inputs[1])
    #compare.Result -> switch.Switch
    rockshatter.links.new(compare.outputs[0], switch.inputs[0])
    #repeat_input_001.Geometry -> switch.False
    rockshatter.links.new(repeat_input_001.outputs[1], switch.inputs[1])
    #mesh_boolean.Mesh -> switch.True
    rockshatter.links.new(mesh_boolean.outputs[0], switch.inputs[2])
    #switch.Output -> repeat_output_001.Geometry
    rockshatter.links.new(switch.outputs[0], repeat_output_001.inputs[0])
    #vector_math_002.Value -> compare.A
    rockshatter.links.new(vector_math_002.outputs[1], compare.inputs[0])
    #repeat_input.Geo_original -> repeat_input_001.Geometry
    rockshatter.links.new(repeat_input.outputs[2], repeat_input_001.inputs[1])
    #repeat_input.Integer -> sample_index_001.Index
    rockshatter.links.new(repeat_input.outputs[3], sample_index_001.inputs[2])
    #reroute_002.Output -> sample_index_001.Geometry
    rockshatter.links.new(reroute_002.outputs[0], sample_index_001.inputs[0])
    #domain_size.Point Count -> math_001.Value
    rockshatter.links.new(domain_size.outputs[0], math_001.inputs[0])
    #reroute_002.Output -> delete_geometry_001.Geometry
    rockshatter.links.new(reroute_002.outputs[0], delete_geometry_001.inputs[0])
    #repeat_input.Integer -> compare_002.A
    rockshatter.links.new(repeat_input.outputs[3], compare_002.inputs[2])
    #vector_math.Vector -> align_rotation_to_vector.Vector
    rockshatter.links.new(vector_math.outputs[0], align_rotation_to_vector.inputs[2])
    #align_rotation_to_vector.Rotation -> transform_geometry.Rotation
    rockshatter.links.new(align_rotation_to_vector.outputs[0], transform_geometry.inputs[2])
    #repeat_output_001.Geometry -> subdivide_mesh.Mesh
    rockshatter.links.new(repeat_output_001.outputs[0], subdivide_mesh.inputs[0])
    #subdivide_mesh.Mesh -> join_geometry_001.Geometry
    rockshatter.links.new(subdivide_mesh.outputs[0], join_geometry_001.inputs[0])
    return rockshatter

rockshatter = _rockshatter_node_group()

