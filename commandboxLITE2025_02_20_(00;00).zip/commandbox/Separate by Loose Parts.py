#https://www.youtube.com/watch?v=7l3fyNRagfU

import bpy

selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']

for obj in selected_objects:
    
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')  
    bpy.ops.mesh.separate(type='LOOSE')  
    bpy.ops.object.mode_set(mode='OBJECT')

# Pivotları ayarla
    bpy.context.view_layer.objects.active = obj
    obj.select_set(True)
    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
    obj.select_set(False)


    
