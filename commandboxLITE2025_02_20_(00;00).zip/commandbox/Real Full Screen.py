# https://www.youtube.com/watch?v=ixyebNEiF8Q
#① Run Command activates Shortcuts per session    ② Ctrl+Shift+Alt+Z = Toggle Real Full Screen    ③ Ctrl+Shift+NUMPAD_MINUS / PLUS = Scale UI
#autorun=True

bl_info = {
    "name": "Real Full Screen and UI Scale Adjuster",
    "blender": (4, 3, 0),
    "category": 'Fables Alive Games',
    "version": (12, 12, 2024),
    "description": "Toggles fullscreen , adjusts UI scale",
    "author": "Fables Alive Games",
    "support": "COMMUNITY"
}

import bpy

class RealFullScreenPreferences(bpy.types.AddonPreferences):

    bl_idname = __name__

    def draw(self, context):
        layout = self.layout

        # Panel başlığı
        layout.label(text="Keyboard Shortcuts")

        # İki etiket ekliyoruz
        layout.label(text="Toggle Real Fullscreen  :  Ctrl + Shift + Alt+  Z",icon="INFO")
        layout.label(text="Adjust UI scale     :  Ctrl + Shift + (Numpad +/-)",icon="INFO")
        
# Fullscreen Toggle Operator
class WM_OT_FullscreenToggle(bpy.types.Operator):
    bl_idname = "wm.realfullscreen_toggle"
    bl_label = "Real Fullscreen Toggle"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.wm.window_fullscreen_toggle()
        bpy.ops.screen.screen_full_area(use_hide_panels=True)

        textinfo_='Ctrl + Shift + Z : Toggle Real Full Screen'
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}

# UI Scale Adjuster Operator
class WM_OT_UI_Scale_Adjust(bpy.types.Operator):
    bl_idname = "wm.realui_scale_adjust"
    bl_label = "Real Adjust UI Scale"
    bl_options = {'REGISTER', 'UNDO'}
    
    increase: bpy.props.BoolProperty(options={'HIDDEN'})

    def execute(self, context):
        current_scale = bpy.context.preferences.view.ui_scale
        if self.increase:
            new_scale = min(current_scale + 0.05, 3.0)
        else:
            new_scale = max(current_scale - 0.05, 0.8)
        bpy.context.preferences.view.ui_scale = new_scale

        textinfo_= f"UI Scale set to {new_scale:.2f}"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}

def register_keymaps():
    wm = bpy.context.window_manager
    keyconfig = wm.keyconfigs.addon
    if keyconfig:
        keymap = keyconfig.keymaps.new(name="Window", space_type="EMPTY")

        # Fullscreen toggle shortcut
        keymap.keymap_items.new("wm.realfullscreen_toggle", 'Z', 'PRESS', ctrl=True, alt=True, shift=True)

        # UI Scale Adjust shortcuts
        kmi_increase = keymap.keymap_items.new("wm.realui_scale_adjust", 'NUMPAD_PLUS', 'PRESS', ctrl=True,alt=True, shift=True)
        kmi_increase.properties.increase = True

        kmi_decrease = keymap.keymap_items.new("wm.realui_scale_adjust", 'NUMPAD_MINUS', 'PRESS', ctrl=True, alt=True,shift=True)
        kmi_decrease.properties.increase = False

def unregister_keymaps():
    wm = bpy.context.window_manager
    keyconfig = wm.keyconfigs.addon
    if keyconfig:
        keymap = keyconfig.keymaps.get("Window")
        if keymap:
            for kmi in keymap.keymap_items:
                if kmi.idname in {"wm.realfullscreen_toggle", "wm.realui_scale_adjust"}:
                    keymap.keymap_items.remove(kmi)

def register():
    bpy.utils.register_class(RealFullScreenPreferences)
    bpy.utils.register_class(WM_OT_FullscreenToggle)
    bpy.utils.register_class(WM_OT_UI_Scale_Adjust)
    register_keymaps()

def unregister():
    unregister_keymaps()
    bpy.utils.unregister_class(WM_OT_UI_Scale_Adjust)
    bpy.utils.unregister_class(WM_OT_FullscreenToggle)
    bpy.utils.unregister_class(RealFullScreenPreferences)

if __name__ == "__main__":
    register()