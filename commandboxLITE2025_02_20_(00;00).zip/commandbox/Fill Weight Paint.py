# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Fill Weight Paint for active Vertex group (Vertex Groups are same with bone names by default)
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_fill_weight_paint(bpy.types.Operator):
    bl_idname = "paint.fill_weight_paint"  
    bl_label = "Fill Weight Paint"  
    bl_options = {'REGISTER', 'UNDO'}  

    def execute(self, context):
        obj = bpy.context.active_object
        if obj and obj.type == 'MESH':
            mesh = obj.data

            # Aktif vertex grubunun adı
            active_group = obj.vertex_groups.active

            if active_group:

                for vert in mesh.vertices:
                    for vertGroup in vert.groups:
                        if vertGroup.group == active_group.index:
                            vertGroup.weight = 1.0
                textinfo_ = f"Weight Paint set to 1 for group: {active_group.name}"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'FINISHED'}
            else:
                textinfo_ = "No Active Vertex Group Selected"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'CANCELLED'}

def register():
    bpy.utils.register_class(OBJECT_OT_fill_weight_paint)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_fill_weight_paint)

if __name__ == "__main__":
    register()
    bpy.ops.paint.fill_weight_paint()
