import bpy

class RenameSingleBonePopup(bpy.types.Operator):
    bl_idname = "object.rename_single_bone_popup"
    bl_label = "Rename Bone"
    
    bone_name: bpy.props.StringProperty(name="Bone Name", default="Bone_")
    bone_index: bpy.props.IntProperty(name="Bone Index")  # Kemik indexi, sıralama için kullanılacak

    def execute(self, context):
        armature = context.object  # Seçili objeyi kullanıyoruz
        bone = armature.data.bones[self.bone_index]
        # Kemik adını yeniden adlandır
        bone.name = self.bone_name
        return {'FINISHED'}

    def invoke(self, context, event):
        # Popup penceresini açmak için kullanılır
        context.window_manager.invoke_props_dialog(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'RET':
            # Enter tuşuna basıldığında pencereyi kapat
            return self.execute(context)
        elif event.type == 'ESC':
            # ESC tuşuna basıldığında pencereyi kapat
            return {'CANCELLED'}
        
        return {'RUNNING_MODAL'}


class RenameBonesForArmatureOperator(bpy.types.Operator):
    bl_idname = "object.rename_bones_for_armature"
    bl_label = "Rename Bones for Armature"

    def execute(self, context):
        # Seçili armatureyi kontrol et
        armatures = [obj for obj in bpy.context.selected_objects if obj.type == 'ARMATURE']
        for armature in armatures:
            # Armature içindeki tüm kemikleri sırasıyla işleyip popup aç
            for i, bone in enumerate(armature.data.bones):
                # Her kemik için ayrı ayrı popup aç
                bpy.ops.object.rename_single_bone_popup('INVOKE_DEFAULT', 
                    bone_index=i, 
                    bone_name=bone.name)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(RenameSingleBonePopup)
    bpy.utils.register_class(RenameBonesForArmatureOperator)
    # Script çalıştırıldığında hemen popup açılacak
    bpy.ops.object.rename_bones_for_armature('INVOKE_DEFAULT')

def unregister():
    bpy.utils.unregister_class(RenameSingleBonePopup)
    bpy.utils.unregister_class(RenameBonesForArmatureOperator)

if __name__ == "__main__":
    register()
