#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
# Ensures all objects in the scene, including those not currently visible, are made visible in both the viewport and render
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def unhide_all_objects():
    
    for obj in bpy.context.view_layer.objects:
        
        obj.hide_set(False)
        
        obj.hide_render = False


unhide_all_objects()

print("All objects are now visible.")
