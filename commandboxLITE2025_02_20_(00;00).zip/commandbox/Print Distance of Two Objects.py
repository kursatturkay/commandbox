# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#2nd line as description for Print Distance of Two Objects.
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 

import bpy
import math

# import os

# import sys


# current_dir = os.path.dirname(__file__)

# if current_dir not in sys.path:
#     sys.path.append(current_dir)

# import _modal_draw_operator

# if not hasattr(_modal_draw_operator, 'is_registered') or not _modal_draw_operator.is_registered:
#     _modal_draw_operator.register()
#     _modal_draw_operator.is_registered = True

# Get the selected objects
selected_objects = bpy.context.selected_objects

# Check if exactly two objects are selected
if len(selected_objects) == 2:
    # Get the locations of the objects
    obj1_location = selected_objects[0].location
    obj2_location = selected_objects[1].location
    
    # Calculate the distance
    distance = (obj1_location - obj2_location).length
    
    # Print the distance
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=f"Distance between {selected_objects[0].name} and {selected_objects[1].name} is: {distance:.2f} units")
    #bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Distance between selected objects: {distance:.2f} units", duration=5)
else:
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="Please select exactly two objects.")
    #bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select exactly two objects.", duration=5)







#  