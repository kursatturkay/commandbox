# Deselects All, Selects and Focuses to Only Objects NOT Type of Meshes. But All Other Kind Of Objects
import bpy

def hide_meshes_and_focus():
    bpy.ops.object.select_all(action='DESELECT')
    
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.hide_set(True)
        else:
            obj.hide_set(False)
            obj.select_set(True)

    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'WINDOW':
                    with bpy.context.temp_override(area=area, region=region):
                        bpy.ops.view3d.view_selected(use_all_regions=False)
                    return

for obj in bpy.data.objects:
    obj.hide_set(False)

hide_meshes_and_focus()
