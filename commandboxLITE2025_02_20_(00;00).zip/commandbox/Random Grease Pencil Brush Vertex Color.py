# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Random Grease Pencil Brush Vertex Color.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import random

# Renk paletini oluştur
colors = [
    (0, 0, 0),          # Siyah
    (1, 1, 1),          # Beyaz
    (0.5, 0.5, 0.5),    # Gri
    (0.529, 0.808, 0.922),  # Gökyüzü mavisi
    (0.0, 0.467, 0.714),  # Deniz Mavisi
    (0.710, 0.592, 0.839),  # Lavanta
    (0.961, 0.961, 0.863),  # Bej
    (1.0, 0.435, 0.0),      # Turuncu
    (0.173, 0.419, 0.184),  # Koyu Yeşil
    (0.0, 0.2, 0.4),        # Koyu Mavi
    (1.0, 0.843, 0.0),      # Altın Sarısı
]

# Aktif Grease Pencil objesini al
grease_pencil_obj = bpy.context.active_object

# Eğer aktif obje Grease Pencil değilse, işlem yapma
if grease_pencil_obj and grease_pencil_obj.type == 'GREASEPENCIL':
    # Renk modunu 'VERTEXCOLOR' olarak ayarla (boyama işlemi için)
    bpy.context.scene.tool_settings.gpencil_paint.color_mode = 'VERTEXCOLOR'
    
    # Renk paletinden rastgele bir renk seç
    selected_color = random.choice(colors)
    
    # Seçilen rengi boya için ayarla
    bpy.context.tool_settings.gpencil_paint.brush.color = selected_color
    
    print(f"Yeni boya rengi seçildi: {selected_color}")
else:
    print("Aktif obje GREASEPENCIL değil!")
