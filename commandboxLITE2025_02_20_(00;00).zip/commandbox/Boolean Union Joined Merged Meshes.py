#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Boolean Union Joined Merged Meshes. Also Unions 1 object that have loose (joined) parts
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_separate_and_boolean_union(bpy.types.Operator):
    """Separate all selected meshes and apply boolean union"""
    bl_idname = "object.separate_boolean_union"
    bl_label = "Separate Loose Parts & Boolean Union"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not selected_objects:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        separated_objects = []

        # Seçili tüm mesh nesneleri için "Separate by Loose Parts" işlemi yap
        for obj in selected_objects:
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Seperate sonrası tüm yeni mesh objelerini tekrar seç
        separated_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        if len(separated_objects) < 2:
            self.report({'WARNING'}, "At least two separate meshes are required")
            return {'CANCELLED'}

        # Boolean Union işlemi için ilk objeyi aktif yap
        active_obj = context.view_layer.objects.active
        if active_obj not in separated_objects:
            active_obj = separated_objects[0]
            context.view_layer.objects.active = active_obj
        
        separated_objects.remove(active_obj)

        # Boolean işlemi uygula
        for obj in separated_objects:
            bool_mod = active_obj.modifiers.new(name="Boolean", type='BOOLEAN')
            bool_mod.operation = 'UNION'
            bool_mod.object = obj
            bpy.ops.object.modifier_apply(modifier=bool_mod.name)
            
            # Birleşen objeyi sil
            bpy.data.objects.remove(obj, do_unlink=True)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_separate_and_boolean_union)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_separate_and_boolean_union)

if __name__ == "__main__":
    register()

    bpy.ops.object.separate_boolean_union()