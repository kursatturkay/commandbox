# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggles a panel in Blender's "Command Box" tab to toggle the selectability of objects by their type (e.g., MESH, LIGHT, CAMERA) using checkboxes.
    
import bpy

class OBJECT_PT_ToggleSelectablePanel(bpy.types.Panel):
    """Panel for toggling selectable properties of objects"""
    bl_label = "Toggle Selectable Panel"
    bl_idname = "OBJECT_PT_ToggleSelectablePanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Command Box"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Toggle Selectable by Object Type:")

        
        object_types = ['MESH', 'LIGHT', 'CAMERA', 'CURVE', 'EMPTY', 'ARMATURE', 'LATTICE', 'TEXT','GREASEPENCIL','SURFACE', 'META', 'SPEAKER', 'LIGHT_PROBE', 'VOLUME']

        
        for obj_type in object_types:
            property_name = f"toggle_selectable_{obj_type.lower()}"
            if not hasattr(context.scene, property_name):
                
                setattr(context.scene, property_name, bpy.props.BoolProperty(
                    name=f"Toggle {obj_type}",
                    description=f"Toggle selectable for {obj_type} objects",
                    default=True
                ))
            
            layout.prop(context.scene, property_name, text=obj_type)

        
        layout.operator("object.toggle_selectable_by_type", text="Apply All")



class OBJECT_OT_ToggleSelectableByType(bpy.types.Operator):
    """Toggle selectable property for objects by type"""
    bl_idname = "object.toggle_selectable_by_type"
    bl_label = "Toggle Selectable by Type"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        for obj in bpy.data.objects:
            obj_type = obj.type.lower()
            toggle_property = f"toggle_selectable_{obj_type}"
            if hasattr(context.scene, toggle_property):
                toggle_value = getattr(context.scene, toggle_property)
                obj.hide_select = not toggle_value
        
        return {'FINISHED'}



def register():
    
    bpy.utils.register_class(OBJECT_PT_ToggleSelectablePanel)
    bpy.utils.register_class(OBJECT_OT_ToggleSelectableByType)

    
    object_types = ['MESH', 'LIGHT', 'CAMERA', 'CURVE', 'EMPTY', 'ARMATURE', 'LATTICE', 'TEXT','GREASEPENCIL', 'SURFACE', 'META', 'SPEAKER', 'LIGHT_PROBE', 'VOLUME']
    for obj_type in object_types:
        property_name = f"toggle_selectable_{obj_type.lower()}"
        if not hasattr(bpy.types.Scene, property_name):
            
            setattr(bpy.types.Scene, property_name, bpy.props.BoolProperty(
                name=f"Toggle {obj_type}",
                description=f"Toggle selectable for {obj_type} objects",
                default=True
            ))



def unregister():
    
    bpy.utils.unregister_class(OBJECT_PT_ToggleSelectablePanel)
    bpy.utils.unregister_class(OBJECT_OT_ToggleSelectableByType)

    
    object_types = ['MESH', 'LIGHT', 'CAMERA', 'CURVE', 'EMPTY', 'ARMATURE', 'LATTICE', 'TEXT', 'GREASEPENCIL','SURFACE', 'META', 'SPEAKER', 'LIGHT_PROBE', 'VOLUME']
    for obj_type in object_types:
        property_name = f"toggle_selectable_{obj_type.lower()}"
        if hasattr(bpy.types.Scene, property_name):
            delattr(bpy.types.Scene, property_name)


# if __name__ == "__main__":
#     register()

def toggle():
    
    if hasattr(bpy.types, "OBJECT_PT_ToggleSelectablePanel"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented  
        bpy.utils.unregister_class(bpy.types.OBJECT_PT_ToggleSelectablePanel)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
        register()

# İlk çalıştırma (register yapılacak)
if __name__ == "__main__":
    toggle()
