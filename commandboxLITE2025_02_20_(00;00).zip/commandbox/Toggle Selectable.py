# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggles "selectable" for selected objects, or makes all objects selectable if none are selected.
    
import bpy

# Seçili nesneleri alın
selected_objects = bpy.context.selected_objects

if selected_objects:
    # Seçili nesnelerin selectable özelliğini toggle et
    for obj in selected_objects:
        obj.hide_select = not obj.hide_select
else:
    # Hiçbir şey seçili değilse, tüm nesneleri selectable yap
    for obj in bpy.data.objects:
        obj.hide_select = False
