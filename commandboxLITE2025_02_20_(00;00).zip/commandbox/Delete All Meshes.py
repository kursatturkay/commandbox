import bpy

# Mesh olmayan tüm objeleri sil komutu
def delete_non_mesh_objects():
    # Mesh olmayan tüm objeleri sil
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            bpy.data.objects.remove(obj, do_unlink=True)

# Komutu çalıştırmak için:
delete_non_mesh_objects()
#Delete Non Mesh Objs
