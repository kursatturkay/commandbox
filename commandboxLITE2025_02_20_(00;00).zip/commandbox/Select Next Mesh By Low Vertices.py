# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① Selects Mesh by Low Vertex Count in Scene

import bpy

if "last_selected_index_low" not in bpy.context.scene:
    bpy.context.scene["last_selected_index_low"] = -1

mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
sorted_meshes = sorted(mesh_objects, key=lambda obj: len(obj.data.vertices))

last_selected_index_low = bpy.context.scene["last_selected_index_low"]

bpy.ops.object.select_all(action='DESELECT')

if last_selected_index_low == -1:

    next_selected_mesh = sorted_meshes[0]
    next_selected_index = 0

else:
    next_selected_index = last_selected_index_low + 1
    if next_selected_index < len(sorted_meshes):
        next_selected_mesh = sorted_meshes[next_selected_index]
    else:

        next_selected_mesh = sorted_meshes[0]
        next_selected_index = 0

next_selected_mesh.select_set(True)
bpy.context.view_layer.objects.active = next_selected_mesh

bpy.context.scene["last_selected_index_low"] = next_selected_index

for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':

        for region in area.regions:
            if region.type == 'WINDOW':

                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
                break
