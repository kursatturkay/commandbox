# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Cameras Visibility.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

# import bpy


# for obj in bpy.data.objects:
#     if obj.type == 'CAMERA':  
        
#         current_visibility = obj.hide_get()  
#         obj.hide_set(not current_visibility)  
#         print(f"Toggled visibility for camera: {obj.name}")

import bpy


for obj in bpy.context.view_layer.objects:
    if obj.type == 'CAMERA':  
        
        current_visibility = obj.hide_viewport  
        obj.hide_viewport = not current_visibility  
        print(f"Toggled visibility for camera: {obj.name}")
