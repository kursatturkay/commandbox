import bpy

def cycle_armature_display_as():
    # Mevcut seçenekler
    display_modes = ['OCTAHEDRAL', 'STICK', 'BBONE', 'ENVELOPE', 'WIRE']
    
    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE':  # Sadece Armature tipindeki nesneleri seç
            armature = obj.data     # Nesnenin datablock'unu al
            current_mode = armature.display_type

            # Geçerli modun index'ini bul
            if current_mode in display_modes:
                current_index = display_modes.index(current_mode)
            else:
                current_index = -1

            # Döngüsel olarak bir sonraki modu al
            next_index = (current_index + 1) % len(display_modes)
            armature.display_type = display_modes[next_index]
            
            # Nesne adını yazdır
            textinfo_ = f"{obj.name} Display Type cycled to: {armature.display_type}"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

cycle_armature_display_as()

# def cycle_armature_display_as():
#     # Mevcut seçenekler
#     display_modes = ['OCTAHEDRAL', 'STICK', 'BBONE', 'ENVELOPE', 'WIRE']
    
#     for armature in bpy.data.armatures:
#         current_mode = armature.display_type

#         # Geçerli modun index'ini bul
#         if current_mode in display_modes:
#             current_index = display_modes.index(current_mode)
#         else:
#             current_index = -1

#         # Döngüsel olarak bir sonraki modu al
#         next_index = (current_index + 1) % len(display_modes)
#         armature.display_type = display_modes[next_index]
        
#         textinfo_=f"{armature.} Display Type cycled to: {armature.display_type}"
#         bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

# cycle_armature_display_as()
