# https://www.youtube.com/watch?v=RxjwS8TlJlc
#Set Pivot Origin To Top.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh

def set_origin_to_top_vertex_without_moving():
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            # Nesneyi aktif yap
            bpy.context.view_layer.objects.active = obj
            
            # Edit mode'a geç
            bpy.ops.object.mode_set(mode='EDIT')
            
            # BMesh veri yapısını oluştur
            bm = bmesh.from_edit_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            
            # Vertex'lerin dünya uzayındaki Z koordinatlarını al
            world_coords = [obj.matrix_world @ v.co for v in bm.verts]
            max_z = max(coord.z for coord in world_coords)  # En yüksek Z koordinatını bul
            
            # Nesneyi OBJECT moduna geri al
            bpy.ops.object.mode_set(mode='OBJECT')
            
            # Cursor'ı en üst noktaya taşı
            bpy.context.scene.cursor.location = (obj.location.x, obj.location.y, max_z)
            
            # Orijini Cursor'a taşı
            bpy.ops.object.origin_set(type='ORIGIN_CURSOR')
            
            # Nesne yerinde kalsın diye pivot taşındıktan sonra eski konuma geri taşı
            obj.location.z += (max_z - obj.location.z)

# Fonksiyonu çalıştır
set_origin_to_top_vertex_without_moving()
