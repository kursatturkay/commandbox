import bpy

#usage:
#    bpy.ops.view3d.toggle_n_panel_command_box()
#    layout.operator("view3d.toggle_n_panel_command_box")

class VIEW3D_OT_toggle_n_panel_and_set_tab(bpy.types.Operator):
    """N Panel'i aç ve 'Command Box' sekmesini etkinleştir"""
    bl_idname = "view3d.toggle_n_panel_command_box"
    bl_label = "Toggle N Panel & Command Box"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        category = "Command Box"
        area_type = 'VIEW_3D'

        if bpy.app.version >= (4, 2, 0):
            
            areas = (area for win in context.window_manager.windows for area in win.screen.areas if area.type == area_type)

            for area in areas:
                for region in area.regions:
                    if region.type == 'UI':  
                        if region.width == 1:  
                            with context.temp_override(area=area):
                                bpy.ops.wm.context_toggle(data_path='space_data.show_region_ui')
                                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

                        try:
                            
                            if region.active_panel_category != category:
                                region.active_panel_category = category
                                area.tag_redraw()
                        except AttributeError:
                            pass  

        return {'FINISHED'}


def register():
    bpy.utils.register_class(VIEW3D_OT_toggle_n_panel_and_set_tab)

def unregister():
    bpy.utils.unregister_class(VIEW3D_OT_toggle_n_panel_and_set_tab)


#register()