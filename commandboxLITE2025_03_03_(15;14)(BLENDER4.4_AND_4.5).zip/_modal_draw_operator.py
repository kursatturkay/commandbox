import bpy
import blf
import gpu
import time
import textwrap

_draw_handler = None
_draw_text = ""
_draw_start_time = 0
_draw_duration = 3


def get_viewport_width():
    """Aktif Viewport genişliğini döndürür."""
    for area in bpy.context.window_manager.windows[0].screen.areas:
        if area.type == 'VIEW_3D':
            for region in area.regions:
                if region.type == 'WINDOW':
                    return region.width
    return 300  # Varsayılan genişlik

def is_asset_shelf_open():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':  # Eğer alan 3D Viewport ise
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    # Asset Shelf'in görünür olup olmadığını kontrol et ve döndür
                    return space.show_region_asset_shelf
    return False  # 3D Viewport bulunmazsa False döner


def draw_type_2d(color, text, size=15):
    font_id = 0
    dpi = bpy.context.preferences.system.dpi
    blf.size(font_id, size * (dpi / 72))

    # Viewport genişliğini al
    viewport_width = get_viewport_width()
    wrap_width = viewport_width - 40  # Sağ ve sol kenar boşlukları için

    # Metni satırlara böl (hem \n hem de otomatik sarma için)
    lines = []
    for line in text.split("\n"):  # '\n' karakterine göre satırları böler
        wrapped_lines = textwrap.fill(line, width=int(wrap_width / (size * 0.6)))
        lines.extend(wrapped_lines.split("\n"))  # Sarılan satırları listeye ekle

    # Satırları çiz
    y_offset = 100 if is_asset_shelf_open() else 40
    line_height = size + 5  # Satır yüksekliği
    for line in lines:
        blf.position(font_id, 20, y_offset, 0)  # 20 px sol boşluk
        blf.color(font_id, *color)
        blf.draw(font_id, line)
        y_offset -= line_height



def draw_callback_2d():
    global _draw_text
    gpu.state.blend_set('ALPHA')
    draw_type_2d((1.0, 1.0, 1.0, 1.0), _draw_text)
    gpu.state.blend_set('NONE')


def update_draw_text(text, duration=3):
    global _draw_text, _draw_start_time, _draw_handler, _draw_duration

    _draw_text = text
    _draw_start_time = time.time()
    _draw_duration = duration

    if not _draw_handler:
        areas = [area for area in bpy.context.window_manager.windows[0].screen.areas if area.type == 'VIEW_3D']
        if areas:
            _draw_handler = areas[0].spaces[0].draw_handler_add(draw_callback_2d, (), 'WINDOW', 'POST_PIXEL')


def remove_draw_handler():
    global _draw_handler
    if _draw_handler:
        areas = [area for area in bpy.context.window_manager.windows[0].screen.areas if area.type == 'VIEW_3D']
        if areas:
            areas[0].spaces[0].draw_handler_remove(_draw_handler, 'WINDOW')
        _draw_handler = None


class ModalDrawOperator(bpy.types.Operator):
    """Viewport'ta yazı çizen Modal Operator"""
    bl_idname = "view3d.modal_draw_operator"
    bl_label = "Modal Draw Operator to Draw Text"

    text: bpy.props.StringProperty(name="Text", default="Default Text")
    duration: bpy.props.IntProperty(name="Duration", default=3)

    def modal(self, context, event):
        global _draw_start_time, _draw_duration
        
        if context.area and context.area.type == 'VIEW_3D':
            context.area.tag_redraw()

        if time.time() - _draw_start_time > _draw_duration:
            remove_draw_handler()
            return {'CANCELLED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            remove_draw_handler()
            return {'CANCELLED'}

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        update_draw_text(self.text, self.duration)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}


def register():
    bpy.utils.register_class(ModalDrawOperator)


def unregister():
    bpy.utils.unregister_class(ModalDrawOperator)
