#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Reload Refresh Linked Files.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class OT_ReloadLinkedFiles(bpy.types.Operator):
    """Reload all linked files in the Blender project"""
    bl_idname = "wm.reload_linked_files"
    bl_label = "Reload Linked Files"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Get all linked files
        linked_files = [lib for lib in bpy.data.libraries if lib.filepath]

        if not linked_files:
            textinfo_= "No linked files found."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            return {'CANCELLED'}

        # Reload each linked file
        for lib in linked_files:
            print(f"Reloading: {lib.filepath}")
            lib.reload()

        textinfo_= f"{len(linked_files)} linked file(s) reloaded."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

# Register the operator
def register():
    bpy.utils.register_class(OT_ReloadLinkedFiles)

def unregister():
    bpy.utils.unregister_class(OT_ReloadLinkedFiles)

if __name__ == "__main__":
    register()

    bpy.ops.wm.reload_linked_files()
