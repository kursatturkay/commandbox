#Refresh All Images
import bpy

def refresh_all_images():
    for image in bpy.data.images:
        if image:
            image.reload()
<
refresh_all_images()
