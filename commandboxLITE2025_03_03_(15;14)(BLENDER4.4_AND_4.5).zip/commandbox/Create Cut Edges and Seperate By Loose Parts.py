# https://www.youtube.com/watch?v=3oJv7KVh3OM
# ① Select TARGET mesh , ② Select CUTTER mesh. ③ apply command. (be sure normals are correct)
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 
import bpy
import bmesh
from mathutils import Matrix, Vector

def unhide_deselect(mesh):
    polygons = len(mesh.polygons)
    edges = len(mesh.edges)
    vertices = len(mesh.vertices)

    mesh.polygons.foreach_set('hide', [False] * polygons)
    mesh.edges.foreach_set('hide', [False] * edges)
    mesh.vertices.foreach_set('hide', [False] * vertices)

    mesh.polygons.foreach_set('select', [False] * polygons)
    mesh.edges.foreach_set('select', [False] * edges)
    mesh.vertices.foreach_set('select', [False] * vertices)

    mesh.update()


def join(target, objects, select=[]):
    mxi = target.matrix_world.inverted_safe()

    bm = bmesh.new()
    bm.from_mesh(target.data)
    bm.normal_update()
    bm.verts.ensure_lookup_table()

    i = bm.faces.layers.int.verify()

    # use_auto_smooth removed in blender version 4.1
    # if any([obj.data.use_auto_smooth for obj in objects]):
    #    target.data.use_auto_smooth = True

    for idx, obj in enumerate(objects):
        mesh = obj.data
        mx = obj.matrix_world
        mesh.transform(mxi @ mx)

        bmm = bmesh.new()
        bmm.from_mesh(mesh)
        bmm.normal_update()
        bmm.verts.ensure_lookup_table()

        im = bmm.faces.layers.int.verify()

        for f in bmm.faces:
            f[im] = idx + 1

        bmm.to_mesh(mesh)
        bmm.clear()

        bm.from_mesh(mesh)

        bpy.data.meshes.remove(mesh, do_unlink=True)

    if select:
        for f in bm.faces:
            if f[i] in select:
                f.select_set(True)

    bm.to_mesh(target.data)
    bm.clear()


def delete_face_island(mesh):
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.normal_update()
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()

    first_face = bm.faces[0]

    island_faces = set()
    to_process = [first_face]
    while to_process:
        current_face = to_process.pop()
        if current_face not in island_faces:
            island_faces.add(current_face)
            linked_faces = [
                linked_face for edge in current_face.edges 
                for linked_face in edge.link_faces if linked_face != current_face
            ]
            to_process.extend(linked_faces)

    bmesh.ops.delete(bm, geom=list(island_faces), context='FACES')

    bm.to_mesh(mesh)
    bm.free()

class SimpleMeshCut(bpy.types.Operator):
    bl_idname = "object.simple_mesh_cut"
    bl_label = "Simple Mesh Cut"
    bl_description = "Cuts the active object using the other selected object without menus"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (
            context.mode == 'OBJECT' and 
            len(context.selected_objects) == 2 and 
            all(obj.type == 'MESH' for obj in context.selected_objects)
        )

    def execute(self, context):
        target = context.active_object
        cutter = [obj for obj in context.selected_objects if obj != target][0]

        
        unhide_deselect(target.data)
        unhide_deselect(cutter.data)

        
        cutter.data.materials.clear()

        
        join(target, [cutter], select=[1])

        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.intersect(separate_mode='CUT')
        bpy.ops.object.mode_set(mode='OBJECT')

        
        delete_face_island(target.data)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='EDGE')

       
        for area in bpy.context.screen.areas:
            if area.type == 'VIEW_3D':
                space = area.spaces.active
                
                if hasattr(space, 'shading'):
                    space.shading.show_xray = True

        return {'FINISHED'}

def register():
    bpy.utils.register_class(SimpleMeshCut)

def unregister():
    bpy.utils.unregister_class(SimpleMeshCut)

if __name__ == "__main__":
    register()
    bpy.ops.object.simple_mesh_cut()
    bpy.ops.mesh.edge_split(type='VERT')


    import os
    # Dosyanın adını ve yolu al
    file_name = "Separate by Loose Parts.py"
    script_dir = os.path.dirname(os.path.realpath(__file__))
    file_path = os.path.join(script_dir, file_name)

    # Dosyanın içeriğini oku ve çalıştır
    with open(file_path, "r", encoding="utf-8") as file:
        exec(file.read())
