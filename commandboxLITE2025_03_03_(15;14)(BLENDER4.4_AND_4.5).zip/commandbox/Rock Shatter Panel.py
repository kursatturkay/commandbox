#https://www.youtube.com/watch?v=AT6eFvRIUvg
#① Select A Mesh ② Run This Command ③ Goto NPanel > Command Box > ③ Press "Add RockShatter" ④ Modify Settings ⑤ Press Bake Button
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 
# 

bl_info = {
    "name": "RockShatter Addon",
    "blender": (3, 0, 0),
    "category": "Object",
    "description": "Add RockShatter (NPanel>Tool>Rock Shatter)",
}

import bpy
import bmesh
import os
import sys
#from mathutils import Vector
import math

class RockShatterOperator(bpy.types.Operator):
    bl_idname = "object.rockshatter_add_ops"
    bl_label = "Add RockShatter (NPanel>Tool>Rock Shatter)"

    def execute(self, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            # Add Geometry Nodes modifier
            mod = obj.modifiers.new(name="RockShatter", type='NODES')

            # Ensure node group exists
            if "RockShatter" not in bpy.data.node_groups:
                # Dynamically load _rockshatter_node_group
                script_dir = os.path.dirname(os.path.abspath(__file__))
                if script_dir not in sys.path:
                    sys.path.append(script_dir)

                from _rockshatter_node_group import _rockshatter_node_group
                _rockshatter_node_group()

            # Assign the node group
            mod.node_group = bpy.data.node_groups["RockShatter"]
        else:
            self.report({'WARNING'}, "No active mesh object selected!")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class RockShatterResetDefaultsOperator(bpy.types.Operator):
    bl_idname = "object.rockshatter_reset_defaults"
    bl_label = "Reset RockShatter Defaults"
    bl_options = {'INTERNAL'}  # Prevent from showing in the F3 menu

    def execute(self, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            # Get the RockShatter node group
            mod = next((mod for mod in obj.modifiers if mod.type == 'NODES' and mod.node_group and mod.node_group.name == "RockShatter"), None)
            if mod and mod.node_group:
                node_group = mod.node_group
                
                # Reset Density
                if "Distribute Points on Faces" in node_group.nodes:
                    node_group.nodes["Distribute Points on Faces"].inputs[4].default_value = 1.0  # Default Density
                # Reset Factor
                if "Mix" in node_group.nodes:
                    node_group.nodes["Mix"].inputs[0].default_value = 0.5  # Default Factor
                # Reset Scale
                if "Scale Elements" in node_group.nodes:
                    node_group.nodes["Scale Elements"].inputs[2].default_value = 1.0  # Default Scale
                
                self.report({'INFO'}, "RockShatter values reset to defaults")
            else:
                self.report({'WARNING'}, "RockShatter modifier not found on the active object!")
        else:
            self.report({'WARNING'}, "No active mesh object selected!")
            return {'CANCELLED'}
        return {'FINISHED'}

class OBJECT_PT_toggle_RockShatterPanel(bpy.types.Operator):
    bl_idname = "wm.toggle_rock_shatter_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.rockshatter_panel_visible = not context.window_manager.rockshatter_panel_visible

        if(context.window_manager.rockshatter_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class RockShatterPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_rockshatter"
    bl_label = "Rock Shatter"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "rockshatter_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_rock_shatter_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        scene=context.scene

        # Check if active object has RockShatter modifier
        if obj and obj.type == 'MESH' and any(mod for mod in obj.modifiers if mod.type == 'NODES' and mod.node_group and mod.node_group.name == "RockShatter"):
            mod = next(mod for mod in obj.modifiers if mod.node_group and mod.node_group.name == "RockShatter")
            node_group = mod.node_group

            layout.label(text="RockShatter Properties")
            
            # Add Density and Seed from DOF1_IO
            if "Distribute Points on Faces" in node_group.nodes:
                node = node_group.nodes["Distribute Points on Faces"]
                layout.prop(node.inputs[4], "default_value", text="Density")
                layout.prop(node.inputs[6], "default_value", text="Seed")

            # Add Factor from Mix_IO
            if "Mix" in node_group.nodes:
                node = node_group.nodes["Mix"]
                layout.prop(node.inputs[0], "default_value", text="Factor")

            # Add Scale from SE_IO
            if "Scale Elements" in node_group.nodes:
                node = node_group.nodes["Scale Elements"]
                layout.prop(node.inputs[2], "default_value", text="Scale", slider=True)
                if node.inputs[2].default_value < 0.4:
                    node.inputs[2].default_value = 0.4  # Enforce minimum value

            layout.separator()
            layout.operator("object.rockshatter_reset_defaults", text="Reset to Defaults")
            #layout.operator("mesh.dissolve_flat_edges_multiple",text="Dissolve Flat Edges")
            layout.prop(scene, "dissolve_flat_edges_multiple", text="Dissolve Flat Edges")
            layout.operator("object.rockshatter_bake", text="Bake RockShatter")
        else:
            layout.operator("object.rockshatter_add_ops", text="Add RockShatter")

class RockShatterBakeOperator(bpy.types.Operator):
    bl_idname = "object.rockshatter_bake"
    bl_label = "Bake RockShatter"
    bl_options = {'INTERNAL'}  # Prevent from showing in the F3 menu

    def execute(self, context):
        scene=context.scene
        obj = context.active_object
        
        if obj and obj.type == 'MESH':
            # Apply Geometry Nodes modifier
            bpy.ops.object.modifier_apply(modifier="RockShatter")
            
            if scene.dissolve_flat_edges_multiple:
                bpy.ops.mesh.dissolve_flat_edges_multiple()

            # Separate by loose parts
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.mode_set(mode='OBJECT')

            # Set origin to geometry for each part
            for part in context.selected_objects:
                bpy.context.view_layer.objects.active = part
                bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME', center='BOUNDS')

            # Remove node tree
            if "RockShatter" in bpy.data.node_groups:
                bpy.data.node_groups.remove(bpy.data.node_groups["RockShatter"])
        else:
            self.report({'WARNING'}, "No active mesh object selected!")
            return {'CANCELLED'}

        return {'FINISHED'}

class SelectAndDissolveFlatEdgesOperator(bpy.types.Operator):
    """Select and dissolve edges on flat surfaces for all selected mesh objects"""
    bl_idname = "mesh.dissolve_flat_edges_multiple"
    bl_label = "Dissolve Flat Edges on All Selected Objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    angle_threshold: bpy.props.FloatProperty(
        name="Angle Threshold",
        description="Edges flatter than this angle will be selected and dissolved (degrees)",
        default=5.0,
        min=0.0,
        max=180.0
    )
    
    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not selected_objects:
            self.report({'ERROR'}, "Please select at least one mesh object")
            return {'CANCELLED'}
        
        original_active = context.active_object
        
        angle_threshold_rad = math.radians(self.angle_threshold)
        
        for obj in selected_objects:
            context.view_layer.objects.active = obj
            
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')
            
            me = obj.data
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.edges.ensure_lookup_table()
            
            for edge in bm.edges:
                faces = edge.link_faces
                
                if len(faces) == 2:
                    
                    angle = faces[0].normal.angle(faces[1].normal)
                    
                    if angle < angle_threshold_rad:
                        edge.select = True
            
            bm.to_mesh(me)
            bm.free()
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.dissolve_edges()
            
            bpy.ops.object.mode_set(mode='OBJECT')
        
        if original_active:
            context.view_layer.objects.active = original_active
        
        if original_active and original_active.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
            
        return {'FINISHED'}


classes = (
    SelectAndDissolveFlatEdgesOperator,
    OBJECT_PT_toggle_RockShatterPanel,
    RockShatterOperator,
    RockShatterPanel,
    RockShatterBakeOperator,
    RockShatterResetDefaultsOperator,  # Added reset button operator
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.WindowManager.rockshatter_panel_visible = bpy.props.BoolProperty(default=False)
    
    bpy.types.Scene.dissolve_flat_edges_multiple = bpy.props.BoolProperty(
    description="Dissolve Flat Edges",
    default=True
)

def unregister():
    del bpy.types.WindowManager.rockshatter_panel_visible
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_rock_shatter_panel()

# def toggle():
    
#     if hasattr(bpy.types, "VIEW3D_PT_rockshatter"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='Rock Shatter Panel exist. now removing', duration=5)
#         #unregister() throws mRNA error ? couldnt resolve so commented  
#         bpy.utils.unregister_class(bpy.types.VIEW3D_PT_rockshatter)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='Rock Shatter Panel not exist.now registering under CommandBox Tab', duration=5)
#         register()

# İlk çalıştırma (register yapılacak)
# if __name__ == "__main__":
#     toggle()

