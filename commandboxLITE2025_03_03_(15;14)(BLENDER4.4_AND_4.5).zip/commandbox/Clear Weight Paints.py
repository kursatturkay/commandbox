#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Clear Weight Paints.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class ClearWeightPaintsOperator(bpy.types.Operator):
    bl_idname = "object.clear_weight_paints"
    bl_label = "Clear Weight Paints"

    def execute(self, context):
        obj = bpy.context.active_object

        
        for vertex_group in obj.vertex_groups:
            
            for v in obj.data.vertices:
                try:
                    vertex_group.remove([v.index])
                except RuntimeError:
                    pass  

        return {'FINISHED'}


def register():
    bpy.utils.register_class(ClearWeightPaintsOperator)

def unregister():
    bpy.utils.unregister_class(ClearWeightPaintsOperator)

if __name__ == "__main__":
    register()
    bpy.ops.object.clear_weight_paints()
