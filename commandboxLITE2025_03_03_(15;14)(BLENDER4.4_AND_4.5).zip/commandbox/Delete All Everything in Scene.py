#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Delete All Everything in Scene.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy


if bpy.context.mode != 'OBJECT':
    bpy.ops.object.mode_set(mode='OBJECT')


bpy.ops.object.select_all(action='DESELECT')


bpy.ops.object.select_all(action='SELECT')


bpy.ops.object.delete()
