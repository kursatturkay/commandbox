# https://www.youtube.com/watch?v=ixyebNEiF8Q&t=331s
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Add Vertices On Intersecting Edges.

import bpy
import bmesh

# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Add Vertices On Intersecting Edges.

import bpy
import bmesh

def intersect_vertices_on_mesh_edges():
    
    selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
    
    c1=bpy.context.scene.tool_settings.use_mesh_automerge
    c2=bpy.context.scene.tool_settings.use_mesh_automerge_and_split
    
    bpy.context.scene.tool_settings.use_mesh_automerge = True
    bpy.context.scene.tool_settings.use_mesh_automerge_and_split = True


    if len(selected_objects) > 1:
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.join()  

    combined_object = bpy.context.object  
    bpy.ops.object.mode_set(mode='EDIT')  

    bpy.ops.mesh.select_mode(type='VERT')  
    bpy.ops.mesh.select_all(action='SELECT')  

    
    bpy.ops.transform.translate(
        value=(0, 0, 0),
        orient_type='GLOBAL',
        orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
        orient_matrix_type='GLOBAL',
        mirror=True,
        use_proportional_edit=False,
        proportional_edit_falloff='SMOOTH',
        proportional_size=1,
        use_proportional_connected=False,
        use_proportional_projected=False,
        snap=False,
        snap_elements={'INCREMENT'},
        use_snap_project=False,
        snap_target='CLOSEST',
        use_snap_self=True,
        use_snap_edit=True,
        use_snap_nonedit=True,
        use_snap_selectable=False
    )

    bpy.ops.mesh.select_all(action='DESELECT')  

    
    bm = bmesh.from_edit_mesh(combined_object.data)

    
    for v in bm.verts:
        connected_edges = len(v.link_edges)
        if connected_edges > 2:  
            v.select = True
        else:
            v.select = False

    
    bmesh.update_edit_mesh(combined_object.data)

    bpy.ops.object.mode_set(mode='EDIT')  

    bpy.context.scene.tool_settings.use_mesh_automerge = c1
    bpy.context.scene.tool_settings.use_mesh_automerge_and_split = c2
    
    bpy.ops.mesh.separate(type='LOOSE')

    textinfo_="Process Finished."
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)


intersect_vertices_on_mesh_edges()