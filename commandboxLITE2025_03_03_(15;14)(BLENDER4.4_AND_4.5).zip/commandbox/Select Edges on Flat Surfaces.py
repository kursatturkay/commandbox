#https://www.youtube.com/watch?v=k8a5kEOMO80
#Select Edges on Flat Surfaces.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
from mathutils import Vector
import math

import bpy
import bmesh
from mathutils import Vector
import math

class SelectFlatEdgesOperator(bpy.types.Operator):
    """Select edges on flat surfaces"""
    bl_idname = "mesh.select_flat_edges"
    bl_label = "Select Edges on Flat Surfaces"
    bl_options = {'REGISTER', 'UNDO'}
    
    angle_threshold: bpy.props.FloatProperty(
        name="Angle Threshold",
        description="Edges flatter than this angle will be selected (degrees)",
        default=5.0,
        min=0.0,
        max=180.0
    )
    
    def execute(self, context):
        
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh object")
            return {'CANCELLED'}
        
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')
        
        me = obj.data
        bm = bmesh.new()
        bm.from_mesh(me)
        bm.edges.ensure_lookup_table()
        
        angle_threshold_rad = math.radians(self.angle_threshold)
        
        for edge in bm.edges:
            
            faces = edge.link_faces
            
            
            if len(faces) == 2:
                angle = faces[0].normal.angle(faces[1].normal)
                
                if angle < angle_threshold_rad:
                    edge.select = True
        
        bm.to_mesh(me)
        bm.free()
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        return {'FINISHED'}

def register():
    bpy.utils.register_class(SelectFlatEdgesOperator)

def unregister():
    bpy.utils.unregister_class(SelectFlatEdgesOperator)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.select_flat_edges()