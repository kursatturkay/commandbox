#https://www.youtube.com/watch?v=pjMbiLMNpVM
import bpy

smallest_obj = None
smallest_volume = float('inf')  

for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':  
        
        bbox = obj.bound_box
        
        width = abs(bbox[0][0] - bbox[4][0])  
        height = abs(bbox[0][1] - bbox[2][1])  
        depth = abs(bbox[0][2] - bbox[1][2])  
        volume = width * height * depth  
        
        if volume < smallest_volume:
            smallest_volume = volume
            smallest_obj = obj

if smallest_obj:
    bpy.ops.object.select_all(action='DESELECT')  
    smallest_obj.select_set(True)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"The smallest object by volume is: {smallest_obj.name}", duration=5)
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No mesh objects found in the scene.", duration=5)


for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        
        for region in area.regions:
            if region.type == 'WINDOW':
                
                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
                break