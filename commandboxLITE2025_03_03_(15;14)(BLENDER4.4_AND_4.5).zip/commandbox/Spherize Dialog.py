#https://www.youtube.com/watch?v=H2cAPNsjJAM
#Spherize Selected Method two.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
import math
from mathutils import Vector
from bpy.props import FloatProperty

class SpherizeDialogOperator(bpy.types.Operator):
    bl_idname = "mesh.spherize_dialog"
    bl_label = "Spherize Dialog"
    bl_options = {'REGISTER', 'UNDO'}

    factor: FloatProperty(
        name="Factor",
        description="Spherize factor",
        default=0.5,
        min=-2.0,
        max=2.0,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(obj.data)
        selected_edges = [e for e in bm.edges if e.select]
        if not selected_edges:
            return {'CANCELLED'}

        verts = {v for e in selected_edges for v in e.verts}
        center = sum((v.co for v in verts), Vector()) / len(verts)
        radius = sum((v.co - center).length for v in verts) / len(verts)

        for v in verts:
            direction = (v.co - center).normalized()
            v.co = v.co.lerp(center + direction * radius, self.factor)

        bmesh.update_edit_mesh(obj.data)
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "factor")  # Tool panelinde Factor'ü göster

    def invoke(self, context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)  # Tool Properties penceresini aç

def register():
    bpy.utils.register_class(SpherizeDialogOperator)

def unregister():
    bpy.utils.unregister_class(SpherizeDialogOperator)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.spherize_dialog('INVOKE_DEFAULT')  # Tool Properties aç