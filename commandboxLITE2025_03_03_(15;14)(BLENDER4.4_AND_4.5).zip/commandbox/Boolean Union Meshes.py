#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Better Than Classic Union. You wont lost meshes. Boolean Union Joined Merged Meshes
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_boolean_union(bpy.types.Operator):
    """Join selected objects and apply boolean union"""
    bl_idname = "object.boolean_union"
    bl_label = "Boolean Union"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if len(selected_objects) < 2:
            self.report({'WARNING'}, "Select at least two mesh objects")
            return {'CANCELLED'}

        # Set active object as the target for boolean operation
        active_obj = context.view_layer.objects.active
        if active_obj not in selected_objects:
            active_obj = selected_objects[0]
            context.view_layer.objects.active = active_obj
        
        selected_objects.remove(active_obj)

        # Apply boolean modifiers
        for obj in selected_objects:
            bool_mod = active_obj.modifiers.new(name="Boolean", type='BOOLEAN')
            bool_mod.operation = 'UNION'
            bool_mod.object = obj

            bpy.ops.object.modifier_apply(modifier=bool_mod.name)

            # Delete the original object after merging
            bpy.data.objects.remove(obj, do_unlink=True)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_boolean_union)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_boolean_union)

if __name__ == "__main__":
    register()

    bpy.ops.object.boolean_union()