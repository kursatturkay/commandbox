#https://www.youtube.com/watch?v=3oJv7KVh3OM
#Join Overlapping Meshes.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
from mathutils.kdtree import KDTree

class OBJECT_OT_JoinOverlappingMeshes(bpy.types.Operator):
    """Joins separate meshes with overlapping vertices"""
    bl_idname = "object.join_overlapping_meshes"
    bl_label = "Join Overlapping Meshes"
    bl_options = {'UNDO'}

    threshold: bpy.props.FloatProperty(
        name="Threshold",
        description="Distance threshold to detect overlapping vertices",
        default=0.001,
        min=0.001,
        max=1.0,  # Daha geniş bir aralık
        step=0.001,
        precision=4
    )

    def get_mesh_vertices(self, obj):
        """Returns all vertices of a mesh in world coordinates."""
        depsgraph = bpy.context.evaluated_depsgraph_get()
        obj_eval = obj.evaluated_get(depsgraph)
        mesh = obj_eval.to_mesh()

        verts = [obj.matrix_world @ v.co for v in mesh.vertices]
        obj_eval.to_mesh_clear()
        return verts

    def meshes_have_overlapping_vertices(self, obj1, obj2, threshold):
        """Checks if two meshes have overlapping vertices within a given threshold."""
        verts1 = self.get_mesh_vertices(obj1)
        verts2 = self.get_mesh_vertices(obj2)

        tree = KDTree(len(verts1))
        for i, v in enumerate(verts1):
            tree.insert(v, i)
        tree.balance()

        for v in verts2:
            co, index, dist = tree.find(v)
            if dist < threshold:
                return True  # Overlapping vertex found

        return False  # No overlap

    def execute(self, context):
        meshes = [obj for obj in context.scene.objects if obj.type == 'MESH']
        merged_sets = []  

        while meshes:
            obj = meshes.pop(0)
            merge_group = [obj]

            for other in meshes[:]:  
                if self.meshes_have_overlapping_vertices(obj, other, self.threshold):
                    merge_group.append(other)
                    meshes.remove(other)

            if len(merge_group) > 1:
                bpy.ops.object.select_all(action='DESELECT')
                for m in merge_group:
                    m.select_set(True)

                context.view_layer.objects.active = merge_group[0]
                bpy.ops.object.join()  
                merged_sets.append(merge_group)

        for merged_group in merged_sets:
            obj = merged_group[0]  
            context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.remove_doubles(threshold=self.threshold)  
            bpy.ops.object.mode_set(mode='OBJECT')

        # Report the result as a message in the info panel, without modal tool
        textinfo_= f"{len(merged_sets)} groups merged."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

# Operator for toggling panel visibility
class SCENE_OT_toggle_merge_overlapping_meshes_panel(bpy.types.Operator):
    """Toggle the visibility of the Merge Panel"""
    bl_idname = "scene.toggle_merge_overlapping_meshes_panel"
    bl_label = "Toggle Merge Overlapping Meshes"

    def execute(self, context):
        context.scene.show_merge_overlapping_panel = not context.scene.show_merge_overlapping_panel

        if(context.scene.show_merge_overlapping_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()
            
        return {'FINISHED'}
    
class VIEW3D_PT_MergePanel(bpy.types.Panel):
    """Panel for merging overlapping meshes"""
    bl_label = "Join Merge Overlapping Meshes Panel"
    bl_idname = "VIEW3D_PT_merge_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_merge_overlapping_panel

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_merge_overlapping_meshes_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "merge_threshold")
        layout.operator(OBJECT_OT_JoinOverlappingMeshes.bl_idname, text="Apply")


def register():
    bpy.utils.register_class(SCENE_OT_toggle_merge_overlapping_meshes_panel)
    bpy.types.Scene.show_merge_overlapping_panel = bpy.props.BoolProperty(default=False)
    bpy.utils.register_class(OBJECT_OT_JoinOverlappingMeshes)
    bpy.utils.register_class(VIEW3D_PT_MergePanel)

    bpy.types.Scene.merge_threshold = bpy.props.FloatProperty(
        name="Merge Threshold",
        description="Threshold distance for merging overlapping vertices",
        default=0.001,
        min=0.001,
        max=1.0,  # Daha geniş bir aralık
        step=0.001,
        precision=4
    )


def unregister():
    bpy.utils.unregister_class(OBJECT_OT_JoinOverlappingMeshes)
    bpy.utils.unregister_class(VIEW3D_PT_MergePanel)
    bpy.utils.register_class(SCENE_OT_toggle_merge_overlapping_meshes_panel)
    del bpy.types.Scene.merge_threshold
    del bpy.types.Scene.show_merge_overlapping_panel

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_merge_overlapping_meshes_panel()
