# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Reselect Transforms of Selected Objects.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def reset_transforms():
    """Reset the transforms (location, rotation, scale) of selected objects."""
    for obj in bpy.context.selected_objects:
        # Sıfırla: Konum
        if hasattr(obj, "location"):
            obj.location = (0.0, 0.0, 0.0)
        
        # Sıfırla: Rotasyon
        if hasattr(obj, "rotation_euler"):
            obj.rotation_euler = (0.0, 0.0, 0.0)
        
        # Sıfırla: Ölçek
        if hasattr(obj, "scale"):
            obj.scale = (1.0, 1.0, 1.0)

# Call the function
reset_transforms()
