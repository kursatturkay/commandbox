# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Suggestion Or Bug Report.
import webbrowser
import urllib.parse


to_email = "fablesalive@gmail.com"
subject = "Suggestion or Bug Report - CommandBox Addon for Blender :"
body = ""  


mailto_link = f"mailto:{to_email}?subject={urllib.parse.quote(subject)}&body={urllib.parse.quote(body)}"


webbrowser.open(mailto_link)
