#https://www.youtube.com/watch?v=YBoYhN_WEDo
#Toggles To Sculpt Mode if not. Toggles DynTopo immediately without Warning Dialog. (Default Keymap: CTRL + * )
#autorun=True
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_toggle_dynamic_topology(bpy.types.Operator):
    bl_idname = "object.toggle_dynamic_topology"
    bl_label = "Toggle Dynamic Topology"
    
    def execute(self, context):

        #not raises error. even I commented the line below. I dont know what it is yet.
        #context.object.data.remesh_mode = "QUAD"
        if context.object.mode != 'SCULPT':
            bpy.ops.object.mode_set(mode='SCULPT')
            
        
        bpy.ops.sculpt.dynamic_topology_toggle()
        

#         obj = bpy.context.object
# if {preserve_uvs}:
#     orignal_obj = obj.copy()
#     orignal_obj.data = obj.data.copy()
    
# if {merge}:
#     bpy.ops.object.mode_set(mode='EDIT')
#     bpy.ops.mesh.select_all(action='SELECT')
#     bpy.ops.mesh.remove_doubles()
#     bpy.ops.object.mode_set(mode='OBJECT')
# # Remesh the model
# obj.data.remesh_mode = 'QUAD'

            #textinfo_=f"Switched to Sculpt Mode: {context.object.data.remesh_mode} ▮adaptivity:{context.object.data.remesh_voxel_adaptivity} |▮∎ ∥ ⫴"
        
        
        
        o=context.object
        dyntopo_status='ON' if o.use_dynamic_topology_sculpting else 'OFF'
        textinfo_ = f"Switched to Sculpt Mode: {o.data.remesh_mode} ∥ DynaTopo:{dyntopo_status} ∥ {o.data.remesh_voxel_adaptivity}"


        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)        
        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_toggle_dynamic_topology)
    
    keymap = bpy.context.window_manager.keyconfigs.active.keymaps["3D View"]

    existing_item = None
    for item in keymap.keymap_items:
        if item.type == 'NUMPAD_ASTERIX' and item.ctrl and item.idname == "object.toggle_dynamic_topology":
            existing_item = item
            break

    if not existing_item:
        keymap.keymap_items.new("object.toggle_dynamic_topology", "NUMPAD_ASTERIX", "PRESS", ctrl=True)
        #print("New shortcut assigned: Ctrl + *")


def unregister():
    bpy.utils.unregister_class(OBJECT_OT_toggle_dynamic_topology)

if __name__ == "__main__":

    if "OBJECT_OT_toggle_dynamic_topology" in dir(bpy.types):
        bpy.ops.object.toggle_dynamic_topology()
    
    register()