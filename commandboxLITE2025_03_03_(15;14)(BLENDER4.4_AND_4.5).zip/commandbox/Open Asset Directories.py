#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Open Asset Directories.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import os
import sys
import subprocess

def open_explorer(path):
    if sys.platform == "win32":
        os.startfile(path)
    elif sys.platform == "darwin":  
        subprocess.Popen(["open", path])
    else:  
        subprocess.Popen(["xdg-open", path])


asset_libraries = bpy.context.preferences.filepaths.asset_libraries

for lib in asset_libraries:
    open_explorer(lib.path)
