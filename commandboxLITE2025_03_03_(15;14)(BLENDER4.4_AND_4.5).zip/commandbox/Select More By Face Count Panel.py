#https://www.youtube.com/watch?v=3ZIjLy12SIw
#Select By Face Count Panel. Select meshes based on face count order, step-by-step
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class MESH_OT_select_by_face_count(bpy.types.Operator):
    """Select meshes based on face count order, step-by-step"""
    bl_idname = "mesh.select_by_face_count"
    bl_label = "Select by Face Count"
    bl_options = {'REGISTER', 'UNDO'}

    direction: bpy.props.EnumProperty(
        name="Direction",
        items=(
            ('LOWER', "Lower", "Select mesh with lower face count"),
            ('HIGHER', "Higher", "Select mesh with higher face count"),
        )
    )

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def execute(self, context):
        # 1. Sahnedeki tüm meshleri al ve yüz sayılarına göre sırala.
        mesh_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
        
        # (object, face_count) tuple'ları içeren bir liste
        meshes_with_facecount = [(obj, len(obj.data.polygons)) for obj in mesh_objects]
        
        # Yüz sayılarına göre artan sırada sırala
        meshes_with_facecount.sort(key=lambda item: item[1]) 

        # Sadece objelerin kendisinden oluşan sıralı bir liste
        sorted_meshes = [item[0] for item in meshes_with_facecount]

        try:
            # 2. Mevcut seçimi al
            selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']
            
            if not selected_objects:
               #Eğer hiç seçili obje yoksa, en başından başla
                if self.direction == 'LOWER':
                    if sorted_meshes:
                        selected_mesh = sorted_meshes[0]
                        selected_mesh.select_set(True)
                        face_count = len(selected_mesh.data.polygons)
                        textinfo_ = f"No selection. Selected first object: {selected_mesh.name} - Faces: {face_count} - Total Selected: 1"
                        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                elif self.direction == 'HIGHER':
                    if sorted_meshes:
                       selected_mesh = sorted_meshes[-1]
                       selected_mesh.select_set(True)
                       face_count = len(selected_mesh.data.polygons)
                       textinfo_ = f"No selection. Selected last object: {selected_mesh.name} - Faces: {face_count} - Total Selected: 1"
                       bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'FINISHED'}

            # Seçili objelerin sıralı listedeki indexlerini bul
            selected_indices = []
            for obj in selected_objects:
                try:
                    index = sorted_meshes.index(obj)
                    selected_indices.append(index)
                except ValueError:
                    textinfo_ = f"Selected object {obj.name} not found in the sorted list."
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                    return {'CANCELLED'}
            
            if not selected_indices:
                textinfo_ = "No selected object found in the list"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'CANCELLED'}
                
            if self.direction == 'LOWER':
                 # Seçili en küçük indexi bul
                min_index = min(selected_indices)
                
                next_index = min_index - 1
                
                if next_index >= 0:
                    selected_mesh = sorted_meshes[next_index]
                    selected_mesh.select_set(True)
                    face_count = len(selected_mesh.data.polygons)
                    total_selected = len(bpy.context.selected_objects)
                    textinfo_ = f"Selected object: {selected_mesh.name} - Faces: {face_count} - Total Selected: {total_selected}"
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                else:
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="Lower selection limit reached", duration=5)

            elif self.direction == 'HIGHER':
                # Seçili en büyük indexi bul
                max_index = max(selected_indices)
                    
                next_index = max_index + 1
                
                if next_index < len(sorted_meshes):
                   selected_mesh = sorted_meshes[next_index]
                   selected_mesh.select_set(True)
                   face_count = len(selected_mesh.data.polygons)
                   total_selected = len(bpy.context.selected_objects)
                   textinfo_ = f"Selected object: {selected_mesh.name} - Faces: {face_count} - Total Selected: {total_selected}"
                   bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                else:
                    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="Higher selection limit reached", duration=5)
        except Exception as e:
            textinfo_ = f"An error occurred: {e}"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            return{'CANCELLED'}

        return {'FINISHED'}


class MESH_PT_facecount_selector(bpy.types.Panel):
    """Creates a Panel in the Object properties window"""
    bl_label = "Select More By Face Count Panel"
    bl_idname = "MESH_PT_facecount_selector"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_facecount_selector_panel

    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("scene.toggle_facecount_selector_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        layout.operator(MESH_OT_select_by_face_count.bl_idname, text="Select Lower").direction = 'LOWER'
        layout.operator(MESH_OT_select_by_face_count.bl_idname, text="Select Higher").direction = 'HIGHER'


class SCENE_OT_toggle_facecount_selector_panel(bpy.types.Operator):
    """Toggle the visibility of Face Count Selector Panel"""
    bl_idname = "scene.toggle_facecount_selector_panel"
    bl_label = "Toggle Face Count Selector Panel"

    def execute(self, context):
        context.scene.show_facecount_selector_panel = not context.scene.show_facecount_selector_panel
        return {'FINISHED'}

def register():
    bpy.types.Scene.show_facecount_selector_panel = bpy.props.BoolProperty(default=False)
    bpy.utils.register_class(MESH_OT_select_by_face_count)
    bpy.utils.register_class(MESH_PT_facecount_selector)
    bpy.utils.register_class(SCENE_OT_toggle_facecount_selector_panel)



def unregister():
    del bpy.types.Scene.show_facecount_selector_panel
    bpy.utils.unregister_class(MESH_OT_select_by_face_count)
    bpy.utils.unregister_class(MESH_PT_facecount_selector)
    bpy.utils.unregister_class(SCENE_OT_toggle_facecount_selector_panel)


if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_facecount_selector_panel()