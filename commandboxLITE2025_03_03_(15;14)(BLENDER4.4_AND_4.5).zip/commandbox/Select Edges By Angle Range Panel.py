#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Select Edges By Angle Range Panel.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
import math
from mathutils import Vector

class SelectEdgesByAngleOperator(bpy.types.Operator):
    """Select edges based on the angle between their adjacent faces"""
    bl_idname = "mesh.select_edges_by_angle"
    bl_label = "Select Edges By Angle Range"
    bl_options = {'REGISTER', 'UNDO'}
    
    min_angle: bpy.props.FloatProperty(
        name="Minimum Angle",
        description="Minimum angle to consider (degrees)",
        default=0.0,
        min=0.0,
        max=180.0
    )
    
    max_angle: bpy.props.FloatProperty(
        name="Maximum Angle",
        description="Maximum angle to consider (degrees)",
        default=10.0,
        min=0.0,
        max=180.0
    )
    
    def execute(self, context):

        # print(f"Running with min_angle={self.min_angle}, max_angle={self.max_angle}")
        
        # Check active object and edit mode
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Please select a mesh object")
            return {'CANCELLED'}
        
        # Store current mode
        current_mode = context.object.mode
        
        # Switch to edit mode if not already there
        if current_mode != 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
            
        # Ensure we're working with the mesh data
        bpy.ops.mesh.select_mode(type='EDGE')
        
        # Get the BMesh
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        bm.edges.ensure_lookup_table()
        
        # Deselect all edges in BMesh
        for edge in bm.edges:
            edge.select = False
        
        selected_count = 0
        total_edges = len(bm.edges)
        
        # Check each edge
        for edge in bm.edges:
            # Get faces connected to this edge
            faces = edge.link_faces
            
            # If edge is connected to at least two faces (internal edge)
            if len(faces) == 2:
                # Compare the normals of the two faces
                angle_rad = faces[0].normal.angle(faces[1].normal)
                angle_deg = math.degrees(angle_rad)
                
                # Debug print for first few edges
                if selected_count < 5:
                    print(f"Edge angle: {angle_deg:.2f}° - Range: {self.min_angle:.2f}° to {self.max_angle:.2f}°")
                
                # Check if angle is within our desired range
                if self.min_angle <= angle_deg <= self.max_angle:
                    edge.select = True
                    selected_count += 1
        
        # Update the mesh with our changes
        bm.select_flush(True)  # Ensure selection is updated
        bmesh.update_edit_mesh(me)
        
        self.report({'INFO'}, f"Selected {selected_count} out of {total_edges} edges with angles between {self.min_angle:.2f}° and {self.max_angle:.2f}°")
        return {'FINISHED'}

class ANGLE_EDGES_OT_SelectPreset(bpy.types.Operator):
    """Select edges using a preset angle range"""
    bl_idname = "mesh.select_edges_by_angle_preset"
    bl_label = "Select Edges By Angle Preset"
    bl_options = {'REGISTER', 'UNDO'}
    
    min_angle: bpy.props.FloatProperty(default=0.0)
    max_angle: bpy.props.FloatProperty(default=5.0)
    preset_name: bpy.props.StringProperty(default="Preset")
    
    def execute(self, context):
        print(f"Running preset '{self.preset_name}' with min={self.min_angle}, max={self.max_angle}")
        
        # Run the main operator with our preset values
        bpy.ops.mesh.select_edges_by_angle(min_angle=self.min_angle, max_angle=self.max_angle)
        
        return {'FINISHED'}

class OBJECT_PT_toggle_select_edges_by_angle_range_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_select_edges_by_angle_range_panel"
    bl_label = "Toggle select edges by angle range panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.select_edges_by_angle_range_panel_visible = not context.window_manager.select_edges_by_angle_range_panel_visible

        if(context.window_manager.select_edges_by_angle_range_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class MESH_PT_AngleEdgesPanel(bpy.types.Panel):
    """Panel for edge selection by angle range"""
    bl_label = "Select Edges By Angle Range"
    bl_idname = "MESH_PT_angle_edges"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"
    #bl_context = "mesh_edit"
    

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "select_edges_by_angle_range_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_select_edges_by_angle_range_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        
        # Add property sliders
        col = layout.column(align=True)
        col.label(text="Angle Settings:")
        col.prop(context.scene, "angle_edges_min_angle", text="Min Angle (°)")
        col.prop(context.scene, "angle_edges_max_angle", text="Max Angle (°)")
        
        # Information
        info_box = layout.box()
        info_box.label(text="How to use:")
        col = info_box.column(align=True)
        col.label(text="• Lower angles = more parallel faces")
        col.label(text="• 0° = completely parallel faces")
        col.label(text="• Typical range: 0-5° for almost parallel")
        
        # User-defined selection with current values
        layout.operator(SelectEdgesByAngleOperator.bl_idname, text="Select With Current Settings").max_angle = context.scene.angle_edges_max_angle
        
        # Example presets
        box = layout.box()
        box.label(text="Quick Presets:")
        
        row = box.row(align=True)
        op = row.operator(ANGLE_EDGES_OT_SelectPreset.bl_idname, text="Very Parallel (0-1°)")
        op.min_angle = 0.0
        op.max_angle = 1.0
        op.preset_name = "Very Parallel"
        
        row = box.row(align=True)
        op = row.operator(ANGLE_EDGES_OT_SelectPreset.bl_idname, text="Almost Parallel (0-5°)")
        op.min_angle = 0.0
        op.max_angle = 5.0
        op.preset_name = "Almost Parallel"
        
        row = box.row(align=True)
        op = row.operator(ANGLE_EDGES_OT_SelectPreset.bl_idname, text="Slightly Angled (5-15°)")
        op.min_angle = 5.0
        op.max_angle = 15.0
        op.preset_name = "Slightly Angled"
        
        row = box.row(align=True)
        op = row.operator(ANGLE_EDGES_OT_SelectPreset.bl_idname, text="Medium Angles (15-45°)")
        op.min_angle = 15.0
        op.max_angle = 45.0
        op.preset_name = "Medium Angles"
        
        row = box.row(align=True)
        op = row.operator(ANGLE_EDGES_OT_SelectPreset.bl_idname, text="Sharp Angles (29-180°)")
        op.min_angle = 29.0
        op.max_angle = 180.0
        op.preset_name = "Sharp Angles"

def update_max_angle(self, context):
    # Ensure max is always >= min
    if context.scene.angle_edges_max_angle < context.scene.angle_edges_min_angle:
        context.scene.angle_edges_max_angle = context.scene.angle_edges_min_angle

def update_min_angle(self, context):
    # Ensure min is always <= max
    if context.scene.angle_edges_min_angle > context.scene.angle_edges_max_angle:
        context.scene.angle_edges_min_angle = context.scene.angle_edges_max_angle

def register():
    bpy.utils.register_class(SelectEdgesByAngleOperator)
    bpy.utils.register_class(ANGLE_EDGES_OT_SelectPreset)
    bpy.utils.register_class(MESH_PT_AngleEdgesPanel)
    
    bpy.utils.register_class(OBJECT_PT_toggle_select_edges_by_angle_range_panel)
    bpy.types.WindowManager.select_edges_by_angle_range_panel_visible = bpy.props.BoolProperty(default=False)
    
    # Register properties for the panel
    bpy.types.Scene.angle_edges_min_angle = bpy.props.FloatProperty(
        name="Min Angle", 
        description="Minimum angle between face normals (degrees)",
        default=0.0,
        min=0.0,
        max=180.0,
        update=update_min_angle
    )
    
    bpy.types.Scene.angle_edges_max_angle = bpy.props.FloatProperty(
        name="Max Angle", 
        description="Maximum angle between face normals (degrees)",
        default=5.0,
        min=0.0,
        max=180.0,
        update=update_max_angle
    )

def unregister():
    bpy.utils.unregister_class(SelectEdgesByAngleOperator)
    bpy.utils.unregister_class(ANGLE_EDGES_OT_SelectPreset)
    bpy.utils.unregister_class(MESH_PT_AngleEdgesPanel)
    bpy.utils.unregister_class(OBJECT_PT_toggle_select_edges_by_angle_range_panel)
    # Remove properties
    del bpy.types.Scene.angle_edges_min_angle
    del bpy.types.Scene.angle_edges_max_angle
    del bpy.types.WindowManager.select_edges_by_angle_range_panel_visible
    
if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_select_edges_by_angle_range_panel()