import bpy

# Initialize variables to track the largest object and its volume
largest_obj = None
largest_volume = 0  # Start with a very small number (0)

# Loop through all objects in the scene
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':  # Only consider mesh objects
        # Calculate the size of the object using its bounding box dimensions
        bbox = obj.bound_box
        
        # Calculate the volume of the bounding box: width * height * depth
        width = abs(bbox[0][0] - bbox[4][0])  # Distance between min/max X
        height = abs(bbox[0][1] - bbox[2][1])  # Distance between min/max Y
        depth = abs(bbox[0][2] - bbox[1][2])  # Distance between min/max Z
        volume = width * height * depth  # Calculate the volume
        
        # Check if the current object is the largest one so far
        if volume > largest_volume:
            largest_volume = volume
            largest_obj = obj

# Select the largest object by volume
if largest_obj:
    bpy.ops.object.select_all(action='DESELECT')  # Deselect all objects
    largest_obj.select_set(True)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"The largest object by volume is: {largest_obj.name}", duration=5)
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No mesh objects found in the scene.", duration=5)
