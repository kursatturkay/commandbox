#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Clear All Seams (Cyan Edges).
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class MESH_OT_clear_all_sharp_edges(bpy.types.Operator):
    """Clear all sharp edges from the active mesh and report how many were cleared"""
    bl_idname = "mesh.clear_all_sharp_edges"
    bl_label = "Clear All Sharp Edges"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == 'MESH'
    
    def execute(self, context):
        obj = context.active_object
        mesh = obj.data
        
        original_mode = obj.mode
        
        if original_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        sharp_count = 0
        for edge in mesh.edges:
            if edge.use_edge_sharp:
                sharp_count += 1
        
        for edge in mesh.edges:
            edge.use_edge_sharp = False
        
        bpy.ops.object.mode_set(mode=original_mode)
        
        textinfo_= f"{sharp_count} sharp edges cleared"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(MESH_OT_clear_all_sharp_edges)

def unregister():
    bpy.utils.unregister_class(MESH_OT_clear_all_sharp_edges)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.clear_all_sharp_edges()