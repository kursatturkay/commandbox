#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Random Shading.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
from bpy.props import StringProperty, BoolProperty

# Scene properties tanımlama
def register_properties():
    bpy.types.Scene.previous_shading_type = StringProperty(
        name="Previous Shading Type",
        default="SOLID"
    )
    bpy.types.Scene.previous_color_type = StringProperty(
        name="Previous Color Type",
        default="MATERIAL"
    )
    bpy.types.Scene.is_random_shading = BoolProperty(
        name="Is Random Shading",
        default=False
    )

class ToggleRandomShading(bpy.types.Operator):
    bl_idname = "view3d.toggle_random_shading"
    bl_label = "Toggle Random Shading"
    bl_description = "Toggle between random shading and previous shading settings"
    
    def execute(self, context):
        shading = context.space_data.shading
        scene = context.scene
        
        # Gerçek shading durumunu kontrol et
        is_currently_random = (shading.type == 'SOLID' and shading.color_type == 'RANDOM')
        
        if not is_currently_random:
            # Mevcut ayarları sakla
            scene.previous_shading_type = shading.type
            scene.previous_color_type = shading.color_type
            
            # Random shading'i aktif et
            shading.type = 'SOLID'
            shading.color_type = 'RANDOM'
            scene.is_random_shading = True
        else:
            # Önceki ayarlara geri dön
            shading.type = scene.previous_shading_type
            shading.color_type = scene.previous_color_type
            scene.is_random_shading = False
            
        return {'FINISHED'}

def register():
    register_properties()
    bpy.utils.register_class(ToggleRandomShading)

def unregister():
    del bpy.types.Scene.previous_shading_type
    del bpy.types.Scene.previous_color_type
    del bpy.types.Scene.is_random_shading
    bpy.utils.unregister_class(ToggleRandomShading)

if __name__ == "__main__":
    register()
    bpy.ops.view3d.toggle_random_shading()