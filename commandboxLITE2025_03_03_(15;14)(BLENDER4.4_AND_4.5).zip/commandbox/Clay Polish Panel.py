#once "Clay Polish" is Run, its also accessable in F3 Menu via "Clay Polish Operator". undo and access it using F3 will open settings.
import bpy
import bmesh

# Clay Polish fonksiyonu
def clay_polish(obj, smooth_iterations=10, sharpness=0.5, bevel_width=0.01, bevel_segments=3, bevel_profile=0.7):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    
    mesh = bmesh.from_edit_mesh(obj.data)
    
    for _ in range(smooth_iterations):
        bmesh.ops.smooth_vert(mesh, verts=mesh.verts, factor=sharpness, use_axis_x=True, use_axis_y=True, use_axis_z=True)
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # Bevel Modifier Ekleme
    bevel_modifier = obj.modifiers.new(name="Bevel", type='BEVEL')
    bevel_modifier.width = bevel_width
    bevel_modifier.segments = bevel_segments
    bevel_modifier.profile = bevel_profile
    
    bpy.ops.object.modifier_apply(modifier=bevel_modifier.name)
    
    bpy.ops.object.mode_set(mode='EDIT')
    bmesh.update_edit_mesh(obj.data)

# Operatör Tanımlaması
class ClayPolishOperator(bpy.types.Operator):
    """Apply Clay Polish with customizable settings"""
    bl_idname = "object.clay_polish_operator"
    bl_label = "Clay Polish Operator"
    bl_options = {'REGISTER', 'UNDO'}

    smooth_iterations: bpy.props.IntProperty(
        name="Smooth Iterations",
        description="Number of smoothing iterations",
        default=10,
        min=1,
        max=200
    )
    sharpness: bpy.props.FloatProperty(
        name="Sharpness",
        description="Sharpness factor for smoothing",
        default=0.5,
        min=0.0,
        max=1.0
    )
    bevel_width: bpy.props.FloatProperty(
        name="Bevel Width",
        description="Width of the bevel (minimum 0.01)",
        default=0.01,
        min=0.01,  # Minimum değeri 0.01 olarak belirledik
        max=10.0
    )
    bevel_segments: bpy.props.IntProperty(
        name="Bevel Segments",
        description="Number of segments for the bevel",
        default=3,
        min=1,
        max=10
    )
    bevel_profile: bpy.props.FloatProperty(
        name="Bevel Profile",
        description="Profile of the bevel",
        default=0.7,
        min=0.0,
        max=1.0
    )

    def execute(self, context):
        obj = bpy.context.active_object
        if obj and obj.type == 'MESH':
            clay_polish(obj, smooth_iterations=self.smooth_iterations, sharpness=self.sharpness,
                        bevel_width=self.bevel_width, bevel_segments=self.bevel_segments,
                        bevel_profile=self.bevel_profile)
            bpy.ops.object.mode_set(mode='OBJECT')
        else:
            self.report({'WARNING'}, "Active object is not a mesh!")
        return {'FINISHED'}


class OBJECT_PT_toggle_clay_polish_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_clay_polish_panel"
    bl_label = "Toggle Clay Polish Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.clay_polish_panel_visible = not context.window_manager.clay_polish_panel_visible

        if(context.window_manager.clay_polish_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
# Panel Tanımlaması
class ClayPolishPanel(bpy.types.Panel):
    bl_label = "Clay Polish"
    bl_idname = "OBJECT_PT_clay_polish_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "clay_polish_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_clay_polish_panel", text="", icon='CANCEL', emboss=False)
    
    def draw(self, context):
        layout = self.layout
        layout.operator("object.clay_polish_operator", text="Run Clay Polish")
        layout.prop(context.scene, "smooth_iterations")
        layout.prop(context.scene, "sharpness")
        layout.prop(context.scene, "bevel_width")
        layout.prop(context.scene, "bevel_segments")
        layout.prop(context.scene, "bevel_profile")

# Register/Unregister sınıfları
def register():
    bpy.types.WindowManager.clay_polish_panel_visible = bpy.props.BoolProperty(default=False)
    bpy.utils.register_class(ClayPolishOperator)
    bpy.utils.register_class(OBJECT_PT_toggle_clay_polish_panel)
    bpy.utils.register_class(ClayPolishPanel)
    bpy.types.Scene.smooth_iterations = bpy.props.IntProperty(name="Smooth Iterations", default=10, min=1, max=100)
    bpy.types.Scene.sharpness = bpy.props.FloatProperty(name="Sharpness", default=0.5, min=0.0, max=1.0)
    bpy.types.Scene.bevel_width = bpy.props.FloatProperty(name="Bevel Width", default=0.01, min=0.01, max=1.0)
    bpy.types.Scene.bevel_segments = bpy.props.IntProperty(name="Bevel Segments", default=3, min=1, max=10)
    bpy.types.Scene.bevel_profile = bpy.props.FloatProperty(name="Bevel Profile", default=0.7, min=0.0, max=1.0)

def unregister():
    bpy.utils.unregister_class(ClayPolishOperator)
    bpy.utils.unregister_class(ClayPolishPanel)
    bpy.utils.unregister_class(OBJECT_PT_toggle_clay_polish_panel)
    del bpy.types.Scene.smooth_iterations
    del bpy.types.Scene.sharpness
    del bpy.types.Scene.bevel_width
    del bpy.types.Scene.bevel_segments
    del bpy.types.Scene.bevel_profile
    del bpy.types.WindowManager.clay_polish_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_clay_polish_panel()
    #bpy.ops.object.clay_polish_operator('INVOKE_DEFAULT')





# import bpy
# import bmesh

# def clay_polish(obj, smooth_iterations=10, sharpness=0.5):
    
#     bpy.context.view_layer.objects.active = obj
#     bpy.ops.object.mode_set(mode='EDIT')
    
    
#     mesh = bmesh.from_edit_mesh(obj.data)
    
    
#     for _ in range(smooth_iterations):
#         bmesh.ops.smooth_vert(mesh, verts=mesh.verts, factor=sharpness, use_axis_x=True, use_axis_y=True, use_axis_z=True)
    
    
#     bpy.ops.object.mode_set(mode='OBJECT')
#     bpy.ops.object.modifier_add(type='BEVEL')
#     obj.modifiers[-1].width = 0.01  
#     obj.modifiers[-1].segments = 3  
#     obj.modifiers[-1].profile = 0.7 
    
    
#     bpy.ops.object.modifier_apply(modifier=obj.modifiers[-1].name)
    
    
#     bpy.ops.object.mode_set(mode='EDIT')
#     bmesh.update_edit_mesh(obj.data)


# obj = bpy.context.active_object
# if obj and obj.type == 'MESH':
#     clay_polish(obj, smooth_iterations=10, sharpness=0.3)
#     bpy.ops.object.mode_set(mode='OBJECT')






# import bpy
# import bmesh

# def clay_polish(obj, smooth_iterations=10, sharpness=0.5):
    
#     bpy.context.view_layer.objects.active = obj
#     bpy.ops.object.mode_set(mode='EDIT')
    
    
#     mesh = bmesh.from_edit_mesh(obj.data)
    
    
#     for _ in range(smooth_iterations):
#         bmesh.ops.smooth_vert(mesh, verts=mesh.verts, factor=sharpness, use_axis_x=True, use_axis_y=True, use_axis_z=True)
    
    
#     bpy.ops.object.mode_set(mode='OBJECT')
#     bpy.ops.object.modifier_add(type='BEVEL')
#     obj.modifiers[-1].width = 0.01  
#     obj.modifiers[-1].segments = 3  
#     obj.modifiers[-1].profile = 0.7 
    
    
#     bpy.ops.object.modifier_apply(modifier=obj.modifiers[-1].name)
    
    
#     bpy.ops.object.mode_set(mode='EDIT')
#     bmesh.update_edit_mesh(obj.data)


# obj = bpy.context.active_object
# if obj and obj.type == 'MESH':
#     clay_polish(obj, smooth_iterations=10, sharpness=0.3)
#     bpy.ops.object.mode_set(mode='OBJECT')