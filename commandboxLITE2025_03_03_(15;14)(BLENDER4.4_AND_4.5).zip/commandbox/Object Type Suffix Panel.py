#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Object Type Suffix Panel.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import re

bl_info = {
    "name": "Object Type Name Suffix",
    "blender": (4, 3, 2),
    "category": "Object",
    "author": "fables alive games",
    "description": "Adds customizable object type suffix to object names and data blocks",
    "version": (1, 9),
}

# Varsayılan suffixler
default_suffixes = {
    'MESH': '_MESH',
    'CURVE': '_CURVE',
    'SURFACE': '_SURFACE',
    'META': '_META',
    'FONT': '_TEXT',
    'ARMATURE': '_ARM',
    'BONE': '_BONE',
    'LATTICE': '_LATTICE',
    'EMPTY': '_EMPTY',
    'LIGHT': '_LIGHT',
    'CAMERA': '_CAMERA',
    'SPEAKER': '_SPEAKER',
    'LIGHT_PROBE': '_PROBE',
    'GPENCIL': '_GPENCIL',
    'POINTCLOUD': '_POINTCLOUD',
    'VOLUME': '_VOLUME',
    'HAIR': '_HAIR',
    'COLLECTION': '_COL'
}

# Data block suffixler
data_block_suffixes = {
    'MESH': '_MESH_DATA',
    'CURVE': '_CURVE_DATA',
    'SURFACE': '_SURFACE_DATA',
    'META': '_META_DATA',
    'FONT': '_TEXT_DATA',
    'ARMATURE': '_ARM_DATA',
    'LATTICE': '_LATTICE_DATA',
    'LIGHT': '_LIGHT_DATA',
    'CAMERA': '_CAMERA_DATA',
    'SPEAKER': '_SPEAKER_DATA',
    'GPENCIL': '_GPENCIL_DATA',
    'POINTCLOUD': '_POINTCLOUD_DATA',
    'VOLUME': '_VOLUME_DATA',
    'HAIR': '_HAIR_DATA',
    'MATERIAL': '_MAT',
    'TEXTURE': '_TEX',
    'IMAGE': '_IMG',
    'ACTION': '_ACT',
    'NODETREE': '_NODE',
    'WORLD': '_WORLD',
    'SCENE': '_SCENE'
}


class ObjectSuffixItem(bpy.types.PropertyGroup):
    object_type: bpy.props.StringProperty()
    suffix: bpy.props.StringProperty()


class DataBlockSuffixItem(bpy.types.PropertyGroup):
    data_type: bpy.props.StringProperty()
    suffix: bpy.props.StringProperty()


class ObjectSuffixProperties(bpy.types.PropertyGroup):
    suffix_list: bpy.props.CollectionProperty(type=ObjectSuffixItem)
    data_suffix_list: bpy.props.CollectionProperty(type=DataBlockSuffixItem)
    index: bpy.props.IntProperty(default=0)
    data_index: bpy.props.IntProperty(default=0)
    apply_to_data_blocks: bpy.props.BoolProperty(
        name="Apply to Data Blocks",
        description="Apply suffixes to data blocks as well",
        default=True
    )


def ensure_defaults(scene):
    """Varsayılan suffix listesini oluşturur"""
    props = scene.object_suffix_props
    
    # Object suffix listesi
    if not props.suffix_list:
        for obj_type, suffix in default_suffixes.items():
            item = props.suffix_list.add()
            item.object_type = obj_type
            item.suffix = suffix
    
    # Data block suffix listesi
    if not props.data_suffix_list:
        for data_type, suffix in data_block_suffixes.items():
            item = props.data_suffix_list.add()
            item.data_type = data_type
            item.suffix = suffix


def clean_name(name):
    """Mevcut objenin veya kemiğin adından eski suffix'i temizler"""
    return re.sub(r"(_[A-Za-z0-9_]+)?$", "", name)


class OBJECT_UL_SuffixList(bpy.types.UIList):
    """UIList için özel gösterim"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        self.use_filter_show = False  # Filtre satırını gizler
        row = layout.row()
        row.label(text=item.object_type)
        row.prop(item, "suffix", text="")


class DATA_UL_SuffixList(bpy.types.UIList):
    """Data block UIList için özel gösterim"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        self.use_filter_show = False  # Filtre satırını gizler
        row = layout.row()
        row.label(text=item.data_type)
        row.prop(item, "suffix", text="")


def apply_suffix_to_collections():
    for collection in bpy.data.collections:
        collection.name = clean_name(collection.name) + default_suffixes.get('COLLECTION', '')


def apply_suffix_to_datablocks(data_suffix_list):
    # Convert list to dictionary for easier lookup
    data_suffixes = {item.data_type: item.suffix for item in data_suffix_list}
    
    # Apply to mesh data
    for mesh in bpy.data.meshes:
        mesh.name = clean_name(mesh.name) + data_suffixes.get('MESH', '')
    
    # Apply to materials
    for material in bpy.data.materials:
        material.name = clean_name(material.name) + data_suffixes.get('MATERIAL', '')
        
    # Apply to textures
    for texture in bpy.data.textures:
        texture.name = clean_name(texture.name) + data_suffixes.get('TEXTURE', '')
        
    # Apply to images
    for image in bpy.data.images:
        image.name = clean_name(image.name) + data_suffixes.get('IMAGE', '')
    
    # Apply to armature data
    for armature in bpy.data.armatures:
        armature.name = clean_name(armature.name) + data_suffixes.get('ARMATURE', '')
    
    # Apply to curve data
    for curve in bpy.data.curves:
        curve.name = clean_name(curve.name) + data_suffixes.get('CURVE', '')
    
    # Apply to camera data
    for camera in bpy.data.cameras:
        camera.name = clean_name(camera.name) + data_suffixes.get('CAMERA', '')
    
    # Apply to light data
    for light in bpy.data.lights:
        light.name = clean_name(light.name) + data_suffixes.get('LIGHT', '')
    
    # Apply to speaker data
    for speaker in bpy.data.speakers:
        speaker.name = clean_name(speaker.name) + data_suffixes.get('SPEAKER', '')
    
    # Apply to lattice data
    for lattice in bpy.data.lattices:
        lattice.name = clean_name(lattice.name) + data_suffixes.get('LATTICE', '')
    
    # Apply to metaballs
    for metaball in bpy.data.metaballs:
        metaball.name = clean_name(metaball.name) + data_suffixes.get('META', '')
    
    # Apply to nodegroups
    for nodetree in bpy.data.node_groups:
        nodetree.name = clean_name(nodetree.name) + data_suffixes.get('NODETREE', '')
    
    # Apply to worlds
    for world in bpy.data.worlds:
        world.name = clean_name(world.name) + data_suffixes.get('WORLD', '')
    
    # Apply to actions
    for action in bpy.data.actions:
        action.name = clean_name(action.name) + data_suffixes.get('ACTION', '')
    
    # Apply to grease pencil data
    for gpencil in bpy.data.grease_pencils:
        gpencil.name = clean_name(gpencil.name) + data_suffixes.get('GPENCIL', '')
    
    # Apply to hair data
    for hair in bpy.data.hair_curves:
        hair.name = clean_name(hair.name) + data_suffixes.get('HAIR', '')
    
    # Apply to pointclouds
    for pointcloud in bpy.data.pointclouds:
        pointcloud.name = clean_name(pointcloud.name) + data_suffixes.get('POINTCLOUD', '')
    
    # Apply to volumes
    for volume in bpy.data.volumes:
        volume.name = clean_name(volume.name) + data_suffixes.get('VOLUME', '')


class OBJECT_OT_AddSuffix(bpy.types.Operator):
    """Add type suffix to object names including bones"""
    bl_idname = "object.add_type_suffix"
    bl_label = "Apply Suffixes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        props = context.scene.object_suffix_props
        
        # Convert lists to dictionaries for easier lookup
        obj_suffixes = {item.object_type: item.suffix for item in props.suffix_list}
        
        objects = bpy.context.selected_objects if bpy.context.selected_objects else bpy.context.scene.objects
        
        for obj in objects:
            if obj.type == 'ARMATURE':
                obj.name = clean_name(obj.name) + obj_suffixes.get('ARMATURE', '')
                for bone in obj.data.bones:
                    bone.name = clean_name(bone.name) + obj_suffixes.get('BONE', '')
            else:
                suffix = obj_suffixes.get(obj.type, '')
                if suffix:
                    obj.name = clean_name(obj.name) + suffix
        
        apply_suffix_to_collections()  # Koleksiyonlara da suffix ekleyelim
        
        # Data block suffixleri de uygulayalım
        if props.apply_to_data_blocks:
            apply_suffix_to_datablocks(props.data_suffix_list)
        
        return {'FINISHED'}


class OBJECT_PT_toggle_ObjectTypeSuffixPanel(bpy.types.Operator):
    bl_idname = "wm.toggle_toggle_object_type_suffix_panel"
    bl_label = "Toggle Object Type Suffix Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.object_type_suffix_panel_visible = not context.window_manager.object_type_suffix_panel_visible

        if(context.window_manager.object_type_suffix_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}


class OBJECT_PT_TypeSuffixPanel(bpy.types.Panel):
    """Panel for customizing suffixes"""
    bl_label = "Object Type Suffix"
    bl_idname = "OBJECT_PT_type_suffix_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "object_type_suffix_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_toggle_object_type_suffix_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        props = context.scene.object_suffix_props

        # Object suffixes
        box = layout.box()
        box.label(text="Object Suffixes:")
        row = box.row()
        row.template_list("OBJECT_UL_SuffixList", "", props, "suffix_list", props, "index", rows=6)
        
        # Data Block suffixes
        box = layout.box()
        box.prop(props, "apply_to_data_blocks")
        if props.apply_to_data_blocks:
            box.label(text="Data Block Suffixes:")
            row = box.row()
            row.template_list("DATA_UL_SuffixList", "", props, "data_suffix_list", props, "data_index", rows=6)
        
        layout.operator("object.add_type_suffix", text="Apply All Suffixes")


def register():
    bpy.utils.register_class(OBJECT_PT_toggle_ObjectTypeSuffixPanel)

    bpy.utils.register_class(ObjectSuffixItem)
    bpy.utils.register_class(DataBlockSuffixItem)
    bpy.utils.register_class(ObjectSuffixProperties)
    bpy.utils.register_class(OBJECT_UL_SuffixList)
    bpy.utils.register_class(DATA_UL_SuffixList)
    bpy.utils.register_class(OBJECT_OT_AddSuffix)
    bpy.utils.register_class(OBJECT_PT_TypeSuffixPanel)

    bpy.types.Scene.object_suffix_props = bpy.props.PointerProperty(type=ObjectSuffixProperties)
    bpy.types.WindowManager.object_type_suffix_panel_visible=bpy.props.BoolProperty(default=False)

    ensure_defaults(bpy.context.scene)

def unregister():
    bpy.utils.unregister_class(ObjectSuffixItem)
    bpy.utils.unregister_class(DataBlockSuffixItem)
    bpy.utils.unregister_class(ObjectSuffixProperties)
    bpy.utils.unregister_class(OBJECT_UL_SuffixList)
    bpy.utils.unregister_class(DATA_UL_SuffixList)
    bpy.utils.unregister_class(OBJECT_OT_AddSuffix)
    bpy.utils.unregister_class(OBJECT_PT_TypeSuffixPanel)
    bpy.utils.unregister_class(OBJECT_PT_toggle_ObjectTypeSuffixPanel)

    del bpy.types.Scene.object_suffix_props
    del bpy.types.WindowManager.object_type_suffix_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_toggle_object_type_suffix_panel()