# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Transfer Rotations.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def transfer_transforms(transfer_location=True, transfer_rotation=True, transfer_scale=True):
    
    selected_objects = bpy.context.selected_objects
    active_object = bpy.context.view_layer.objects.active  

    if active_object in selected_objects and len(selected_objects) > 1:
        
        source = active_object
        
        targets = [obj for obj in selected_objects if obj != source]
        
        if transfer_location:
            source_location = source.location
        if transfer_rotation:
            source_rotation = source.rotation_euler
        if transfer_scale:
            source_scale = source.scale
        
        for target in targets:
            if transfer_location:
                target.location = source_location
            if transfer_rotation:
                target.rotation_euler = source_rotation
            if transfer_scale:
                target.scale = source_scale
        
        textinfo_=f"Transforms transferred from {source.name} to {len(targets)} objects!"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
    else:
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        textinfo_="Please select at least two objects and ensure one is active!"

transfer_transforms(transfer_location=False, transfer_rotation=False, transfer_scale=True)
