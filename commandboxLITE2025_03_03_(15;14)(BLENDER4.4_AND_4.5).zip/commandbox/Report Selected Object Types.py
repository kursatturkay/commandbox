#Report Selected Object Types
import bpy

selected_objects = bpy.context.selected_objects

if selected_objects:
    object_types = {obj.type for obj in selected_objects}
    #bpy.context.workspace.status_text_set(f"Selected object types: {', '.join(object_types)}")
    textinfo_=f"Selected object types: {', '.join(object_types)}"
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
else:
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="No objects selected", duration=5)
    #bpy.context.workspace.status_text_set("No objects selected.")
