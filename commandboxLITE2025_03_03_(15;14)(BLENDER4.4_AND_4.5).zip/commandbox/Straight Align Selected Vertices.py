#
#① Aligns all selected vertices between the first and last selected vertices on the chosen axis. ② Select Edge Loop Or Vertices to align ③ Apply in NPanel > Command Box
bl_info = {
    "name": "Straight Align Selected Vertices",
    "author": "Fables Alive",
    "version": (2, 1),
    "blender": (4, 3, 0),
    "location": "View3D > Tool Shelf > Align Selected Vertices",
    "description": "Aligns all selected vertices between the first and last selected vertices on the chosen axis.",
    "warning": "",
    "wiki_url": "",
    "category": "Mesh",
}

import bpy
import bmesh
import os

#from bpy.utils import previews

# # Initialize preview collection for custom images
# preview_collections = {}

# def load_custom_icons():
#     pcoll = previews.new()
#     script_path = os.path.dirname(__file__)
#     icons_dir = os.path.join(script_path, "img")
#     pcoll.load("logo", os.path.join(icons_dir, "logo.png"), 'IMAGE')
#     preview_collections["main"] = pcoll

# def unload_custom_icons():
#     for pcoll in preview_collections.values():
#         previews.remove(pcoll)
#     preview_collections.clear()

class AlignVerticesX(bpy.types.Operator):
    """Align selected vertices between the first and last on the X axis"""
    bl_idname = "mesh.align_vertices_x"
    bl_label = "Align Vertices on X Axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = bpy.context.object.data
        bm = bmesh.from_edit_mesh(me)

        selected_verts = [v for v in bm.verts if v.select]
        if len(selected_verts) < 2:
            self.report({'WARNING'}, "Please select at least two vertices.")
            return {'CANCELLED'}

        first_vert = selected_verts[0]
        last_vert = selected_verts[-1]
        target_x = (first_vert.co.x + last_vert.co.x) / 2

        for v in selected_verts:
            v.co.x = target_x

        bmesh.update_edit_mesh(me, loop_triangles=True)
        return {'FINISHED'}

class AlignVerticesY(bpy.types.Operator):
    """Align selected vertices between the first and last on the Y axis"""
    bl_idname = "mesh.align_vertices_y"
    bl_label = "Align Vertices on Y Axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = bpy.context.object.data
        bm = bmesh.from_edit_mesh(me)

        selected_verts = [v for v in bm.verts if v.select]
        if len(selected_verts) < 2:
            self.report({'WARNING'}, "Please select at least two vertices.")
            return {'CANCELLED'}

        first_vert = selected_verts[0]
        last_vert = selected_verts[-1]
        target_y = (first_vert.co.y + last_vert.co.y) / 2

        for v in selected_verts:
            v.co.y = target_y

        bmesh.update_edit_mesh(me, loop_triangles=True)
        return {'FINISHED'}

class AlignVerticesZ(bpy.types.Operator):
    """Align selected vertices between the first and last on the Z axis"""
    bl_idname = "mesh.align_vertices_z"
    bl_label = "Align Vertices on Z Axis"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = bpy.context.object.data
        bm = bmesh.from_edit_mesh(me)

        selected_verts = [v for v in bm.verts if v.select]
        if len(selected_verts) < 2:
            self.report({'WARNING'}, "Please select at least two vertices.")
            return {'CANCELLED'}

        first_vert = selected_verts[0]
        last_vert = selected_verts[-1]
        target_z = (first_vert.co.z + last_vert.co.z) / 2

        for v in selected_verts:
            v.co.z = target_z

        bmesh.update_edit_mesh(me, loop_triangles=True)
        return {'FINISHED'}

class AlignVerticesAuto(bpy.types.Operator):
    """Automatically align selected vertices based on the axis orthogonal to the first and last vertex direction"""
    bl_idname = "mesh.align_vertices_auto"
    bl_label = "Auto Align Vertices"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        me = bpy.context.object.data
        bm = bmesh.from_edit_mesh(me)

        selected_verts = [v for v in bm.verts if v.select]
        if len(selected_verts) < 2:
            self.report({'WARNING'}, "Please select at least two vertices.")
            return {'CANCELLED'}

        first_vert = selected_verts[0]
        last_vert = selected_verts[-1]

        delta_x = abs(first_vert.co.x - last_vert.co.x)
        delta_y = abs(first_vert.co.y - last_vert.co.y)
        delta_z = abs(first_vert.co.z - last_vert.co.z)

        # Determine the axis orthogonal to the largest difference
        if delta_x >= delta_y and delta_x >= delta_z:
            # Align on Y and Z plane (orthogonal to X)
            target_y = (first_vert.co.y + last_vert.co.y) / 2
            target_z = (first_vert.co.z + last_vert.co.z) / 2
            for v in selected_verts:
                v.co.y = target_y
                v.co.z = target_z
        elif delta_y >= delta_x and delta_y >= delta_z:
            # Align on X and Z plane (orthogonal to Y)
            target_x = (first_vert.co.x + last_vert.co.x) / 2
            target_z = (first_vert.co.z + last_vert.co.z) / 2
            for v in selected_verts:
                v.co.x = target_x
                v.co.z = target_z
        else:
            # Align on X and Y plane (orthogonal to Z)
            target_x = (first_vert.co.x + last_vert.co.x) / 2
            target_y = (first_vert.co.y + last_vert.co.y) / 2
            for v in selected_verts:
                v.co.x = target_x
                v.co.y = target_y

        bmesh.update_edit_mesh(me, loop_triangles=True)
        return {'FINISHED'}

class AlignVerticesPanel(bpy.types.Panel):
    """Creates a tab in the Toolbar for aligning vertices"""
    bl_label = "Align Selected Vertices"
    bl_idname = "VIEW3D_PT_align_selected_vertices"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    def draw(self, context):
        layout = self.layout

        #pcoll = preview_collections.get("main", None)
        #if pcoll:
        #    icon = pcoll["logo"].icon_id
        #    row = layout.row()
        #    row.scale_y = 4.0  # Increase the height of the icon
        #    row.template_icon(icon_value=icon)

        row = layout.row()
        row.operator("mesh.align_vertices_x")
        row = layout.row()
        row.operator("mesh.align_vertices_y")
        row = layout.row()
        row.operator("mesh.align_vertices_z")
        row = layout.row()
        row.operator("mesh.align_vertices_auto")

def register():
    #load_custom_icons()
    bpy.utils.register_class(AlignVerticesX)
    bpy.utils.register_class(AlignVerticesY)
    bpy.utils.register_class(AlignVerticesZ)
    bpy.utils.register_class(AlignVerticesAuto)
    bpy.utils.register_class(AlignVerticesPanel)

def unregister():
    #unload_custom_icons()
    bpy.utils.unregister_class(AlignVerticesX)
    bpy.utils.unregister_class(AlignVerticesY)
    bpy.utils.unregister_class(AlignVerticesZ)
    bpy.utils.unregister_class(AlignVerticesAuto)
    bpy.utils.unregister_class(AlignVerticesPanel)

def toggle():
    
    if hasattr(bpy.types, "VIEW3D_PT_align_selected_vertices"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented  
        bpy.utils.unregister_class(bpy.types.VIEW3D_PT_align_selected_vertices)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
        register()

# İlk çalıştırma (register yapılacak)
if __name__ == "__main__":
    toggle()
