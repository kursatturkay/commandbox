#  Deselects All. Selects Only Curves in Scene.
import bpy


bpy.ops.object.select_all(action='DESELECT')


for obj in bpy.context.scene.objects:
    if obj.type == 'CURVE':
        obj.select_set(True)
