#https://www.youtube.com/watch?v=ZnxC3jXdo0E
#  Activates System Console Window and Clears
import os
import platform
import ctypes

def clear_console():
    if platform.system() == "Windows":
        os.system("cls")
    else:
        os.system("clear")

def show_system_console(show):
    #SW_HIDE = 0   SW_SHOW = 5
    ctypes.windll.user32.ShowWindow(
        ctypes.windll.kernel32.GetConsoleWindow(), 5 if show else 0
    )

def set_system_console_topmost(top):
    HWND_NOTOPMOST = -2
    HWND_TOPMOST = -1
    HWND_TOP = 0
    SWP_NOMOVE = 0x0002
    SWP_NOSIZE = 0x0001
    SWP_NOZORDER = 0x0004

    ctypes.windll.user32.SetWindowPos(
        ctypes.windll.kernel32.GetConsoleWindow(),
        HWND_TOP if top else HWND_NOTOPMOST,
        0,
        0,
        0,
        0,
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER,
    )

clear_console()

show_system_console(True)
set_system_console_topmost(True)