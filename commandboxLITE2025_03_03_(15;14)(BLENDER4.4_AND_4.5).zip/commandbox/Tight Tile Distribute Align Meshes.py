#https://www.youtube.com/watch?v=hkrR7eZaYhM
#Tight Tile Distribute Align Meshes. Select Meshes that needs to be aligned. Apply Magic ; ) 
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import math

def get_bounding_box_size(obj):
    min_corner = [min(v[i] for v in obj.bound_box) for i in range(3)]
    max_corner = [max(v[i] for v in obj.bound_box) for i in range(3)]
    return (max_corner[0] - min_corner[0], max_corner[1] - min_corner[1], max_corner[2] - min_corner[2])

class OBJECT_OT_TightTileDistributeAlignMeshes(bpy.types.Operator):
    bl_idname = "object.tight_tile_distribute_align_meshes"
    bl_label = "Tight Tile Distribute Align Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected_objects:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        selected_objects.sort(key=lambda obj: get_bounding_box_size(obj)[0], reverse=True)
        
        max_width = max(get_bounding_box_size(obj)[0] for obj in selected_objects)
        max_height = max(get_bounding_box_size(obj)[1] for obj in selected_objects)

        num_objects = len(selected_objects)
        grid_size = math.ceil(math.sqrt(num_objects))  
        
        start_x, start_y = 0, 0
        for index, obj in enumerate(selected_objects):
            row = index // grid_size
            col = index % grid_size
            new_x = start_x + col * max_width
            new_y = start_y - row * max_height  
            obj.location = (new_x, new_y, obj.location.z)

        return {'FINISHED'}

def register():
    bpy.utils.register_class(OBJECT_OT_TightTileDistributeAlignMeshes)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_TightTileDistributeAlignMeshes)

if __name__ == "__main__":
    register()
    bpy.ops.object.tight_tile_distribute_align_meshes()
