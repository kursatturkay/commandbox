#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Mesh Wireframe.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy


selected_objects = bpy.context.selected_objects


mesh_objects = [obj for obj in selected_objects if obj.type == 'MESH']


previous_display_types = {}


if mesh_objects:
    for obj in mesh_objects:
        if obj.name not in previous_display_types:
            
            previous_display_types[obj.name] = obj.display_type
        
        
        if obj.display_type == 'WIRE':
            obj.display_type = previous_display_types[obj.name]
        else:
            
            obj.display_type = 'WIRE'
else:
    
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.display_type = 'SOLID'  
