#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Weight Paint to Vertex Paint Panel.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh

def weight_to_vertex_paint(obj):
    if obj.type != 'MESH':
        print("Error: This function only works on mesh objects.")
        return
    
    if not obj.data.vertex_colors:
        obj.data.vertex_colors.new(name="WeightToVertex")
    
    vcol_layer = obj.data.vertex_colors.active
    
    if not obj.data.vertices or not obj.data.polygons:
        print("Error: No valid vertices or faces found.")
        return
    
    weight_group = obj.vertex_groups.active
    if not weight_group:
        print("Error: No active weight group found.")
        return
    
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.faces.ensure_lookup_table()
    
    loop_colors = bm.loops.layers.color.get("WeightToVertex")
    if not loop_colors:
        loop_colors = bm.loops.layers.color.new("WeightToVertex")
    
    def weight_to_color(weight):
        return (weight, max(0.0, 1.0 - 2.0 * abs(weight - 0.5)), 1.0 - weight, 1.0)
    
    for face in bm.faces:
        for loop in face.loops:
            vert = loop.vert
            weight = 0.0
            
            try:
                weight = weight_group.weight(vert.index)
            except RuntimeError:
                weight = 0.0
            
            print(f"Vertex {vert.index} - Weight: {weight}")
            
            color = weight_to_color(weight)
            loop[loop_colors] = color
    
    bm.to_mesh(obj.data)
    bm.free()
    obj.data.update()
    print("Conversion from Weight Paint to Vertex Paint completed successfully!")

class WeightToVertexOperator(bpy.types.Operator):
    bl_idname = "object.weight_to_vertex"
    bl_label = "Weight to Vertex Paint"
    bl_description = "Convert active weight paint data to vertex paint"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        obj = context.object
        if obj:
            weight_to_vertex_paint(obj)
        return {'FINISHED'}


class OBJECT_PT_toggle_WeightToVertexPanel(bpy.types.Operator):
    bl_idname = "wm.toggle_weight_to_vertex_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.weight_paint_to_vertex_paint_panel_visible = not context.window_manager.weight_paint_to_vertex_paint_panel_visible

        if(context.window_manager.weight_paint_to_vertex_paint_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}

class WeightToVertexPanel(bpy.types.Panel):
    bl_label = "Weight Paint to Vertex Paint"
    bl_idname = "OBJECT_PT_weight_to_vertex"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "weight_paint_to_vertex_paint_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_weight_to_vertex_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        layout.operator("object.weight_to_vertex", text="Convert")

def register():
    bpy.utils.register_class(OBJECT_PT_toggle_WeightToVertexPanel)
    bpy.types.WindowManager.weight_paint_to_vertex_paint_panel_visible = bpy.props.BoolProperty(default=False)

    bpy.utils.register_class(WeightToVertexOperator)
    bpy.utils.register_class(WeightToVertexPanel)

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_toggle_WeightToVertexPanel)
    bpy.utils.unregister_class(WeightToVertexOperator)
    bpy.utils.unregister_class(WeightToVertexPanel)
    del bpy.types.WindowManager.weight_paint_to_vertex_paint_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_weight_to_vertex_panel()