# https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggles Meshes' ViewPort Display of Color Alpha / Opaque.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

def adjust_alpha_for_selected_meshes():
    
    selected_objects = bpy.context.selected_objects

    if selected_objects:
        for obj in selected_objects:
            
            if obj.type == 'MESH':
                
                if obj.display_type in ['SOLID','TEXTURED']:
                    alpha = obj.color[3]  

                    if alpha == 1:
                        obj.color[3] = 0.3
                    else:
                        obj.color[3] = 1

    
    else:
        
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH':
                if obj.display_type in ['SOLID','TEXTURED']:
                    if obj.color[3] != 1:
                        obj.color[3] = 1


adjust_alpha_for_selected_meshes()
