#https://www.youtube.com/watch?v=hZn1z-Sdvt0
#Select Faces By Edges Count Panel.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh

class SelectFacesProperties(bpy.types.PropertyGroup):
    edge_count_3: bpy.props.BoolProperty(name="3 Edges", default=False)
    edge_count_4: bpy.props.BoolProperty(name="4 Edges", default=False)
    edge_count_5_or_more: bpy.props.BoolProperty(name="5 or More Edges", default=False)

class SelectFacesByEdgesOperator(bpy.types.Operator):
    bl_idname = "mesh.select_faces_by_edges"
    bl_label = "Select Faces by Edge Count"
    bl_description = "Select faces based on the number of edges"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        props = context.scene.select_faces_props

        if obj and obj.type == 'MESH':
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='FACE') 
            bpy.ops.mesh.select_all(action='DESELECT')

            bm = bmesh.from_edit_mesh(obj.data)

            selected_count = 0

            for f in bm.faces:
                edge_count = len(f.edges)
                if (props.edge_count_3 and edge_count == 3) or \
                   (props.edge_count_4 and edge_count == 4) or \
                   (props.edge_count_5_or_more and edge_count >= 5):
                    f.select = True
                    selected_count += 1

            bmesh.update_edit_mesh(obj.data)
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='FACE')

            textinfo_=f"{selected_count} faces selected."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        else:
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="No mesh object selected.", duration=5)
        
        return {'FINISHED'}

class SCENE_OT_toggle_faces_by_edges_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_faces_by_edges_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.show_select_faces_by_edges_panel = not context.scene.show_select_faces_by_edges_panel

        if(context.scene.show_select_faces_by_edges_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()        
        return {'FINISHED'}
    
class SelectFacesPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_select_faces"
    bl_label = "Select Faces by Edges"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return context.scene.show_select_faces_by_edges_panel

    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("scene.toggle_faces_by_edges_panel", text="", icon ='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        props = context.scene.select_faces_props

        col = layout.column()
        col.label(text="Edge Count Selection:")
        col.prop(props, "edge_count_3")
        col.prop(props, "edge_count_4")
        col.prop(props, "edge_count_5_or_more")
        col.operator(SelectFacesByEdgesOperator.bl_idname, text="Select Faces")

classes = [
    SelectFacesProperties,
    SelectFacesByEdgesOperator,
    SelectFacesPanel,
    SCENE_OT_toggle_faces_by_edges_panel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.select_faces_props = bpy.props.PointerProperty(type=SelectFacesProperties)
    bpy.types.Scene.show_select_faces_by_edges_panel = bpy.props.BoolProperty(
        name="Show Select Faces By Edges Panel",
        default=False)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.select_faces_props
    del bpy.types.Scene.show_select_faces_by_edges_panel

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_faces_by_edges_panel()