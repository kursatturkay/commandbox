#
#Cycles between Object, Vertex, Edge, and Face modes (Hotkey: Alt+Q). autorun=True 
#autorun=True 

import bpy

class OBJECT_OT_toggle_object_edit_cycle(bpy.types.Operator):
    """Cycle between Object, Vertex, Edge, and Face modes"""  # Tooltip
    bl_idname = "object.toggle_object_edit_cycle"  # Unique identifier for the operator
    bl_label = "Toggle Object/Edit Mode Cycle"  # Display name in the UI
    bl_options = {'REGISTER', 'UNDO'}  # Enable undo support

    def execute(self, context):
        # Define the edit modes in order: Object -> Vertex -> Edge -> Face -> Object
        edit_modes = [
            'OBJECT',  # Object Mode
            (True, False, False),  # Vertex Mode
            (False, True, False),  # Edge Mode
            (False, False, True)   # Face Mode
        ]

        obj = context.active_object

        if not obj or obj.type != 'MESH':
            self.report({'WARNING'}, "Please select a mesh object")

            textinfo_="No valid object selected or object is not a mesh."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            return {'CANCELLED'}

        if obj.mode == 'OBJECT':  # If in Object Mode
            bpy.ops.object.mode_set(mode='EDIT')  # Switch to Edit Mode
            bpy.context.tool_settings.mesh_select_mode = edit_modes[1]  # Set to Vertex Mode
            
            textinfo_="Switched to Edit Mode: Vertex"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        elif obj.mode == 'EDIT':  # If in Edit Mode
            current_mode = tuple(bpy.context.tool_settings.mesh_select_mode)

            # Find the current edit mode index
            if current_mode in edit_modes[1:]:
                current_index = edit_modes.index(current_mode)
                next_index = (current_index + 1) % len(edit_modes)
            else:
                next_index = 1

            # If next mode is 'OBJECT', switch back to Object Mode
            if next_index == 0:
                bpy.ops.object.mode_set(mode='OBJECT')

                textinfo_="Switched to Object Mode"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            else:
                bpy.context.tool_settings.mesh_select_mode = edit_modes[next_index]
                mode_text = ["Vertex", "Edge", "Face"][next_index - 1]

                textinfo_=f"Switched to Edit Mode: {mode_text}"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}


# Keymap ekleme fonksiyonu
addon_keymaps = []

def register_keymap():
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

    if kc:  # Eğer bir keyconfig mevcutsa
        # Object Mode için kısayol
        km_object = kc.keymaps.new(name='Object Mode', space_type='EMPTY')
        kmi_object = km_object.keymap_items.new(
            OBJECT_OT_toggle_object_edit_cycle.bl_idname,
            type='Q',
            value='PRESS',
            shift=False,
            alt=True
        )
        addon_keymaps.append((km_object, kmi_object))

        # Edit Mode (Mesh) için kısayol
        km_edit_mesh = kc.keymaps.new(name='Mesh', space_type='EMPTY')
        kmi_edit_mesh = km_edit_mesh.keymap_items.new(
            OBJECT_OT_toggle_object_edit_cycle.bl_idname,
            type='Q',
            value='PRESS',
            shift=False,
            alt=True
        )
        addon_keymaps.append((km_edit_mesh, kmi_edit_mesh))

def unregister_keymap():
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


# Register and Unregister
def register():
    bpy.utils.register_class(OBJECT_OT_toggle_object_edit_cycle)
    register_keymap()

def unregister():
    unregister_keymap()
    bpy.utils.unregister_class(OBJECT_OT_toggle_object_edit_cycle)

if __name__ == "__main__":
    register()