import bpy
import json
import os
import bpy.app.timers

from bpy.app.handlers import persistent

# #--------------------------------------------------------
# import importlib
# import sys

# if "_modal_draw_operator" in sys.modules:
#     importlib.reload(sys.modules["_modal_draw_operator"])
# else:
#     from . import _modal_draw_operator

# #--------------------------------------------------------
from . import _modal_draw_operator  # _modal_draw_operator dosyasını içeri aktar
from . import _toggle_n_panel

import bpy.utils.previews
icons_dict = bpy.utils.previews.new()

global autorun
autorun=True

bl_info = {
    "name": "CommandBox",
    "blender": (4, 3, 0),
    "category": 'Command Box',
    "location": "Tool > Fables Alive Games > CommandBox",
    "author": "Fables Alive Games",
    "description": "CommandBox by Fables Alive Games",
    "version": (2024, 12, 21),
    "support": "COMMUNITY"
}


def run_autorun_scripts():
    # Eklenti ayarlarından JSON dosyasının yolunu al
    preferences = bpy.context.preferences.addons[__package__].preferences
    scripts_dir = os.path.dirname(preferences.json_file_path)
    #print(f"<<<<<<<<<<<<<<<<<<<<scripts_dir:{scripts_dir}>>>>>>>>>>>>>>>>>>>>>>>>>>>>")

    # Dizindeki tüm .py dosyalarını tara
    for file_name in os.listdir(scripts_dir):
        if file_name.endswith(".py"):
            script_path = os.path.join(scripts_dir, file_name)
            try:
                # Dosyanın 3. satırını oku
                with open(script_path, 'r', encoding='utf-8') as script_file:
                    lines = script_file.readlines()
                    
                    if len(lines) >= 3:
                        line = lines[2]  # 3. line
                        if re.match(r"^\s*#\s*autorun\s*=\s*True\s*$", line.strip(), re.IGNORECASE):
                            line.strip().startswith("#autorun=True")
                        # Dosyayı çalıştır
                            bpy.ops.script.python_file_run(filepath=script_path)
            except Exception as e:
                print(f"{file_name} işlenirken hata oluştu: {e}")
    
    return None #tiemr durması için


addon_keymaps = []

def register_keymap():
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name="Window", space_type='EMPTY', region_type='WINDOW')
    km1 = km.keymap_items.new("commandbox.run_script", 'F5', 'PRESS')
    print(f"Keymap 1 (km1) is assigned? {km1}")
    km2 = km.keymap_items.new("commandbox.search_operator", 'X', 'PRESS', alt=True)
    km3 = km.keymap_items.new("view3d.toggle_n_panel_command_box", 'X', 'PRESS', ctrl=True, alt=True)
    addon_keymaps.append((km, [km1, km2, km3]))

def unregister_keymap():
    wm = bpy.context.window_manager
    for km, kmi_list in addon_keymaps:
        for kmi in kmi_list:
            km.keymap_items.remove(kmi)

    addon_keymaps.clear()


def get_icon_value(icon_name: str) -> int:
    icon_items = bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.items()
    icon_dict = {tup[1].identifier : tup[1].value for tup in icon_items}

    return icon_dict[icon_name]

def get_commandbox_items(self, context):
    scene = context.scene
    items = scene.commandbox_collection

    #run_icon_id=icons_collection.get("run").icon_id
    #icon = self.layout.icon('SCRIPTSPLUGIN')
    #icons = bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys()

    #iconid=get_icon_value('FILE_SCRIPT')

    return [(item.name, item.name, "") for item in items]

class COMMANDBOX_OT_SearchOperator(bpy.types.Operator):
    bl_idname = "commandbox.search_operator"
    bl_label = "Search Commands"
    bl_property = "search_enum"

    search_enum: bpy.props.EnumProperty(
        name="Commands",
        description="Search through CommandBox items",
        items=get_commandbox_items,
    )

    #def delayed_execution(self):
    #    bpy.ops.commandbox.run_script()
    #    return None  # Timer'ın yalnızca bir kez çalışması için None döner

    def execute(self, context):

        scene = context.scene
        selected_name = self.search_enum


        # Seçilen öğeyi indeksine göre bul
        global autorun
        autorun=False
        for index, item in enumerate(scene.commandbox_collection):
            if item.name == selected_name:
                scene.active_item_index = index
                break
        
        autorun=True
        # Hemen çalıştır
        #bpy.ops.commandbox.run_script()
        
        #Ya da Delayed çalıştır
        #bpy.app.timers.register(self.delayed_execution, first_interval=1)
        #-------------------------------------------
        #RUN SCRIPT
        preferences = context.preferences.addons[__package__].preferences

        script_path = os.path.join(
            os.path.dirname(preferences.json_file_path),f"{selected_name}.py")
        try:
            #bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=f"Selected Command Executed: {self.search_enum}", duration=5)
            #self.report({'INFO'}, f"Executed {script_path}.")
            bpy.ops.script.python_file_run(filepath=script_path)
            self.report({'INFO'}, f"Selected Command Executed: {self.search_enum}")
        except Exception as e:
            self.report({'ERROR'}, f"Error executing script: {e}")
        #-------------------------------------------
        return {'PASS_THROUGH'}
        #return {'FINISHED'}

        # # context.scene.active_item_index = next(
        # #     (i for i, item in enumerate(context.scene.commandbox_collection) if item.name == self.search_enum),
        # #     -1
        # # )
        # # if context.scene.active_item_index == -1:
        # #     self.report({'WARNING'}, "Selected item not found!")
        # #     return {'CANCELLED'}

        # # bpy.ops.commandbox.execute_item()
        # # return {'FINISHED'}

        #self.report({'INFO'}, f"Selected Command: {self.search_enum}")
        #bpy.ops.commandbox.execute_item()
        #return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.invoke_search_popup(self)
        return {'FINISHED'}
        #return {'RUNNING_MODAL'}

import re

class COMMANDBOX_OT_OpenYouTubeLink(bpy.types.Operator):
    bl_idname = "commandbox.open_youtube_link"
    bl_label = "Open YouTube Link"
    bl_description = "Open the YouTube link from the first line of the selected script"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        scene = context.scene
        items = scene.commandbox_collection

        if items:
            selected_item = items[scene.active_item_index].name
            script_path = os.path.join(
                os.path.dirname(preferences.json_file_path),
                f"{selected_item}.py")

            try:
                with open(script_path, 'r') as script_file:
                    first_line = script_file.readline().strip()

                    # Düzenli ifade ile kontrol
                    match = re.match(r"#\s*(https?://\S+)", first_line)
                    if match:
                        url = match.group(1)
                        import webbrowser
                        webbrowser.open(url)
                        info_ =f"Opened URL: {url}"
                        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=info_, duration=5)
                    else:
                        info_="YouTube help video not found in the first line."
                        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=info_, duration=5)
                        
            except Exception as e:
                info_= f"Error reading script: {e}"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=info_, duration=5)

        return {'FINISHED'}


class COMMANDBOX_OT_FloatingPanel(bpy.types.Operator):
    bl_idname = "commandbox.floating_panel"
    bl_label = "CommandBox Floating Panel"
    bl_description = "Open CommandBox in a floating panel"
    bl_options = {'REGISTER'}

    #width: bpy.props.IntProperty(name="Width", default=300)
    def invoke(self, context, event):
        #bpy.app.timers.register(lambda: bpy.ops.ui.search_menu('INVOKE_DEFAULT'), first_interval=0.1)
        #return context.window_manager.invoke_popup(self)

        return context.window_manager.invoke_popup(self)

        #width = 400
        #bpy.app.timers.register(self.focus_filter_field(context), first_interval=1)
        #return context.window_manager.invoke_popup(self,width=width)
        # {'RUNNING_MODAL'}

    def draw(self, context):
        layout = self.layout
        #layout.operator_context = 'INVOKE_REGION_WIN'
        scene = context.scene

        # Başlık
        #layout.label(text="CommandBox Commands", icon='SCRIPT')

        layout.operator("commandbox.search_operator", text="Search Commands")

        # Komut Listesi
        # # layout.template_list(
        # #     "COMMANDBOX_UL_Items",  # Liste sınıfı
        # #     "",  # Tip filtresi
        # #     scene,
        # #     "commandbox_collection",  # Veriler
        # #     scene,
        # #     "active_item_index",  # Aktif indeks
        # #     rows=15
        # # )

        # Düğme Satırı
        #row = layout.row()
        #layout.box()
        #row.label()#text=f"Double Click To Run Command")
        #row.operator("commandbox.execute_item", text="Run Command", icon='PLAY')
        #row.operator("commandbox.close_panel", text="Close", icon='CANCEL')

          # Eğer daha önce yüklenmemişse JSON'u yükle
        #if len(scene.commandbox_collection) == 0:
        #    bpy.app.timers.register(lambda: load_items_from_json(bpy.context),
        #                            first_interval=.1)


    def execute(self, context):
        return {'FINISHED'}

class COMMANDBOX_OT_ExecuteItem(bpy.types.Operator):
    bl_idname = "commandbox.execute_item"
    bl_label = "Execute Command"
    bl_description = "Execute the selected command"

    def execute(self, context):
        scene = context.scene
        active_index = scene.active_item_index

        if active_index < 0 or active_index >= len(scene.commandbox_collection):
            self.report({'WARNING'}, "No valid item selected!")
            return {'CANCELLED'}

        item = scene.commandbox_collection[active_index]



        # Burada liste öğesine bağlı komutu çalıştırabilirsiniz
        self.report({'INFO'}, f"Executed: {item.name}")
        return {'FINISHED'}


# Blender kullanıcı veri dizini altında bir 'Command Box' klasörü oluşturuyoruz
def get_default_json_path():
    # Blender'ın user resource directory'sini alıyoruz (örneğin SCRIPTS)
    #scripts_dir = bpy.utils.user_resource('SCRIPTS')

    # Eğer scripts_dir None ise, yani dizin bulunamazsa bir varsayılan dizin kullanıyoruz
    #if not scripts_dir:
    #    scripts_dir = os.path.expanduser("~")  # Ev dizini olarak varsayılan

    #C:\Users\pc0\AppData\Roaming\Blender Foundation\Blender\4.2\extensions\user_default\commandbox
    #C:\Users\pc0\AppData\Roaming\Blender Foundation\Blender\4.2\scripts\addons

    # commandbox adında bir alt klasör oluşturuyoruz
    #commandbox_dir = os.path.join(scripts_dir, "addons", "commandbox")
    commandbox_dir = os.path.dirname(__file__)
    commandbox_dir = os.path.join(commandbox_dir, "commandbox")

    # commandbox dizini yoksa oluşturuyoruz
    if not os.path.exists(commandbox_dir):
        os.makedirs(commandbox_dir)

    items_ffn = os.path.join(commandbox_dir, "items.json")
    print(f'items.json full file name is: {items_ffn}')
    # JSON dosyasının tam yolu
    return items_ffn


bpy.types.Scene.use_order_name = bpy.props.BoolProperty(
    name="Order by Name",
    description="Sort items alphabetically",
    default=False)

# Özelleştirilmiş öğe tanımı
class CommandBoxItem(bpy.types.PropertyGroup):
     name: bpy.props.StringProperty(name="Item Name")
     icon: bpy.props.IntProperty()
    #name: bpy.props.StringProperty(name="Item Name", options={'HIDDEN', 'SKIP_SAVE'})


class COMMANDBOX_OT_ToggleSortOrder(bpy.types.Operator):
    bl_idname = "commandbox.toggle_sort_order"
    bl_label = "Toggle Sort Order"
    bl_description = "Toggle alphabetical sorting"

    def execute(self, context):
        # UIList sınıfına erişim
        scene = context.scene
        scene.use_order_name = not scene.use_order_name

        #self.report({'INFO'}, f"Sorting set to: {'Enabled' if scene.use_order_name else 'Disabled'}")

        return {'FINISHED'}


# Operatör tanımlama
class ShowMessageOperator(bpy.types.Operator):
    bl_idname = "wm.show_message"
    bl_label = "Show Message"

    message: bpy.props.StringProperty(default="")

    def execute(self, context):
        context.workspace.status_text_set(self.message)
        bpy.context.workspace.status_text_set(self.message)
        self.report({'WARNING'}, self.message)
        return {'FINISHED'}


# Öğeleri listeleyen UI
commandbox_unique_first_words = []

class COMMANDBOX_UL_Items(bpy.types.UIList):
    bl_idname = "COMMANDBOX_UL_Items"
    bl_options = {'REGISTER'}

    def __init__(self):
        commandbox_unique_first_words = []  # İlk kelimeleri global yerine instance-level tanımla

    def draw_item(self, context, layout, data, item, icon, active_data, active_item, index):
        self.use_filter_show = True
        preferences = context.preferences.addons[__package__].preferences

        # İlk kelimeyi al
        first_word = item.name.split()[0].lower()  # Küçük harfe çevirerek benzersizliği artır
        # Eğer listeye eklenmemişse ekle
        if first_word not in commandbox_unique_first_words:
            commandbox_unique_first_words.append(first_word)

        #print(commandbox_unique_first_words)
        # Benzersiz listenin indexine göre color_grp hesapla
        color_grp = (commandbox_unique_first_words.index(first_word) % 9) + 1

        # UI elemanlarını oluştur
        row = layout.row()
        #row.label(text=f"{item.name}", icon=f'SEQUENCE_COLOR_0{color_grp}' if preferences.show_command_icons else "NONE")
        if preferences.show_command_icons:
            row.label(text=f"{item.name}", icon=f'SEQUENCE_COLOR_0{color_grp}')
        else:
            row.label(text=f"{item.name}")
        
        if preferences.show_command_numbers:
            row.scale_x = 0.11

            # İkinci sütun: Sıra numarası (index)
            row.label(text=f"{index+1}")

        if preferences.show_command_shortcodes:    
            row.scale_x = 0.25

            # Üçüncü sütun: Baş harfler (initials)
            initials = ''.join([word[0].upper() for word in item.name.split()])
            row.label(text=initials)

    def draw_filter(self, context, layout):
        # Nothing much to say here, it's usual UI code...
        #row = layout.row(align=True)

        row = layout.row(align=True)
        row.prop(self, "filter_name", text="",placeholder="Filter by Name, Number, or ShortCode",       )

    # Toggle butonu
        #subrow = row.row(align=True)
        row.prop(context.scene, "use_order_name", text="", icon='SORTALPHA', toggle=True)

    def filter_items(self, context, data, property):

        helper_funcs = bpy.types.UI_UL_list

        flt_flags = []
        flt_neworder = []

        filter_text = self.filter_name.lower()

        items = getattr(data, property)
        sorted_indices = sorted(range(len(items)), key=lambda i: items[i].name.lower())

        for index, item in enumerate(items):
            initials = ''.join([word[0].lower() for word in item.name.split()])
            if (filter_text in str(index + 1).lower() or
                filter_text in item.name.lower() or
                filter_text in initials):
                    flt_flags.append(self.bitflag_filter_item)
            else:
                flt_flags.append(0)

        if context.scene.use_order_name:
            flt_neworder = helper_funcs.sort_items_by_name(items)

        return flt_flags,flt_neworder

    def invoke(self, context, event):
        #print(event.type)
        return {'FINISHED'}


def get_comment_from_file(command_name):
    # __init__.py dosyasının bulunduğu dizini al
    current_dir = os.path.dirname(__file__)

    # commandbox dizini ve ilgili .py dosyasının tam yolunu oluştur
    target_file = os.path.join(current_dir, "commandbox", f"{command_name}.py")

    # Dosyanın mevcut olup olmadığını kontrol et
    if not os.path.isfile(target_file):
        return f"Error: '{command_name}.py' not found in 'Command Box' directory."

    try:
        # Dosyanın ilk iki satırını oku
        with open(target_file, 'r', encoding='utf-8') as file:
            lines = [line.strip() for line in file.readlines()[:2]]  # İlk iki satır

        # URL içermeyen yorum ve URL içeren yorumu ayıralım
        url_comment = None
        non_url_comment = None

        for line in lines:
            if line.startswith("#"):  # Yorum satırını kontrol et
                comment_text = line[1:].strip()  # # işaretinden sonra kalan metni al

                # Eğer yorum bir URL ise, url_comment'e at
                if comment_text.lower().startswith("http://") or comment_text.lower().startswith("https://"):
                    url_comment = comment_text
                else:
                    non_url_comment = comment_text

        # URL içermeyen yorum olsa da olmasa da ek mesajı ekle
        if url_comment:
            return f"{non_url_comment.rstrip('.')+'. ' if non_url_comment else ''}Use Button ❔ Video Help for: {command_name}"

        # Eğer yalnızca non-URL yorum varsa, onu döndür
        if non_url_comment:
            return f"{non_url_comment}"

        # URL içermeyen geçerli bir yorum bulunmazsa
        return f"non-URL or comment found in the first two lines for Command: {command_name}."

    except Exception as e:
        return f"Error reading file: {e}"

def update_active_item(self, context):
    global autorun
    if context.scene.active_item_index == context.scene.previous_item_index:
        
        if autorun:
            bpy.ops.commandbox.run_script()
        
        context.scene.previous_item_index = -1
    else:
        context.scene.previous_item_index = context.scene.active_item_index

        scene = context.scene
        items = scene.commandbox_collection

        if items:
            selected_item = items[scene.active_item_index].name
            comment_=get_comment_from_file(selected_item)
            #bpy.ops.wm.show_message(message=comment_)
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=comment_, duration=5)


            #bpy.ops.wm.show_message(message=selected_item)
    #return {'FINISHED', 'SKIP_SAVE'}


#-----------------------------------------


class COMMANDBOX_OT_OpenFolder(bpy.types.Operator):
    bl_idname = "commandbox.open_folder"
    bl_label = "Open Folder"
    bl_description = "Open the folder containing the selected Python script"

    def execute(self, context):
        
        import subprocess
        import platform

        preferences = context.preferences.addons[__package__].preferences
        scene = context.scene
        items = scene.commandbox_collection

        if items:
            selected_item = items[scene.active_item_index].name
            script_path = os.path.join(
                os.path.dirname(preferences.json_file_path),
                f"{selected_item}.py")
            folder_path = os.path.dirname(script_path)

            try:
                if platform.system() == "Windows":
                    os.startfile(folder_path)
                elif platform.system() == "Darwin":  # macOS
                    subprocess.run(["open", folder_path], check=True)
                else:  # Linux
                    subprocess.run(["xdg-open", folder_path], check=True)

                self.report({'INFO'}, f"Opened folder: {folder_path}")
            except Exception as e:
                self.report({'ERROR'}, f"Error opening folder: {e}")

        return {'FINISHED'}
#-----------------------------------------

class WM_OT_url_open_fables_alive(bpy.types.Operator):
    bl_idname = "commandbox.url_open_fables_alive"
    bl_label = "Open Fables Alive Inc Website"

    def execute(self, context):
        import webbrowser
        webbrowser.open("https://fablesalive.gumroad.com")
        return {'FINISHED'}

class COMMANDBOX_PT_Panel(bpy.types.Panel):
    bl_label = "Command Box LITE"
    bl_idname = "COMMANDBOX_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'
    #use_pin=True
    wwwfablesalive_icon = None

    global icons_collection
    
    def __init__(self):
        self.wwwfablesalive_icon = icons_collection.get("wwwfablesalive")

    def draw_header(self, context):
        layout = self.layout
        #layout.label(text="Başlık")
        layout.label(text="", icon_value=self.wwwfablesalive_icon.icon_id)
        layout.operator("commandbox.reload_items", text="",icon="FILE_REFRESH")
        

        #.prop(self, "filter_name", text="",placeholder="Filter by Name, Number, or ShortCode",       )
        #return super() draw_header(context)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        commandbox_collection_length = len(context.scene.commandbox_collection)
        self.bl_label = f"Command Box LITE (Σ:{commandbox_collection_length})"


        #row = layout.row()
        #row.label(text="As you Mouse Hover on This Command List. Press CTRL+F to Focus Filter", icon='INFO')

       # # Filtreleme satırını ekleyin
       # row = layout.row(align=True)
       # row.prop(scene, "filter_name", text="Filter")
       # row.prop(scene, "use_order_name", text="", icon='SORTALPHA', toggle=True)


        layout.template_list("COMMANDBOX_UL_Items",
                             "",
                             scene,
                             "commandbox_collection",
                             scene,
                             "active_item_index",
                             rows=15)#15 satır minimum

        #row = layout.row()
        #row.label(text=f"{len(scene.commandbox_collection)} Commands")

        #row = layout.row()
        #row.label(text="Double-click an item to run the script", icon='INFO')


        run_icon=icons_collection.get("run")

        wwwfablesalive_icon=icons_collection.get("wwwfablesalive")

        if run_icon:
            layout.operator("commandbox.run_script", text="",icon_value=run_icon.icon_id)


        layout.prop(scene, "new_item_name", text="",placeholder="New Command")

        # Grid düzeni
        grid = layout.grid_flow(row_major=False, columns=10, align=True,even_columns=True)


        #move_up_icon = icons_collection.get("move_up")
        grid.operator("commandbox.move_up", text="", icon='TRIA_UP')

        #move_down_icon = icons_collection.get("move_down")
        grid.operator("commandbox.move_down", text="", icon='TRIA_DOWN')



        #add_icon=icons_collection.get("add")
        grid.operator("commandbox.add_item", text="",icon="ADD")

        #remove_icon=icons_collection.get("remove")
        grid.operator("commandbox.delete_item", text="",icon="REMOVE")

        #save_icon=icons_collection.get("save")

        #if save_icon:
        grid.operator("commandbox.save_items", text="",icon="FILE_TICK")

        #py_icon=icons_collection.get("py")

        #if py_icon:
        grid.operator("commandbox.open_code", text="",icon="FILE_SCRIPT")


        #dir_icon=icons_collection.get("dir")

        #if dir_icon:
        grid.operator("commandbox.open_folder", text="",icon="FILE_FOLDER")


        #reload_icon=icons_collection.get("reload")

        #if(reload_icon):
        grid.operator("commandbox.reload_items", text="",icon="FILE_REFRESH")

        # Özel simge buton
        #yt_icon = icons_collection.get("yt")
        #if yt_icon:
        grid.operator("commandbox.open_youtube_link", text="", icon="QUESTION")
        #row.operator("commandbox.open_youtube_link",text="❓")

        grid.operator("commandbox.url_open_fables_alive",text="",icon_value=wwwfablesalive_icon.icon_id)

        # Eğer daha önce yüklenmemişse JSON'u yükle
        #if len(scene.commandbox_collection) == 0:
        #    bpy.app.timers.register(lambda: load_items_from_json(bpy.context),
        #                            first_interval=.1)


class COMMANDBOX_OT_RefreshItems(bpy.types.Operator):
    bl_idname = "commandbox.reload_items"
    bl_label = "Reload Command List"
    bl_description = "Reload the Command List from JSON"

    def execute(self, context):
        scene = context.scene
        scene.commandbox_collection.clear()
        load_items_from_json(context)
        self.report({'INFO'}, "Command list refreshed from JSON.")
        return {'FINISHED'}

class COMMANDBOX_OT_AddItem(bpy.types.Operator):
    bl_idname = "commandbox.add_item"
    bl_label = "Add Item"
    bl_description = "Add a new command to the list"

    def execute(self, context):
        scene = context.scene
        new_name = scene.new_item_name.strip()  # Boşlukları temizle

        if not new_name:  # Eğer isim boşsa işlemi durdur
            self.report({'WARNING'}, "Item name cannot be empty")
            return {'CANCELLED'}

        textinfo_="'Add Command' not Available in Commandbox Lite Edition"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        
        return {'FINISHED'}

class COMMANDBOX_OT_DeleteItem(bpy.types.Operator):
    bl_idname = "commandbox.delete_item"
    bl_label = "Delete Item"
    bl_description = "Delete the selected item"

    def execute(self, context):
        scene = context.scene
        items = scene.commandbox_collection

        textinfo_="'Delete Command' not Available in Commandbox Lite Edition"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}


class COMMANDBOX_OT_MoveUp(bpy.types.Operator):
    bl_idname = "commandbox.move_up"
    bl_label = "Move Item Up"
    bl_description = "Move the selected item up in the list"

    def execute(self, context):
        textinfo_="'Move Command Up' not Available in Commandbox Lite Edition"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}

class COMMANDBOX_OT_MoveDown(bpy.types.Operator):
    bl_idname = "commandbox.move_down"
    bl_label = "Move Item Down"
    bl_description = "Move the selected item down in the list"

    def execute(self, context):
        textinfo_="'Move Command Down' not Available in Commandbox Lite Edition"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}


class COMMANDBOX_OT_SaveItems(bpy.types.Operator):
    bl_idname = "commandbox.save_items"
    bl_label = "Save Command List to JSON"
    bl_description = "Press [Reload Command List, If [✅Sort Before Save] is Checked in Addon Preferences"

    def execute(self, context):
        textinfo_="'Save Commands' not Available in Commandbox Lite Edition"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}


class COMMANDBOX_OT_RunScript(bpy.types.Operator):
    bl_idname = "commandbox.run_script"
    bl_label = "Run Script"
    bl_description = "Run the selected script"
    bl_options = {'REGISTER', 'UNDO'}  # Operatörün global bağlamda çalışmasını sağlar.

    @classmethod
    def poll(cls, context):
        # Operatör her zaman kullanılabilir olsun
        return True

    def execute(self, context):
        if not hasattr(bpy.types.Scene,"runscriptcounter"):
            bpy.types.Scene.runscriptcounter=0
        
        bpy.types.Scene.runscriptcounter+=1

        print(f"commandbox.run_script begin****************************************{bpy.types.Scene.runscriptcounter}")
        preferences = context.preferences.addons[__package__].preferences
        scene = context.scene
        items = scene.commandbox_collection
        if items:
            selected_item = items[scene.active_item_index].name
            script_path = os.path.join(
                os.path.dirname(preferences.json_file_path),
                f"{selected_item}.py")

            try:
                #with open(script_path) as script_file:
                #exec(compile(script_file.read(), script_path, 'exec'))

                bpy.ops.script.python_file_run(filepath=script_path)

                #with open(script_path, "r") as script_file:
                #    script_content = script_file.read()F
                #    exec(script_content, {"__name__": "__main__"})
                #bpy.ops.ed.undo_push(message=f"Run Script")

                self.report({'INFO'}, f"Executed {script_path}.")
            except Exception as e:
                self.report({'ERROR'}, f"Error executing script: {e}")

        return {'FINISHED'}


class COMMANDBOX_OT_OpenCode(bpy.types.Operator):
    bl_idname = "commandbox.open_code"
    bl_label = "Open Code"
    bl_description = "Open the selected Python script in the default editor (VS Code)"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        scene = context.scene
        items = scene.commandbox_collection

        textinfo_="'Open Command Code' not Available in Commandbox Lite Edition"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}


def load_items_from_json(context):
    scene = context.scene
    scene.commandbox_collection.clear()
    preferences = context.preferences.addons[__package__].preferences
    file_path = preferences.json_file_path if preferences.json_file_path else get_default_json_path(
    )

    try:
        with open(file_path, 'r') as json_file:
            items = json.load(json_file)

        for item_data in items:
            item = scene.commandbox_collection.add()
            item.name = item_data.get("name", "")

        #print("load_items_from_json called")

    except FileNotFoundError:
        print(f"Error: JSON file not found at {file_path}.")
    except json.JSONDecodeError:
        print("Error: JSON file is not properly formatted.")
    except Exception as e:
        print(f"Error loading JSON: {e}")


def save_items_to_json(context):
    scene = context.scene
    preferences = context.preferences.addons[__package__].preferences
    file_path = preferences.json_file_path if preferences.json_file_path else get_default_json_path()

    items = [{"name": item.name} for item in scene.commandbox_collection]

    # Sort items alphabetically if the preference is enabled
    if preferences.sort_before_save:
        items.sort(key=lambda x: x["name"].lower())

    with open(file_path, 'w') as json_file:
        json.dump(items, json_file, indent=4)
    # scene = context.scene
    # preferences = context.preferences.addons[__package__].preferences
    # file_path = preferences.json_file_path if preferences.json_file_path else get_default_json_path(
    # )

    # items = []
    # for item in scene.commandbox_collection:
    #     items.append({"name": item.name})

    # with open(file_path, 'w') as json_file:
    #     json.dump(items, json_file, indent=4)


class CommandBoxPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__
    json_file_path: bpy.props.StringProperty(name="JSON File Path",default=get_default_json_path())
    #json_file_path: bpy.props.StringProperty(name="JSON File Path",pa)

    #def __init__(self):
    #        # default değeri burada atıyoruz, fonksiyon çağrısı olarak
    #        self.json_file_path = get_default_json_path()

    sort_before_save: bpy.props.BoolProperty(
            name="Sort Items Before Save",
            description="Sort items alphabetically before saving to JSON",
            default=True
        )

    show_command_icons: bpy.props.BoolProperty(
        name="Show Command Icons",
        description="Show or Not Command Icons",
        default=True
    )

    show_command_numbers: bpy.props.BoolProperty(
    name="Show Command Numbers",
    description="Show or Not Command Numbers",
    default=True
    )

    show_command_shortcodes: bpy.props.BoolProperty(
    name="Show Command Numbers",
    description="Show or Not Command ShortCodes",
    default=True
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Python Commands will be in json path", icon='INFO')
        layout.prop(self, "json_file_path", text="JSON File Path")
        layout.prop(self, "sort_before_save", text="Sort Items Before Save")
        layout.prop(self, "show_command_icons", text="Show Command Icons")
        layout.prop(self, "show_command_numbers", text="Show Command Numbers")
        layout.prop(self, "show_command_shortcodes", text="Show Command ShortCodes")

def load_items_from_json_with_timer():
    print('load_items_from_json_with_timer executed')

    load_items_from_json(bpy.context)

    #UI refresh
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            area.tag_redraw()
    return None  # Timer'ın bir kez çalışması için None döner

@persistent
def on_scene_load(dummy):
    bpy.app.timers.register(load_items_from_json_with_timer, first_interval=1.0)

def register():
    register_icons()

    bpy.app.handlers.load_post.append(on_scene_load)

    #_modal_draw_operator.register()
    bpy.utils.register_class(_modal_draw_operator.ModalDrawOperator)
    bpy.utils.register_class(_toggle_n_panel.VIEW3D_OT_toggle_n_panel_and_set_tab)

    bpy.utils.register_class(COMMANDBOX_OT_OpenYouTubeLink)
    bpy.utils.register_class(COMMANDBOX_OT_FloatingPanel)
    bpy.utils.register_class(COMMANDBOX_OT_ExecuteItem)
    #bpy.utils.register_class(COMMANDBOX_OT_ClosePanel)

    bpy.utils.register_class(CommandBoxItem)

    bpy.utils.register_class(COMMANDBOX_OT_ToggleSortOrder)
    bpy.utils.register_class(COMMANDBOX_UL_Items)

    bpy.utils.register_class(COMMANDBOX_OT_OpenFolder)
    bpy.utils.register_class(COMMANDBOX_PT_Panel)

    bpy.utils.register_class(COMMANDBOX_OT_MoveUp)
    bpy.utils.register_class(COMMANDBOX_OT_MoveDown)

    bpy.utils.register_class(COMMANDBOX_OT_AddItem)
    bpy.utils.register_class(COMMANDBOX_OT_DeleteItem)
    bpy.utils.register_class(COMMANDBOX_OT_SaveItems)
    bpy.utils.register_class(COMMANDBOX_OT_RunScript)
    bpy.utils.register_class(COMMANDBOX_OT_OpenCode)

    bpy.utils.register_class(WM_OT_url_open_fables_alive)

    bpy.utils.register_class(CommandBoxPreferences)

    bpy.utils.register_class(COMMANDBOX_OT_RefreshItems)
    bpy.utils.register_class(ShowMessageOperator)

    bpy.types.Scene.commandbox_collection = bpy.props.CollectionProperty(
        type=CommandBoxItem)

    bpy.types.Scene.active_item_index = bpy.props.IntProperty(
        name=f"⭐ Double Click To Run Command \n\n⭐ Hover Mouse on This List, Press CTRL+F to Filter\n\n⭐ Select Command, Press ❓ To Watch Video Tutorial\n\n⭐ Alt+X : popup filter commandbox in viewport.\n\n⭐ Ctrl+Alt+X : open this panel\n\n", default=0, update=update_active_item,options={'HIDDEN', 'SKIP_SAVE'})

    # name: bpy.props.StringProperty(name="Item Name", options={'HIDDEN', 'SKIP_SAVE'})
    bpy.types.Scene.previous_item_index = bpy.props.IntProperty(default=-1,options={'HIDDEN', 'SKIP_SAVE'})

    bpy.types.Scene.new_item_name = bpy.props.StringProperty(
        name="New Command Name", default="")

    register_keymap()
    bpy.app.timers.register(load_items_from_json_with_timer, first_interval=0.1)

    bpy.utils.register_class(COMMANDBOX_OT_SearchOperator)

    #run_autorun_scripts()
    bpy.app.timers.register(run_autorun_scripts, first_interval=0.5)

def unregister():
    try:
        unregister_keymap()
        #_modal_draw_operator.unregister()
        bpy.utils.unregister_class(_modal_draw_operator.ModalDrawOperator)
        bpy.utils.unregister_class(_toggle_n_panel.VIEW3D_OT_toggle_n_panel_and_set_tab)

        bpy.app.handlers.load_post.remove(on_scene_load)

        bpy.utils.unregister_class(COMMANDBOX_OT_SearchOperator)

        bpy.utils.unregister_class(ShowMessageOperator)
        bpy.utils.unregister_class(COMMANDBOX_OT_OpenYouTubeLink)
        bpy.utils.unregister_class(COMMANDBOX_OT_FloatingPanel)
        bpy.utils.unregister_class(COMMANDBOX_OT_ExecuteItem)
        #bpy.utils.unregister_class(COMMANDBOX_OT_ClosePanel)

        bpy.utils.unregister_class(CommandBoxItem)
        del bpy.types.Scene.commandbox_collection

        bpy.utils.unregister_class(COMMANDBOX_OT_ToggleSortOrder)
        bpy.utils.unregister_class(COMMANDBOX_UL_Items)

        bpy.utils.unregister_class(COMMANDBOX_OT_OpenFolder)
        bpy.utils.unregister_class(COMMANDBOX_PT_Panel)

        bpy.utils.unregister_class(COMMANDBOX_OT_MoveUp)
        bpy.utils.unregister_class(COMMANDBOX_OT_MoveDown)

        bpy.utils.unregister_class(COMMANDBOX_OT_AddItem)
        bpy.utils.unregister_class(COMMANDBOX_OT_DeleteItem)
        bpy.utils.unregister_class(COMMANDBOX_OT_SaveItems)
        bpy.utils.unregister_class(COMMANDBOX_OT_RunScript)
        bpy.utils.unregister_class(COMMANDBOX_OT_OpenCode)

        bpy.utils.unregister_class(WM_OT_url_open_fables_alive)

        bpy.utils.unregister_class(CommandBoxPreferences)

        bpy.utils.unregister_class(COMMANDBOX_OT_RefreshItems)

        del bpy.types.Scene.active_item_index
        del bpy.types.Scene.new_item_name
        del bpy.types.Scene.previous_item_index

        unregister_icons()

    except Exception as e:
        print(f"unregister exception: {e}. end of exception msg.")


def register_icons():
    global icons_collection
    icons_collection = bpy.utils.previews.new()

    # Simge yolu (__init__.py ile aynı dizindeki "icons" klasörü)
    script_directory = os.path.dirname(__file__)

    #youtube_path = os.path.join(script_directory, "icons", "yt.svg")
    run_path = os.path.join(script_directory, "icons", "run.svg")
    wwwfablesalive_path = os.path.join(script_directory, "icons", "logo.png")
    #py_path = os.path.join(script_directory, "icons", "py.svg")
    #dir_path= os.path.join(script_directory,"icons","dir.svg")
    #save_path= os.path.join(script_directory,"icons","save.svg")

    #add_path= os.path.join(script_directory,"icons","add.svg")
    #remove_path= os.path.join(script_directory,"icons","remove.svg")
    #reload_path= os.path.join(script_directory,"icons","reload.svg")
    # Simgeyi yükle
    #icons_collection.load("yt", youtube_path, 'IMAGE')
    icons_collection.load("run", run_path, 'IMAGE')
    icons_collection.load("wwwfablesalive", wwwfablesalive_path, 'IMAGE')
    #icons_collection.load("py", py_path, 'IMAGE')
    #icons_collection.load("dir",dir_path,'IMAGE')
    #icons_collection.load("save",save_path,'IMAGE')

    #icons_collection.load("add",add_path,'IMAGE')
    #icons_collection.load("remove",remove_path,'IMAGE')
    #icons_collection.load("reload",reload_path,'IMAGE')


    #move_up_path = os.path.join(script_directory, "icons", "move_up.svg")
    #move_down_path = os.path.join(script_directory, "icons", "move_down.svg")

    #icons_collection.load("move_up", move_up_path, 'IMAGE')
    #icons_collection.load("move_down", move_down_path, 'IMAGE')


def unregister_icons():
    global icons_collection
    bpy.utils.previews.remove(icons_collection)


if __name__ == "__main__":
    unregister()
    register()
