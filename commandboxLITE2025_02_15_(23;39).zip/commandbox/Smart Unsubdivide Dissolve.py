#removes unneccessary vertices in a smart way.
import bpy
import bmesh
import math

def limited_dissolve_until_change(obj):
    # Seçili objeyi kontrol et
    if obj.type != 'MESH':
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="The selected object is not a mesh!", duration=5)
        return

    # Başlangıç değerleri
    max_angle = 1.0
    original_vertex_count = len(obj.data.vertices)
    original_edge_count=len(obj.data.edges)

    print(f"original_vertex_count: {original_vertex_count}")

    # Maksimum iterasyon sayısı (Blender'ın çökmesini önlemek için)
    max_iterations = 2000
    iteration = 0

    # Vertex sayısı değişene kadar döngü
    while iteration < max_iterations:
        # Limitli çözme işlemi uygula
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        
        # Mevcut mesh üzerinde çalışmak
        obj = bpy.context.object
        bm = bmesh.from_edit_mesh(obj.data)

        # Tüm vertexleri seçmek
        for v in bm.verts:
            v.select = True

        bmesh.update_edit_mesh(obj.data)

        # Limited dissolve uygula
        bpy.ops.mesh.dissolve_limited(angle_limit=math.radians(max_angle),use_dissolve_boundaries=True,delimit={"NORMAL"})
        
        bpy.ops.object.mode_set(mode='OBJECT')

        # Yeni vertex sayısını kontrol et
        new_vertex_count = len(obj.data.vertices)
        new_edge_count=len(obj.data.edges)

        # Vertex sayısı değiştiyse raporla ve döngüden çık
        if (new_vertex_count != original_vertex_count)or((new_edge_count != original_edge_count)):

            comment_=f"Max Angle: {max_angle:.3f} ▐ Optimized Vertex : {new_vertex_count}/{original_vertex_count} ▐ Optimized Edge : {new_vertex_count}/{original_edge_count}"

            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=comment_, duration=5)
            #bpy.ops.wm.show_message(message=comment_)
            
            break

        # Max Angle değerini arttır (daha küçük bir adım)
        max_angle += .1#math.radians(1)  # Daha hassas artış

        iteration += 1  # İterasyon sayısını artır

    else:
        comment_="The number of vertices did not change, operation terminated. Maximum number of iterations reached."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=comment_, duration=5)

# Aktif objeyi al ve fonksiyonu çağır
active_object = bpy.context.active_object
limited_dissolve_until_change(active_object)
