#https://www.youtube.com/watch?v=6jyftYMc_20
import bpy

bpy.ops.mesh.bridge_edge_loops(merge_factor=0.5,use_merge=True)
