#Add Default UV Map if None
import bpy

for obj in bpy.context.selected_objects:
    if obj.type == 'MESH':
        if not obj.data.uv_layers:
            obj.data.uv_layers.new(name="UVMap")
            bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Default UV map assigned to {obj.name}.", duration=5)
        else:
            bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"{obj.name} already has a UV map.", duration=5)
