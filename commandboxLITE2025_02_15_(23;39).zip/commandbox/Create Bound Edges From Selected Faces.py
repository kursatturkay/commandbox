# https://www.youtube.com/watch?v=43vwGM8grPg
#Must be in Edit|Face Mode. Select Face(s). Apply Command. It creates a new object from the edge loop surrounding the selected faces.

#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

if not bpy.context.tool_settings.mesh_select_mode[2]:
    textinfo_="Warning: This operation only works in Face Select mode. Please switch to Face Select mode."
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
else:
 # Get the list of objects in the scene before separation
    objects_before = set(obj.name for obj in bpy.context.scene.objects if obj.type == 'MESH')
    
    # Perform the operations
    bpy.ops.mesh.region_to_loop()
    bpy.ops.mesh.duplicate()
    bpy.ops.mesh.separate(type='SELECTED')
    
    # Switch to Object Mode to manage the new objects
    bpy.ops.object.mode_set(mode='OBJECT')
    
    # Get the list of objects in the scene after separation
    objects_after = set(obj.name for obj in bpy.context.scene.objects if obj.type == 'MESH')
    
    # Identify the new objects created by the separation
    new_objects = objects_after - objects_before

    if new_objects:
        # Deselect all objects
        bpy.ops.object.select_all(action='DESELECT')
        
        # Select the newly created objects
        for obj_name in new_objects:
            obj = bpy.data.objects[obj_name]
            obj.select_set(True)
        
        # Optionally, set one of the new objects as the active object
        bpy.context.view_layer.objects.active = bpy.data.objects[list(new_objects)[0]]
        
        print(f"Selected new objects: {', '.join(new_objects)}")
    else:
        print("No new objects were created.")