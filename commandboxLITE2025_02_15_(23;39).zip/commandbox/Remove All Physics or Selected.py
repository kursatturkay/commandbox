# https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Removes all Rigid Body, Soft Body, Cloth, Fluid, Dynamic Paint, Smoke / Fire, Collision, Particle Systems, Force Fields
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 

import bpy

def remove_all_physics(obj):
    # Rigid Body (Katı Cisim)
    if obj.rigid_body:
        bpy.context.view_layer.objects.active = obj
        bpy.ops.rigidbody.object_remove()  # Rigid body'yi kaldırır
    
    # Soft Body
    if obj.soft_body:
        obj.soft_body = None
    
    # Cloth
    if "Cloth" in obj.modifiers:
        obj.modifiers.remove(obj.modifiers["Cloth"])
    
    # Fluid
    if "Fluid" in obj.modifiers:
        obj.modifiers.remove(obj.modifiers["Fluid"])
    
    # Dynamic Paint
    if "Dynamic Paint" in obj.modifiers:
        obj.modifiers.remove(obj.modifiers["Dynamic Paint"])
    
    # Smoke / Fire
    if "Smoke" in obj.modifiers:
        obj.modifiers.remove(obj.modifiers["Smoke"])
    
    # Collision
    if "Collision" in obj.modifiers:
        obj.modifiers.remove(obj.modifiers["Collision"])
    
    # Particle Systems
    if obj.particle_systems:
        while obj.particle_systems:
            obj.particle_systems.remove(obj.particle_systems[0])

    # Force Fields
    if obj.field:
        obj.field.type = 'NONE'

    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"The physics features of {obj.name} have been cleared.", duration=5)

def clear_physics():
    selected_objects = bpy.context.selected_objects

    # Eğer seçili obje yoksa sahnedeki tüm objeleri al
    if not selected_objects:
        objects = bpy.context.scene.objects
    else:
        objects = selected_objects
    
    for obj in objects:
        if obj.type in {'MESH', 'CURVE', 'SURFACE', 'FONT'}:  # Fizik eklenebilen tipler
            remove_all_physics(obj)

clear_physics()
