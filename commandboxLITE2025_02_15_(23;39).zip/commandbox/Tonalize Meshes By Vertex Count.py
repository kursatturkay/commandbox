#
#Select Meshes To Tonalize. Colorizes gradually from green to red Meshes depending on Vertex Count. So You can visually detect unoptimized objects.
import bpy

for obj in bpy.context.selected_objects:
    if obj.type != 'MESH':
        obj.select_set(False)
        
selected_objects = bpy.context.selected_objects
if not selected_objects:
    selected_objects = [obj for obj in bpy.context.scene.objects if obj.type == 'MESH']
    for obj in selected_objects:
        obj.color = (1.0, 1.0, 1.0, 1.0)  
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No objects were selected. All mesh objects have been reset to white.", duration=5)
else:
    
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            space = area.spaces.active
            if hasattr(space.shading, "type") and space.shading.type != 'SOLID':
                space.shading.type = 'SOLID'
            if hasattr(space.shading, "light") and space.shading.light != 'STUDIO':
                space.shading.light = 'STUDIO'

            space.shading.color_type = 'OBJECT'


    
    objects_by_vertex_count = sorted(selected_objects, key=lambda obj: len(obj.data.vertices))
    total_objects = len(objects_by_vertex_count)

    if total_objects > 1:
        for index, obj in enumerate(objects_by_vertex_count):
            
            normalized = index / (total_objects - 1)

            if normalized < 0.5:
                
                green_intensity = 1.0
                red_intensity = normalized * 2  
            else:
                
                green_intensity = 1.0 - (normalized - 0.5) * 2  
                red_intensity = 1.0

            
            color = (red_intensity, green_intensity, 0.0, 1.0)  
            obj.color = color
            obj.show_wire = False
            obj.show_all_edges = False
            obj.show_in_front = False
    elif total_objects == 1:
        
        objects_by_vertex_count[0].color = (1.0, 1.0, 1.0, 1.0)
