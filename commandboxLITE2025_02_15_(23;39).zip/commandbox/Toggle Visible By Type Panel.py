# https://www.youtube.com/watch?v=I6NLiXsX1jY 
# Toggles visibility panel (toggles hide_set,hide_render,visible_camera,visible_shadow by object type) 
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class OBJECT_PT_ToggleVisiblePanel(bpy.types.Panel):
    """Panel for toggling visibility of objects by type"""
    bl_label = "Toggle Visibility by Object Type"
    bl_idname = "OBJECT_PT_ToggleVisiblePanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Command Box"

    def draw(self, context):
        layout = self.layout
        #layout.label(text="Toggle Visibility by Object Type:")

        object_types = get_unique_object_types()
        for obj_type in object_types:
            property_name = f"toggle_visible_{obj_type.lower()}"
            layout.prop(context.scene, property_name, text=obj_type)

        #layout.operator("object.toggle_visible_by_type", text="Apply All")
        layout.operator("object.update_scene_properties", text="Update List")

class OBJECT_OT_UpdateSceneProperties(bpy.types.Operator):
    """Update scene properties for toggling visibility"""
    bl_idname = "object.update_scene_properties"
    bl_label = "Update Scene Properties"
    bl_options = {'REGISTER'}

    def execute(self, context):
        update_scene_properties()
        self.report({'INFO'}, "Scene properties updated.")
        return {'FINISHED'}

class OBJECT_OT_ToggleVisibleByType(bpy.types.Operator):
    """Toggle visibility for objects by type"""
    bl_idname = "object.toggle_visible_by_type"
    bl_label = "Toggle Visible by Type"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for obj in context.view_layer.objects:
            obj_type = obj.type.lower()
            toggle_property = f"toggle_visible_{obj_type}"
            if hasattr(context.scene, toggle_property):
                toggle_value = getattr(context.scene, toggle_property)
                
                obj.hide_viewport = not toggle_value
                obj.hide_set(not toggle_value)
                obj.hide_render = (not toggle_value)
                
                obj.visible_camera = (toggle_value)
                obj.visible_shadow = (toggle_value)

        return {'FINISHED'}


def get_unique_object_types():
    """Retrieve a list of unique object types in the current scene"""
    return list(set(obj.type for obj in bpy.data.objects))

def printset(self,context):
    bpy.ops.object.toggle_visible_by_type()

def update_scene_properties():
    """Update scene properties for toggling visibility"""
    object_types = get_unique_object_types()
    for obj_type in object_types:
        property_name = f"toggle_visible_{obj_type.lower()}"
        if not hasattr(bpy.types.Scene, property_name):
            setattr(bpy.types.Scene, property_name, bpy.props.BoolProperty(
                name=f"Toggle {obj_type}",
                description=f"Toggle visibility for {obj_type} objects",
                default=True,
                update=printset,
            ))


def register():
    bpy.utils.register_class(OBJECT_PT_ToggleVisiblePanel)
    bpy.utils.register_class(OBJECT_OT_ToggleVisibleByType)
    bpy.utils.register_class(OBJECT_OT_UpdateSceneProperties)
    

    update_scene_properties()


def unregister():
    bpy.utils.unregister_class(OBJECT_PT_ToggleVisiblePanel)
    bpy.utils.unregister_class(OBJECT_OT_ToggleVisibleByType)
    bpy.utils.unregister_class(OBJECT_OT_UpdateSceneProperties)
    object_types = get_unique_object_types()
    for obj_type in object_types:
        property_name = f"toggle_visible_{obj_type.lower()}"
        if hasattr(bpy.types.Scene, property_name):
            delattr(bpy.types.Scene, property_name)

# İlk çalıştırma (register yapılacak)
# if __name__ == "__main__":
#     register()

def toggle():
    
    if hasattr(bpy.types, "OBJECT_PT_ToggleVisiblePanel"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='Toggle Visibility by Object Type Panel Unregistered from Under CommandBox Panel.', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented  
        bpy.utils.unregister_class(bpy.types.OBJECT_PT_ToggleVisiblePanel)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='Toggle Visibility by Object Type Panel Registered Under CommandBox Panel.', duration=5)
        register()

if __name__ == "__main__":
    toggle()
