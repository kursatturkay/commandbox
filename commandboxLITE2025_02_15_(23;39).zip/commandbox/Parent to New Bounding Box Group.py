#https://www.youtube.com/watch?v=BI9dSxE9czg
#Parents Selected Meshes to a New Wire Mesh
import bpy
import bmesh
from mathutils import Vector
import random

selected_objects = bpy.context.selected_objects

if not selected_objects:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Select More Than One Mesh To Parent Into New BoundingBox", duration=5)
else:

    min_coords = [float('inf')] * 3
    max_coords = [-float('inf')] * 3

    for obj in selected_objects:

        obj_matrix = obj.matrix_world
        for vertex in obj.bound_box:
            global_vertex = obj_matrix @ Vector(vertex)
            for i in range(3):
                min_coords[i] = min(min_coords[i], global_vertex[i])
                max_coords[i] = max(max_coords[i], global_vertex[i])

    mesh = bpy.data.meshes.new("BoundingBoxMesh")
    bounding_box_obj = bpy.data.objects.new("BoundingBox", mesh)
    bpy.context.collection.objects.link(bounding_box_obj)

    bbox_corners = [
        (min_coords[0], min_coords[1], min_coords[2]),
        (min_coords[0], min_coords[1], max_coords[2]),
        (min_coords[0], max_coords[1], min_coords[2]),
        (min_coords[0], max_coords[1], max_coords[2]),
        (max_coords[0], min_coords[1], min_coords[2]),
        (max_coords[0], min_coords[1], max_coords[2]),
        (max_coords[0], max_coords[1], min_coords[2]),
        (max_coords[0], max_coords[1], max_coords[2]),
    ]

    bm = bmesh.new()
    verts = [bm.verts.new(corner) for corner in bbox_corners]
    bm.verts.ensure_lookup_table()

    edges = [
        (0, 1),
        (1, 3),
        (3, 2),
        (2, 0),
        (4, 5),
        (5, 7),
        (7, 6),
        (6, 4),
        (0, 4),
        (1, 5),
        (2, 6),
        (3, 7),
    ]

    for edge in edges:
        bm.edges.new([verts[edge[0]], verts[edge[1]]])

    bm.to_mesh(mesh)
    bm.free()

    for obj_to_parent in selected_objects:
        obj_to_parent.parent = bounding_box_obj

    bpy.context.view_layer.objects.active = bounding_box_obj
    bounding_box_obj.select_set(True)
    bpy.ops.object.mode_set(mode='OBJECT')

    bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')

    #curve rengi görünsün diye kullanılır. ama bu mesh : ) o yüzden kapattım
    #bpy.ops.object.modifier_add(type='EDGE_SPLIT')

    #random_color = (random.random(), random.random(), random.random(), 1)

    rainbow_colors = [
    (1, 0, 0, 1),  # Kırmızı
    (1, 0.5, 0, 1),  # Turuncu
    (1, 1, 0, 1),  # Sarı
    (0, 1, 0, 1),  # Yeşil
    (0, 0, 1, 1),  # Mavi
    (0.29, 0, 0.51, 1),  # İndigo
    (0.56, 0, 1, 1)  # Mor
    ]

    if not hasattr(bpy.types.Scene, "pnbb_color_index"):
        bpy.types.Scene.pnbb_color_index = 0

    pnbb_color_index = bpy.types.Scene.pnbb_color_index

    random_color = rainbow_colors[pnbb_color_index]

    bpy.types.Scene.pnbb_color_index = (pnbb_color_index + 1) % len(rainbow_colors)

    random_color = rainbow_colors[pnbb_color_index]

    bpy.context.scene["pnbb_color_index"] = (pnbb_color_index + 1) % len(rainbow_colors)

    bounding_box_obj.color = random_color
    bounding_box_obj.show_wire = True
    bounding_box_obj.display.show_shadows = False

for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        space = area.spaces.active

        # Viewport Shading tipini 'SOLID' olarak ayarla
        if space.shading.type != 'SOLID':
            space.shading.type = 'SOLID'

        # Shading ışık tipini 'STUDIO' olarak ayarla
        space.shading.light = 'STUDIO'

        if space.shading.wireframe_color_type != 'OBJECT':
            space.shading.wireframe_color_type = 'OBJECT'
