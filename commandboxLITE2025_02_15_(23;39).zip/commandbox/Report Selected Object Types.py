#Report Selected Object Types
import bpy

selected_objects = bpy.context.selected_objects

if selected_objects:
    object_types = {obj.type for obj in selected_objects}
    bpy.context.workspace.status_text_set(f"Selected object types: {', '.join(object_types)}")
else:
    bpy.context.workspace.status_text_set("No objects selected.")
