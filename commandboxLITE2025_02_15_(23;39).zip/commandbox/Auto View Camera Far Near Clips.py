#https://www.youtube.com/watch?v=GQtJJ8kKAGg
#Adjusts the 3D Viewport's clipping planes in Blender based on the nearest and farthest visible objects within the camera's view direction.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import mathutils

def adjust_view_clipping():
    # Sahnedeki tüm objeleri al
    objects = bpy.context.scene.objects

    # Tüm 3D Viewport alanlarını bul
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':  # Eğer alan 3D Viewport ise
            space = area.spaces.active
            region_3d = space.region_3d

            # Görünümün pozisyonu ve yönü
            view_position = region_3d.view_matrix.inverted().translation
            view_direction = region_3d.view_rotation @ mathutils.Vector((0.0, 0.0, -1.0))

            # En yakın ve en uzak mesafeleri başlat
            min_distance = float('inf')
            max_distance = -float('inf')

            # Tüm objeleri kontrol et
            for obj in objects:
                if obj.type == 'MESH' and obj.visible_get():  # Sadece görünür mesh objeler
                    # Objeye olan mesafe
                    obj_location = obj.location
                    distance = (view_position - obj_location).length
                    print(f"distance: {distance}")

                    # View yönünde mi?
                    direction_to_obj = (obj_location - view_position).normalized()
                    dot_product = view_direction.dot(direction_to_obj)

                    if dot_product > 0:  # Yalnızca görüş alanındaki objeleri hesaba kat
                        min_distance = min(min_distance, distance)
                        max_distance = max(max_distance, distance)

            # Clip Start ve Clip End değerlerini ayarla
            if min_distance < float('inf'):  # Eğer bir obje bulunduysa
                space.clip_start = distance*0.01
            if max_distance > -float('inf'):
                space.clip_end = distance*10  # Min 100

            textinfo_=f"Updated View: Clip Start = {space.clip_start}, Clip End = {space.clip_end}"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
# Fonksiyonu çalıştır
adjust_view_clipping()
