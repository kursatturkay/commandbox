#  add a youtube url link to first line for Select Meshes Without Faces
import bpy

# Aktif objeyi kontrol et
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':
        # Objede yüzey olup olmadığını kontrol et
        if len(obj.data.polygons) == 0:
            obj.select_set(True)  # Yüzey olmayan objeyi seç
        else:
            obj.select_set(False)  # Yüzey olan objeyi seç
