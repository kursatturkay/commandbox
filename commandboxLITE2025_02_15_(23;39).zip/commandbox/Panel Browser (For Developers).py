# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Panel Browser.
import bpy

# UIList sınıfı
class PANEL_UL_CustomList(bpy.types.UIList):
    # Filtreleme metodunu özelleştir
    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flt_flags = []
        filter_name = self.filter_name.lower()

        for item in items:
            if filter_name in item.class_name.lower() or filter_name in item.label.lower():
                flt_flags.append(self.bitflag_filter_item)
            else:
                flt_flags.append(0)

        return flt_flags, []

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        self.use_filter_show = True
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            row.label(text=item.class_name, icon='FILE')
            row.label(text=item.label)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text=item.label)

# Panelde gösterilecek öğeler için CollectionProperty
class PanelItem(bpy.types.PropertyGroup):
    class_name: bpy.props.StringProperty()  # Panel sınıf adı
    label: bpy.props.StringProperty()       # Panel başlığı

# Operatör: Listeyi güncelle
class PANEL_OT_UpdateList(bpy.types.Operator):
    bl_idname = "panel.update_list"
    bl_label = "Update List"

    def execute(self, context):
        panel_data = context.scene.panel_data

        # Listeyi temizle
        panel_data.panel_items.clear()

        # Panelleri bul ve listeye ekle
        for cls_name in dir(bpy.types):
            cls = getattr(bpy.types, cls_name)
            if isinstance(cls, type) and issubclass(cls, bpy.types.Panel):
                if hasattr(cls, "bl_label"):
                    item = panel_data.panel_items.add()
                    item.class_name = cls_name
                    item.label = cls.bl_label

        return {'FINISHED'}

# Operator for toggling panel visibility
class SCENE_OT_toggle_panel_browser(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_panel_browser"
    bl_label = "Toggle Panel Browser"

    def execute(self, context):
        context.scene.show_panel_browser = not context.scene.show_panel_browser

        if(context.scene.show_panel_browser):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
# Ana Panel
class PANEL_PT_PanelBrowserPanel(bpy.types.Panel):
    bl_label = "Panel Browser"
    bl_idname = "PANEL_PT_PanelBrowserPanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_panel_browser

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_panel_browser", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        panel_data = context.scene.panel_data

        # Listeyi güncelleyen buton
        layout.operator("panel.update_list", text="Refresh List")

        # UIList
        layout.template_list(
            "PANEL_UL_CustomList",  # Liste sınıfı
            "",                     # Liste ID
            panel_data,             # Veri bloğu
            "panel_items",          # Liste verisi
            panel_data,             # Aktif veri bloğu
            "active_index",         # Aktif öğe
        )

# Veri Bloğu
class PanelData(bpy.types.PropertyGroup):
    panel_items: bpy.props.CollectionProperty(type=PanelItem)
    active_index: bpy.props.IntProperty()

# Kayıt ve Kaldırma
classes = [
    PANEL_UL_CustomList,
    SCENE_OT_toggle_panel_browser,
    PanelItem,
    PANEL_OT_UpdateList,
    PANEL_PT_PanelBrowserPanel,
    PanelData,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.panel_data = bpy.props.PointerProperty(type=PanelData)

    bpy.types.Scene.show_panel_browser = bpy.props.BoolProperty(
    default=False)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.panel_data
    del bpy.types.Scene.show_panel_browser

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_panel_browser()

# def toggle():
    
#     if hasattr(bpy.types, "PANEL_PT_PanelBrowserPanel"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
#         #unregister() throws mRNA error ? couldnt resolve so commented  
#         bpy.utils.unregister_class(bpy.types.PANEL_PT_PanelBrowserPanel)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
#         register()

# # İlk çalıştırma (register yapılacak)
# if __name__ == "__main__":
#     toggle()
