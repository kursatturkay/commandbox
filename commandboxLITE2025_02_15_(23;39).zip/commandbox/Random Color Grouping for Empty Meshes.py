#  add a youtube url link to first line for Random Color Grouping for Empty Meshes
import bpy
import random

# Rastgele bir renk oluşturma fonksiyonu
def generate_random_color():
    return (random.random(), random.random(), random.random(), 1)  # RGBA formatında rastgele renk

# Yüzeysiz Meshleri seç ve renklerini ayarla
def select_and_color_empty_meshes():
    # Vertex sayısına göre renk gruplarını tutacak bir sözlük
    vertex_groups = {}

    # Tüm objeleri kontrol et
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH':
            # Objede yüzey olup olmadığını kontrol et
            if len(obj.data.polygons) == 0:
                obj.select_set(True)  # Yüzey olmayan objeyi seç
                num_vertices = len(obj.data.vertices)
                
                # Aynı vertex sayısına sahip objeler için aynı renk
                if num_vertices not in vertex_groups:
                    vertex_groups[num_vertices] = generate_random_color()
                
                # Objeye renk uygula
                obj.color = vertex_groups[num_vertices]
            else:
                obj.select_set(False)  # Yüzey olan objeyi seçme

# Fonksiyonu çalıştır
select_and_color_empty_meshes()
