# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Objects Names Visibility.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

def toggle_or_reset_name_visibility():
    selected_objects = bpy.context.selected_objects  
    
    if not selected_objects:  
        all_hidden = all(not obj.show_name for obj in bpy.context.scene.objects)  
        
        for obj in bpy.context.scene.objects:
            obj.show_name = all_hidden  
    else:  
        for obj in selected_objects:
            obj.show_name = not obj.show_name  



toggle_or_reset_name_visibility()
