#  https://www.youtube.com/watch?v=61dng-tY0rI

#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh

# Seçili objeleri al
selected_objects = bpy.context.selected_objects

# Seçili her objeyi kontrol et
for obj in selected_objects:
    if obj.type == 'MESH':
        # Obje edit modda değilse edit moda geç
        if bpy.context.mode != 'EDIT_MESH':
            bpy.context.view_layer.objects.active = obj  # Aktif objeyi ayarla
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action="SELECT")

        # BMesh verilerini yükle
        bm = bmesh.from_edit_mesh(obj.data)

        # Sadece seçili yüzeyleri sil
        faces_to_delete = [face for face in bm.faces if face.select]
        bmesh.ops.delete(bm, geom=faces_to_delete, context='FACES_ONLY')

        # Mesh verilerini güncelle
        bmesh.update_edit_mesh(obj.data)
else:
    textinfo_="No Mesh Selected. Select One Or Multiple Meshes"
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
