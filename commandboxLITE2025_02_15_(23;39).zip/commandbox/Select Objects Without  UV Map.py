#Isolate Objects Without  UV Map
import bpy

# Tüm objeleri seçimi kaldır
bpy.ops.object.select_all(action='DESELECT')

# Sahnedeki tüm mesh objelerini döngüye al
for obj in bpy.data.objects:
    if obj.type == 'MESH':
        # Objeyi aktif yap
        bpy.context.view_layer.objects.active = obj
        # Objeyi seç
        obj.select_set(True)
        
        # UV layer'ı kontrol et
        if not obj.data.uv_layers:
            # UV yoksa seçili tut
            obj.select_set(True)
        else:
            # UV varsa seçimden çıkar
            obj.select_set(False)
