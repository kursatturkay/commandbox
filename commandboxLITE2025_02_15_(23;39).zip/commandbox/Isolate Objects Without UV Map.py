#Select Objects Without  UV Map
import bpy

bpy.ops.object.select_all(action='DESELECT')

for obj in bpy.data.objects:
    if obj.type == 'MESH':
        if not obj.data.uv_layers:
            obj.hide_set(False)
        else:
            obj.hide_set(True)

bpy.ops.object.select_by_type(type='MESH')
