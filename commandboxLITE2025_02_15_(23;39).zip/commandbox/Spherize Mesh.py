#https://www.youtube.com/watch?v=H2cAPNsjJAM
#Spherize Selected Method 2.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
import math
from mathutils import Vector
from bpy.props import FloatProperty

class SpherizeMeshOperator(bpy.types.Operator):
    bl_idname = "mesh.spherize_mesh"
    bl_label = "Spherize Mesh"
    bl_options = {'REGISTER', 'UNDO'}  # Tool paneli için gerekli
    
    factor: FloatProperty(
        name="Factor",
        description="Spherize factor",
        default=0.0,
        min=-2.0,
        max=2.0,
    )

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(obj.data)
        selected_edges = [e for e in bm.edges if e.select]
        if not selected_edges:
            return {'CANCELLED'}

        verts = []
        for edge in selected_edges:
            for vert in edge.verts:
                if vert not in verts:
                    verts.append(vert)

        center = Vector((0, 0, 0))
        for v in verts:
            center += v.co
        center /= len(verts)

        radius = 0
        for v in verts:
            radius += (v.co - center).length
        radius /= len(verts)

        for v in verts:
            direction = (v.co - center).normalized()
            original_pos = v.co.copy()
            spherized_pos = center + (direction * radius)
            v.co = original_pos.lerp(spherized_pos, self.factor)

        bmesh.update_edit_mesh(obj.data)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(SpherizeMeshOperator)

def unregister():
    bpy.utils.unregister_class(SpherizeMeshOperator)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.spherize_mesh('INVOKE_DEFAULT')
