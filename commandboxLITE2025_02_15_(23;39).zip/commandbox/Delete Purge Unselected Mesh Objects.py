#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Delete Purge Unselected Mesh Objects.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class ClearUnselectedMeshes(bpy.types.Operator):
    bl_idname = "object.clear_unselected_meshes"
    bl_label = "Clear Unselected Meshes"
    bl_options = {'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        all_mesh_objects = [obj for obj in context.scene.objects if obj.type == 'MESH']

        deleted_count = 0
        for obj in all_mesh_objects:
            if obj not in selected_objects:
                bpy.data.objects.remove(obj, do_unlink=True)
                deleted_count += 1

        remaining_count = len(selected_objects)

        textinfo_ = (
            "No mesh deleted." if deleted_count == 0 else
            "1 mesh deleted." if deleted_count == 1 else
            f"{deleted_count} meshes deleted."
        )

        textinfo_+=f"{textinfo_} {remaining_count} mesh(es) remains."

        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

# Register
if __name__ == "__main__":
    bpy.utils.register_class(ClearUnselectedMeshes)

bpy.ops.object.clear_unselected_meshes()
