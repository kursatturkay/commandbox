# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Deletes the selected object, its siblings, and all parent collections.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy


def delete_selected_and_siblings_and_parent_collections():
    
    selected_obj = bpy.context.object

    if selected_obj is None:
        textinfo_ = "Please select an object."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
    else:
        collections = selected_obj.users_collection

        if collections:
            
            target_collection = collections[0]

            objects_to_remove = list(target_collection.objects)
            
            children_collections = list(target_collection.children)

            
            def get_all_parent_collections(coll):
                parent_collections = []
                for c in bpy.data.collections:
                    if coll.name in c.children:
                        parent_collections.append(c)
                        parent_collections.extend(get_all_parent_collections(c))  
                return parent_collections

            
            parent_collections = get_all_parent_collections(target_collection)

            
            
            for obj in objects_to_remove:
                if obj.name in bpy.data.objects:
                    bpy.data.objects.remove(obj, do_unlink=True)

            
            for child in children_collections:
                if child.name in bpy.data.collections:
                    bpy.data.collections.remove(child)

            
            if target_collection.name in bpy.data.collections:
                bpy.data.collections.remove(target_collection)

            
            for parent in parent_collections:
                if parent.name in bpy.data.collections:
                    bpy.data.collections.remove(parent)

            
            textinfo_ = "Selected object, siblings, and parent collections successfully deleted."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        else:
            textinfo_ = "The selected object is not part of any collection."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

delete_selected_and_siblings_and_parent_collections()
