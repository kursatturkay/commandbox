# https://www.youtube.com/watch?v=OPp-AEIMefY

import bpy
import bmesh
from mathutils import Matrix, Vector

def snap_first_to_second_face():
    
    target_obj = bpy.context.active_object  
    selected_objects = bpy.context.selected_objects

    if len(selected_objects) != 2:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select two objects: the object to be moved and the target object.", duration=5)
        return

    
    source_obj = next(obj for obj in selected_objects if obj != target_obj)

    if target_obj.type != 'MESH':
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="The target object must be a mesh.", duration=5)
        return

    
    mesh = target_obj.data
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.faces.ensure_lookup_table()

    
    active_face = bm.faces.active
    if not active_face:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="A surface is not selected on the target object.", duration=5)
        return

    
    face_center = active_face.calc_center_median()
    face_normal = active_face.normal
    face_tangent = active_face.calc_tangent_edge()
    face_binormal = face_normal.cross(face_tangent)

    
    world_center = target_obj.matrix_world @ face_center
    world_normal = target_obj.matrix_world.to_3x3() @ face_normal
    world_tangent = target_obj.matrix_world.to_3x3() @ face_tangent
    world_binormal = target_obj.matrix_world.to_3x3() @ face_binormal

    
    
    rotation_matrix = Matrix((world_tangent, world_binormal, world_normal)).transposed()
    source_obj.matrix_world = Matrix.Translation(world_center) @ rotation_matrix.to_4x4()

    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Mesh {source_obj.name}, orient and snapped mesh to selected face center.", duration=5)


snap_first_to_second_face()
