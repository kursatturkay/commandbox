# https://www.youtube.com/watch?v=ArFbam_6wQg
# ① Select Elements (Egde / Face / Vertex) ② Apply Command Apply Button NPanel > Command Box > Set Pivot Origin To Selected
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 
import bpy

addon_keymaps = []

class OBJECT_OT_SetPivotOriginToSelected(bpy.types.Operator):
    bl_idname = "object.set_pivot_origin_to_selected"
    bl_label = "Set Origin to Selected"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = bpy.context.view_layer.objects.active
        initial_cursor_location = bpy.context.scene.cursor.location.copy()
        
        bpy.ops.view3d.snap_cursor_to_selected()

        if obj.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        bpy.context.scene.cursor.location = initial_cursor_location
        return {'FINISHED'}
    
class VIEW3D_PT_SetPivotOriginPanel(bpy.types.Panel):
    bl_label = "Set Pivot Origin to Selected"
    bl_idname = "VIEW3D_PT_set_origin_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    def draw(self, context):
        layout = self.layout
        layout.operator(OBJECT_OT_SetPivotOriginToSelected.bl_idname)

def register():
    bpy.utils.register_class(OBJECT_OT_SetPivotOriginToSelected)
    bpy.utils.register_class(VIEW3D_PT_SetPivotOriginPanel)
    
    
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name='Mesh', space_type='EMPTY')
    kmi = km.keymap_items.new(OBJECT_OT_SetPivotOriginToSelected.bl_idname, 'O', 'PRESS', ctrl=True, shift=True, alt=True)
    addon_keymaps.append((km, kmi))

def unregister():
    
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    
    bpy.utils.unregister_class(OBJECT_OT_SetPivotOriginToSelected)
    bpy.utils.unregister_class(VIEW3D_PT_SetPivotOriginPanel)

# if __name__ == "__main__":
#     register()
#     bpy.ops.object.set_pivot_origin_to_selected('INVOKE_DEFAULT')

def toggle():
    
    if hasattr(bpy.types, "VIEW3D_PT_set_origin_panel"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented  
        bpy.utils.unregister_class(bpy.types.VIEW3D_PT_set_origin_panel)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
        register()
        bpy.ops.object.set_pivot_origin_to_selected()

# İlk çalıştırma (register yapılacak)
if __name__ == "__main__":
    toggle()