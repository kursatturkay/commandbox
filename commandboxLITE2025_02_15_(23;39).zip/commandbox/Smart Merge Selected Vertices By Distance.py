import bpy
import bmesh

def smart_merge_selected_vertices(initial_distance=0.0001, increment=0.0001):
    
    selected_objects = bpy.context.selected_objects
    if not selected_objects:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No object was selected.", duration=5)
        return

    for obj in selected_objects:
        if obj.type == 'MESH':
            
            bpy.context.view_layer.objects.active = obj

            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='EDGE')
            bpy.ops.mesh.select_all(action='SELECT')

            
            bm = bmesh.from_edit_mesh(obj.data)
            selected_vertices = [v for v in bm.verts if v.select]

            if not selected_vertices:
                bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Selected vertex could not be found for {obj.name}.", duration=5)
                continue

            
            distance = initial_distance
            has_changed = False
            max_iterations = 2000  
            iterations = 0

            while iterations < max_iterations:
                
                bpy.ops.mesh.remove_doubles(threshold=distance)
                
                
                bmesh.update_edit_mesh(obj.data)
                selected_vertices_after_merge = [v for v in bm.verts if v.select]

                
                if len(selected_vertices_after_merge) < len(selected_vertices):
                    has_changed = True
                    break  

                
                distance += increment
                iterations += 1

            if not has_changed:
                bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"The number of vertices did not change for '{obj.name}' ", duration=5)
            else:
                bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"The merging process has been completed for '{obj.name}'", duration=5)

            
            bmesh.update_edit_mesh(obj.data)

            
            bpy.ops.object.mode_set(mode='EDIT')

def main():
    smart_merge_selected_vertices(initial_distance=0.0001, increment=0.0001)

if __name__ == "__main__":
    main()
