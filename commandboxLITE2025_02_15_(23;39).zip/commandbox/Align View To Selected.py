#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Align View To Selected.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
bpy.ops.view3d.view_axis(type='TOP', align_active=True)#use_camera_smooth=True

#bpy.ops.view3d.view_selected(use_all_regions=False)

# import bpy

# for area in bpy.context.screen.areas:
#     if area.type == 'VIEW_3D':
#         for region in area.regions:
#             if region.type == 'WINDOW':
#                 # Mevcut kamera durumunu kaydet
#                 is_perspective = area.spaces[0].region_3d.is_perspective
                
#                 override = {'area': area, 'region': region}
#                 with bpy.context.temp_override(**override):
#                     # View axis komutunu çalıştır
#                     bpy.ops.view3d.view_axis(type='TOP', align_active=True)
                    
#                     # Önceki kamera durumunu geri yükle
#                     current_is_perspective = area.spaces[0].region_3d.is_perspective
#                     if current_is_perspective != is_perspective:
#                         bpy.ops.view3d.view_persportho()
#                 break
#         break