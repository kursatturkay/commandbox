import bpy

# Initialize variables to track the smallest object and its volume
smallest_obj = None
smallest_volume = float('inf')  # Start with a very large number

# Loop through all objects in the scene
for obj in bpy.context.scene.objects:
    if obj.type == 'MESH':  # Only consider mesh objects
        # Calculate the size of the object using its bounding box dimensions
        bbox = obj.bound_box
        
        # Calculate the volume of the bounding box: width * height * depth
        width = abs(bbox[0][0] - bbox[4][0])  # Distance between min/max X
        height = abs(bbox[0][1] - bbox[2][1])  # Distance between min/max Y
        depth = abs(bbox[0][2] - bbox[1][2])  # Distance between min/max Z
        volume = width * height * depth  # Calculate the volume
        
        # Check if the current object is the smallest one so far
        if volume < smallest_volume:
            smallest_volume = volume
            smallest_obj = obj

# Select the smallest object by volume
if smallest_obj:
    bpy.ops.object.select_all(action='DESELECT')  # Deselect all objects
    smallest_obj.select_set(True)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"The smallest object by volume is: {smallest_obj.name}", duration=5)
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No mesh objects found in the scene.", duration=5)

# Aktif 3D Viewport'ta seçilen objeyi görüntüle
for area in bpy.context.screen.areas:
    if area.type == 'VIEW_3D':
        # Aktif olan VIEW_3D region'ını bul
        for region in area.regions:
            if region.type == 'WINDOW':
                # Geçici context ile view_selected'ı çalıştır
                with bpy.context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected(use_all_regions=False)
                break