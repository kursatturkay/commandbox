#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Delete Purge Empty Meshes Geometry.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class DeleteEmptyMeshesOperator(bpy.types.Operator):
    bl_idname = "object.delete_empty_meshes"
    bl_label = "Delete Empty Meshes"
    bl_description = "Deletes all mesh objects with no vertices, edges, or faces"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                mesh = obj.data
                if len(mesh.vertices) < 2 or len(mesh.edges) <2 or len(mesh.polygons) <2:
                    bpy.data.objects.remove(obj, do_unlink=True)
                    count += 1

        textinfo_=f"{count} empty mesh objects deleted."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(DeleteEmptyMeshesOperator)

def unregister():
    bpy.utils.unregister_class(DeleteEmptyMeshesOperator)

if __name__ == "__main__":
    register()
    bpy.ops.object.delete_empty_meshes()
