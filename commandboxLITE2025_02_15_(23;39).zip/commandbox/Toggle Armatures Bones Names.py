import bpy

def toggle_armature_bone_names():
    
    selected_armatures = [obj for obj in bpy.context.selected_objects if obj.type == 'ARMATURE']
    
    if selected_armatures:
        
        has_shownames = any(armature.data.show_names for armature in selected_armatures)
        
        
        for armature in selected_armatures:
            armature.data.show_names = not has_shownames
    else:
        
        all_armatures = [obj for obj in bpy.data.objects if obj.type == 'ARMATURE']
        
        
        has_shownames = any(armature.data.show_names for armature in all_armatures)
        
        
        for armature in all_armatures:
            armature.data.show_names = not has_shownames

toggle_armature_bone_names()
