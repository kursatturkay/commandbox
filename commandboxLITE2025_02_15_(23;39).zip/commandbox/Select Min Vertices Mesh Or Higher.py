import bpy

def select_closest_plus_vertices_mesh():
    
    selected_objects = bpy.context.selected_objects
    
    
    min_diff = float('inf')  
    closest_plus_obj = None
    
    bpy.ops.object.select_all(action='DESELECT')  
    
    if selected_objects:
        
        selected_obj = selected_objects[0]  
        selected_vertex_count = len(selected_obj.data.vertices)
    else:
        selected_vertex_count = float('inf')  

    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.data.update()  
            vertex_count = len(obj.data.vertices)

            
            if selected_objects and vertex_count > selected_vertex_count:
                
                diff = vertex_count - selected_vertex_count
                if diff > 0 and diff < min_diff:  
                    min_diff = diff
                    closest_plus_obj = obj
            
            elif not selected_objects and vertex_count < min_diff:
                min_diff = vertex_count
                closest_plus_obj = obj

    if closest_plus_obj:
        closest_plus_obj.select_set(True)  
        bpy.context.view_layer.objects.active = closest_plus_obj  
        closest_plus_obj.show_in_front = True  
    else:
        
        if selected_objects:
            selected_obj.select_set(True)
            bpy.context.view_layer.objects.active = selected_obj  
            selected_obj.show_in_front = True  

select_closest_plus_vertices_mesh()
