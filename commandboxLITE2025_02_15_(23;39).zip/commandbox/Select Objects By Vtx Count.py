import bpy

# Access the active selected object
selected_obj = bpy.context.active_object

# Get the vertex count of the selected object
if selected_obj is not None and selected_obj.type == 'MESH':
    vertex_count = len(selected_obj.data.vertices)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Vertex count of the selected object: {vertex_count}", duration=5)
    
    # Loop through all objects in the scene and select objects with the same vertex count
    for obj in bpy.context.scene.objects:
        if obj.type == 'MESH' and len(obj.data.vertices) == vertex_count:
            obj.select_set(True)
        else:
            obj.select_set(False)
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No valid selected object or the object is not a MESH.", duration=5)
