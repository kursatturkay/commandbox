# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① Run Select Nearest Highlighted Mesh ② NPanel > Command Box > Select Nearest Highlighted Mesh ③ OR Press F3 ④ filter "Select Nearest Highlighted Mesh"
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 

import bpy

# Global variables
distance_obj_list = []  # Distance list will be shared globally
current_index = 0  # Counter to track the current object in the list
last_highlighted_obj = None  # To store the last highlighted object

class OBJECT_OT_select_nearest_highlight(bpy.types.Operator):
    bl_idname = "object.select_nearest_highlight"
    bl_label = "Select Nearest Highlighted Mesh"

    def execute(self, context):
        global current_index
        global distance_obj_list
        global last_highlighted_obj

        highlighted_object = None
        
        # Find the highlighted object (the selected one)
        for obj in bpy.context.scene.objects:
            if obj.select_get():  # Highlighted object is the selected one
                highlighted_object = obj
                break
        
        # If no object is selected, exit
        if not highlighted_object:
            self.report({'WARNING'}, "No highlighted object found!")
            return {'CANCELLED'}

        # If the highlighted object has changed, recalculate distances
        if last_highlighted_obj != highlighted_object:
            last_highlighted_obj = highlighted_object
            distance_obj_list = self.get_distances(highlighted_object)
            current_index = 0  # Reset the counter when a new object is selected
            self.report({'INFO'}, "Highlighted object changed, recalculating distances.")

        # If there are still objects in the list, pick the next one
        if distance_obj_list:
            # Check if we have more objects to select
            if current_index < len(distance_obj_list):
                next_object = distance_obj_list[current_index][1]  # Get the object from the tuple
                next_object.select_set(True)  # Select the object
                self.report({'INFO'}, f"Selected: {next_object.name}")

                # Print the distance list and the current index
                self.print_debug_info()

                # Increment the counter for the next object
                current_index += 1

            # If all objects are selected, reset the counter to start over
            if current_index >= len(distance_obj_list):
                current_index = 0
                self.report({'INFO'}, "All objects have been selected, starting over.")
        else:
            self.report({'INFO'}, "No more objects to select.")
        
        return {'FINISHED'}

    def get_distances(self, highlighted_object):
        """Get distances between the highlighted object and all other mesh objects."""
        distance_obj_list = []

        # Iterate through all mesh objects and calculate their distance to the highlighted object
        for obj in bpy.context.scene.objects:
            if obj.type == 'MESH' and obj != highlighted_object:  # Skip the highlighted object itself
                distance = (obj.location - highlighted_object.location).length
                distance_obj_list.append((distance, obj))
        
        # Sort the list by distance (ascending order)
        distance_obj_list.sort(key=lambda x: x[0])

        return distance_obj_list

    def print_debug_info(self):
        """Print the current distance list and the index."""
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Distance Object List:", duration=5)
        for dist, obj in distance_obj_list:
            bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Object: {obj.name}, Distance: {dist}", duration=5)
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Current Index: {current_index}", duration=5)
        selected_object = distance_obj_list[current_index][1]
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"Currently Selected Object: {selected_object.name}", duration=5)


class OBJECT_PT_toggle_select_nearest_highlight_panel(bpy.types.Operator):
    bl_idname = "object.toggle_select_nearest_highlight_panel"
    bl_label = "Toggle Sculpt Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.select_nearest_highlight_panel_visible = not context.window_manager.select_nearest_highlight_panel_visible

        if(context.window_manager.select_nearest_highlight_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
# Panel to show the operator button in the Tool tab
class OBJECT_PT_select_nearest_highlight_panel(bpy.types.Panel):
    bl_idname = "OBJECT_PT_select_nearest_highlight"
    bl_label = "Select Nearest Highlighted Mesh"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "select_nearest_highlight_panel_visible", True)

    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("object.toggle_select_nearest_highlight_panel", text="", icon='CANCEL', emboss=False)

    def draw(self, context):
        layout = self.layout
        layout.operator("object.select_nearest_highlight")

def register():
    bpy.utils.register_class(OBJECT_OT_select_nearest_highlight)
    bpy.utils.register_class(OBJECT_PT_select_nearest_highlight_panel)
    bpy.utils.register_class(OBJECT_PT_toggle_select_nearest_highlight_panel)
    bpy.types.WindowManager.select_nearest_highlight_panel_visible = bpy.props.BoolProperty(default=False)

def unregister():
    del bpy.types.WindowManager.select_nearest_highlight_panel_visible
    bpy.utils.unregister_class(OBJECT_PT_toggle_select_nearest_highlight_panel)
    bpy.utils.unregister_class(OBJECT_OT_select_nearest_highlight)
    bpy.utils.unregister_class(OBJECT_PT_select_nearest_highlight_panel)

if __name__ == "__main__":
    register()
    bpy.ops.object.toggle_select_nearest_highlight_panel()