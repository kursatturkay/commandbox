#Select Meshes Non Zero Scale
import bpy

# Tolerans değeri
tolerance = 1e-6

# Tüm objeleri kontrol et
for obj in bpy.context.scene.objects:
    # Sadece Mesh objeleri seç
    if obj.type == 'MESH':
        # Objede ölçek değeri sıfırdan farklıysa seç
        if abs(obj.scale.x - 1.0) > tolerance or abs(obj.scale.y - 1.0) > tolerance or abs(obj.scale.z - 1.0) > tolerance:
            obj.select_set(True)
        else:
            obj.select_set(False)
