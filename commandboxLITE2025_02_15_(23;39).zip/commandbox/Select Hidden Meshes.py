#Select Hidden Meshes
import bpy

def select_invisible_objects():
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and not obj.visible_get():
            obj.hide_set(False)
            obj.select_set(True)

bpy.ops.object.select_all(action='DESELECT')
select_invisible_objects()
