#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Subdivide Mesh.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

import bpy

class ApplySubdivideToSelectedMeshes(bpy.types.Operator):
    bl_idname = "object.apply_subdivide_to_selected"
    bl_label = "Apply Subdivide to Selected Meshes"

    def execute(self, context):
        # Seçili nesneleri al
        selected_objects = bpy.context.selected_objects

        for obj in selected_objects:
            # Eğer obje mesh ise
            if obj.type == 'MESH':
                # Obje Edit Mode'a geç
                bpy.context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')
                
                # FACE moduna geç
                bpy.ops.mesh.select_mode(type='FACE')
                
                # Bütün yüzeyleri seç
                bpy.ops.mesh.select_all(action='SELECT')

                # Yüzeyleri subdivide et (böl)
                bpy.ops.mesh.subdivide(number_cuts=1)  # Buradaki 'number_cuts' parametresi ile bölme miktarını ayarlayabilirsiniz

                # Obje Object Mode'a geri dön
                bpy.ops.object.mode_set(mode='OBJECT')

        return {'FINISHED'}

# Operator'ı kaydet
def register():
    bpy.utils.register_class(ApplySubdivideToSelectedMeshes)

def unregister():
    bpy.utils.unregister_class(ApplySubdivideToSelectedMeshes)

if __name__ == "__main__":
    register()
    bpy.ops.object.apply_subdivide_to_selected()
