bl_info = {
    "name": "Metaball Manager",
    "blender": (4, 3, 2),
    "category": "Object",
    "description": "Add and manage metaballs in the scene."
}

import bpy
import mathutils
import random

previous_active_object = None

def scene_selection_handler(scene):
    global previous_active_object

    active_object = scene.view_layers[0].objects.active
    if active_object != previous_active_object:
        previous_active_object = active_object
        bpy.ops.object.update_metaball_list()
        bpy.ops.object.select_metaball(direction='SCENE_TO_LIST')

def metaball_manager_index_update(self, context):
    bpy.ops.object.select_metaball(direction='LIST_TO_SCENE')

class MetaballManagerProperties(bpy.types.PropertyGroup):
    def update_object_name(self, context):
        obj = bpy.data.objects.get(self.get("_object_name"))
        if obj:
            try:
                obj.name = self.object_name
                self["_object_name"] = self.object_name
            except RuntimeError:
                self.object_name = obj.name  # Revert if name is invalid

    object_name: bpy.props.StringProperty(
        name="Metaball Name",
        update=update_object_name
    )
    object_type: bpy.props.StringProperty(name="Type", default="BALL")

def get_all_metaball_positions():
    return [(obj, obj.location) for obj in bpy.data.objects if obj.type == 'META']

def find_nearest_metaball(current_pos, all_metaballs):
    nearest = None
    min_dist = float('inf')
    for obj, pos in all_metaballs:
        dist = (current_pos - pos).length
        if dist > 0 and dist < min_dist:  # dist > 0 to exclude self
            min_dist = dist
            nearest = obj
    return nearest


class OBJECT_OT_AddMetaballsToArmature(bpy.types.Operator):
    bl_idname = "object.add_metaballs_to_armature"
    bl_label = "Create Metaballs Related to Armature Joints"
    bl_description = "Create metaballs at armature joint positions"

    def execute(self, context):
        selected_obj = context.view_layer.objects.active

        if not selected_obj or selected_obj.type != 'ARMATURE':
            self.report({'WARNING'}, "Please select an armature")
            return {'CANCELLED'}

        armature = selected_obj
        bones = armature.pose.bones

        for bone in bones:
            # Get bone head position in world space
            head_pos = armature.matrix_world @ bone.head

            # Create a new metaball object at the head position
            meta = bpy.data.metaballs.new('MetaBall')
            meta_obj = bpy.data.objects.new('MetaBall', meta)
            context.scene.collection.objects.link(meta_obj)
            meta_obj.location = head_pos
            
            element = meta.elements.new()
            element.co = (0, 0, 0)
            element.radius = 0.2 * bone.length  # Radius based on bone length
            meta.resolution=0.02
            # Get bone tail position in world space
            tail_pos = armature.matrix_world @ bone.tail

            # Create a new metaball object at the tail position
            meta_tail = bpy.data.metaballs.new('MetaBall')
            meta_obj_tail = bpy.data.objects.new('MetaBall', meta_tail)
            meta_tail.resolution=0.02
            context.scene.collection.objects.link(meta_obj_tail)
            meta_obj_tail.location = tail_pos
            element_tail = meta_tail.elements.new()
            element_tail.co = (0, 0, 0)
            element_tail.radius = 0.2 * bone.length  # Radius based on bone length
            meta.resolution=0.02
        return {'FINISHED'}



def calculate_rotation_from_vector(direction_vector):
    # Başlangıç vektörü (varsayılan yön)
    default_direction = mathutils.Vector((0, 0, 1))
    
    # Rotasyon açısını hesapla
    rotation = default_direction.rotation_difference(direction_vector)
    
    # Quaternion'u Euler açılarına çevir
    euler_rotation = rotation.to_euler()
    
    return euler_rotation

class OBJECT_OT_AddMetaball(bpy.types.Operator):
    bl_idname = "object.add_metaball"
    bl_label = "Add Metaball"
    bl_description = "Add a new metaball to the scene"

    def execute(self, context):
        selected_obj = context.view_layer.objects.active
        all_metaballs = get_all_metaball_positions()
        
        if selected_obj and selected_obj.type == 'META':
            # En yakın metaball'u bul
            nearest_obj = find_nearest_metaball(selected_obj.location, all_metaballs)
            
            if nearest_obj:
                # Seçili ve en yakın metaball arasındaki vektörü hesapla
                direction_vector = (nearest_obj.location - selected_obj.location).normalized()
                
                # Rotasyonu hesapla
                rotation = calculate_rotation_from_vector(direction_vector)
                
                # Base distance hesapla
                base_distance = selected_obj.scale.length * 1.2
                
                # Yeni konumu, doğru üzerinde hesapla
                new_location = selected_obj.location + (direction_vector * base_distance)
                
                # Küçük bir rastgele sapma ekle (doğrudan çok uzaklaşmadan)
                random_offset = mathutils.Vector((
                    random.uniform(-0.1, 0.1),
                    random.uniform(-0.1, 0.1),
                    random.uniform(-0.1, 0.1)
                ))
                new_location += random_offset
            else:
                # Eğer başka metaball yoksa, orijine doğru bir yön belirle
                direction_vector = -selected_obj.location.normalized()
                rotation = calculate_rotation_from_vector(direction_vector)
                base_distance = selected_obj.scale.length * 1.2
                new_location = selected_obj.location + (direction_vector * base_distance)
            
            new_scale = selected_obj.scale.copy()
        else:
            # Seçili metaball yoksa varsayılan konum ve rotasyon
            new_location = (
                random.uniform(1, 2),
                random.uniform(1, 2),
                random.uniform(1, 2)
            )
            new_scale = (1, 1, 1)
            rotation = mathutils.Euler((0, 0, 0))

        # Yeni metaball ekle
        bpy.ops.object.metaball_add(type='BALL', location=new_location, rotation=rotation)
        new_obj = context.view_layer.objects.active
        if new_obj and new_obj.type == 'META':
            new_obj.scale = new_scale

        bpy.ops.object.update_metaball_list()
        return {'FINISHED'}

class OBJECT_OT_UpdateMetaballList(bpy.types.Operator):
    bl_idname = "object.update_metaball_list"
    bl_label = "Update Metaball List"
    bl_description = "Update the metaball list to match the scene"

    def execute(self, context):
        scene = context.scene
        scene.metaball_manager_props.clear()

        for obj in bpy.data.objects:
            if obj.type == 'META':
                metaball_props = scene.metaball_manager_props.add()
                metaball_props.object_name = obj.name
                metaball_props["_object_name"] = obj.name  # Store original name
                metaball_props.object_type = obj.data.elements[0].type

        return {'FINISHED'}

class OBJECT_OT_UpdateMetaballType(bpy.types.Operator):
    bl_idname = "object.update_metaball_type"
    bl_label = "Update Metaball Type"
    bl_description = "Update the type of the selected metaball"

    index: bpy.props.IntProperty()
    new_type: bpy.props.StringProperty()

    def execute(self, context):
        props = context.scene.metaball_manager_props[self.index]
        obj = bpy.data.objects.get(props.object_name)
        if obj and obj.type == 'META':
            obj.data.elements[0].type = self.new_type
            props.object_type = self.new_type
        return {'FINISHED'}

class OBJECT_OT_RemoveInvalidMetaballs(bpy.types.Operator):
    bl_idname = "object.remove_invalid_metaballs"
    bl_label = "Remove Invalid Metaballs"
    bl_description = "Remove metaballs from the list that no longer exist in the scene"

    def execute(self, context):
        scene = context.scene
        valid_objects = {obj.name for obj in bpy.data.objects if obj.type == 'META'}
        to_remove = [i for i, prop in enumerate(scene.metaball_manager_props) if prop.object_name not in valid_objects]

        for index in reversed(to_remove):
            scene.metaball_manager_props.remove(index)

        return {'FINISHED'}

class OBJECT_OT_SelectMetaball(bpy.types.Operator):
    bl_idname = "object.select_metaball"
    bl_label = "Sync Selection"
    bl_description = "Sync selection between the scene and the UIList"

    direction: bpy.props.EnumProperty(
        items=[
            ('SCENE_TO_LIST', "Scene to List", "Sync from scene selection to the UIList"),
            ('LIST_TO_SCENE', "List to Scene", "Sync from UIList selection to the scene")
        ],
        default='SCENE_TO_LIST'
    )

    def execute(self, context):
        scene = context.scene

        if self.direction == 'SCENE_TO_LIST':
            # Sync UIList to scene selection
            selected_obj = context.view_layer.objects.active
            if selected_obj and selected_obj.type == 'META':
                for i, prop in enumerate(scene.metaball_manager_props):
                    if prop.object_name == selected_obj.name:
                        scene.metaball_manager_index = i
                        break
        elif self.direction == 'LIST_TO_SCENE':
            # Sync scene selection to UIList
            index = scene.metaball_manager_index
            if index >= 0 and index < len(scene.metaball_manager_props):
                props = scene.metaball_manager_props[index]
                obj = bpy.data.objects.get(props.object_name)
                if obj:
                    context.view_layer.objects.active = obj
                    bpy.ops.object.select_all(action='DESELECT')
                    obj.select_set(True)

        return {'FINISHED'}

class OBJECT_UL_MetaballList(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        obj = bpy.data.objects.get(item.object_name)
        if obj:
            row = layout.row(align=True)
            row.prop(item, "object_name", text="", emboss=False, icon='META_BALL')

            grid = row.grid_flow(row_major=True, columns=5, align=True)
            types = [
                ('BALL', 'META_BALL', 'Sphere'),
                ('CUBE', 'CUBE', 'Cube'),
                ('CAPSULE', 'META_CAPSULE', 'Tube'),
                ('PLANE', 'MESH_GRID', 'Plane'),
                ('ELLIPSOID', 'META_ELLIPSOID', 'Ellipsoid')
            ]
            for t, icon_type, tooltip in types:
                op = grid.operator("object.update_metaball_type", text="", icon=icon_type, emboss=True)
                op.index = index
                op.new_type = t


# Operator for toggling panel visibility
class SCENE_OT_toggle_metaball_manager_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_metaball_manager_panel"
    bl_label = "Toggle Metaball Manager Panel"

    def execute(self, context):
        context.scene.show_metaball_manager = not context.scene.show_metaball_manager

        if(context.scene.show_metaball_manager):
            bpy.ops.view3d.toggle_n_panel_command_box()
            
        return {'FINISHED'}
        

class OBJECT_PT_MetaballPanel(bpy.types.Panel):
    bl_label = "Metaball Manager"
    bl_idname = "OBJECT_PT_metaball_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_metaball_manager

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_metaball_manager_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Add Metaball butonu
        layout.operator("object.add_metaball", text="Add Metaball")
        
        # Armature Metaballs butonu
        layout.operator("object.add_metaballs_to_armature", 
                       text="Create Metaballs Related to Armature Joints")
        
        # Geri kalan UI elemanları
        layout.template_list(
            "OBJECT_UL_MetaballList", "", scene, "metaball_manager_props", 
            scene, "metaball_manager_index"
        )
        layout.operator("object.update_metaball_list", text="Refresh List")

        row = layout.row(align=True)
        row.operator("object.select_metaball", text="Scene to List").direction = 'SCENE_TO_LIST'
        row.operator("object.select_metaball", text="List to Scene").direction = 'LIST_TO_SCENE'

        index = scene.metaball_manager_index
        if index >= 0 and index < len(scene.metaball_manager_props):
            props = scene.metaball_manager_props[index]
            obj = bpy.data.objects.get(props.object_name)
            if obj:
                orientation = context.scene.transform_orientation_slots[0].type
                matrix = obj.matrix_world if orientation == 'GLOBAL' else obj.matrix_basis

                box = layout.box()
                box.label(text=f"Selected: {obj.name}")
                box.prop(obj, "location", text="Location")
                box.prop(obj, "scale", text="Scale")
                box.prop(obj, "rotation_euler", text="Rotation")
                box.prop(obj.data, "resolution", text="Resolution")

bpy.types.Scene.metaball_manager_index = bpy.props.IntProperty(
    update=metaball_manager_index_update
)

classes = [
    MetaballManagerProperties,
    OBJECT_OT_AddMetaball,
    OBJECT_OT_UpdateMetaballList,
    OBJECT_OT_UpdateMetaballType,
    OBJECT_OT_RemoveInvalidMetaballs,
    OBJECT_OT_SelectMetaball,
    OBJECT_OT_AddMetaballsToArmature,  # Yeni sınıfı ekle
    OBJECT_UL_MetaballList,
    OBJECT_PT_MetaballPanel,
    SCENE_OT_toggle_metaball_manager_panel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.metaball_manager_props = bpy.props.CollectionProperty(type=MetaballManagerProperties)
    #bpy.app.handlers.depsgraph_update_post.append(scene_selection_handler)

    bpy.types.Scene.show_metaball_manager = bpy.props.BoolProperty(
    name="Show Metaball Manager",
    default=False)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.metaball_manager_props
    del bpy.types.Scene.metaball_manager_index
    del bpy.types.Scene.show_metaball_manager
    #bpy.app.handlers.depsgraph_update_post.remove(scene_selection_handler)

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_metaball_manager_panel()
