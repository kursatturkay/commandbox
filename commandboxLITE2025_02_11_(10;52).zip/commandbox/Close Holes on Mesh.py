#https://www.youtube.com/watch?v=6IPjyIB7xpg
#Close Holes, Apply Triangulate & Quadrangulate, Remove Small Islands & Weakly Connected Faces
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh

class MESH_OT_close_holes(bpy.types.Operator):
    """Close Holes, Apply Triangulate & Quadrangulate, Remove Small Islands & Weakly Connected Faces"""
    bl_idname = "mesh.close_holes"
    bl_label = "Close Holes + Tri & Quad + Remove Small Islands & Weak Faces"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "No mesh object selected")
            return {'CANCELLED'}
        
        mesh = obj.data
        was_in_edit_mode = obj.mode == 'EDIT'
        
        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='OBJECT')

        bm = bmesh.new()
        bm.from_mesh(mesh)
        
        result = bmesh.ops.holes_fill(bm, edges=bm.edges)
        new_faces = result.get("faces", [])
        fill_count = len(new_faces)

        if fill_count == 0:
            textinfo_= "No holes were found"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            bm.free()
            if was_in_edit_mode:
                bpy.ops.object.mode_set(mode='EDIT')
            return {'CANCELLED'}
        
        for face in bm.faces:
            face.select = face in new_faces

        bmesh.ops.triangulate(bm, faces=new_faces)
        
        weak_faces = [f for f in bm.faces if sum(1 for v in f.verts if len(v.link_faces) == 1) > 0]
        weak_face_count = len(weak_faces)
        bmesh.ops.delete(bm, geom=weak_faces, context='FACES')

        bm.to_mesh(mesh)
        bm.free()
        mesh.update()

        if was_in_edit_mode:
            bpy.ops.object.mode_set(mode='EDIT')

        if was_in_edit_mode:
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type="FACE")
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.tris_convert_to_quads()
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type="FACE")
        bpy.ops.mesh.select_linked()
        bpy.ops.mesh.region_to_loop()
        
        bpy.ops.mesh.select_all(action='INVERT')  
        bpy.ops.mesh.delete_loose()  

        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.separate(type='LOOSE')
        bpy.ops.object.mode_set(mode='OBJECT')

        small_island_count = 0
        for obj in bpy.context.selected_objects:
            if obj.type == 'MESH' and len(obj.data.polygons) < 10:
                bpy.data.objects.remove(obj)
                small_island_count += 1

        textinfo_= f"Closed {fill_count} holes, removed {weak_face_count} weak faces, removed {small_island_count} small islands"
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

def register():
    bpy.utils.register_class(MESH_OT_close_holes)

def unregister():
    bpy.utils.unregister_class(MESH_OT_close_holes)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.close_holes()
