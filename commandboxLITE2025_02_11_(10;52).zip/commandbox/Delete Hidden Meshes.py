import bpy

def delete_invisible_objects():
    for obj in bpy.data.objects:
        if obj.type == 'MESH' and not obj.visible_get():
            bpy.data.objects.remove(obj, do_unlink=True)

delete_invisible_objects()
