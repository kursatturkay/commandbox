# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Select UV Island Seam Boundary Edges.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

bl_info = {
    "name": "Select UV Island Boundaries",
    "blender": (3, 0, 0),
    "category": "UV",
    "description": "Operator to select edges at UV island boundaries",
}

import bpy

class TRANSFORM_OT_SelectUVIslandBoundaries(bpy.types.Operator):
    """Select edges at UV island boundaries"""
    bl_idname = "transform.select_uv_island_boundaries"
    bl_label = "Select UV Island Boundaries"

    def execute(self, context):
        obj = context.active_object

        if obj and obj.type == 'MESH':
            # Ensure the object is in edit mode
            bpy.ops.object.mode_set(mode='EDIT')

            # Create seams from UV islands
            bpy.ops.uv.seams_from_islands()

            # Switch to edge select mode
            bpy.ops.mesh.select_mode(type='EDGE')

            # Deselect all edges first
            bpy.ops.mesh.select_all(action='DESELECT')

            # Get the active object data in object mode to check for seams
            bpy.ops.object.mode_set(mode='OBJECT')

            # Iterate through the edges and select the ones marked as seams
            for edge in obj.data.edges:
                if edge.use_seam:  # Check if the edge is a seam
                    edge.select = True

            # Switch back to edit mode
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="UV island boundary seams selected.", duration=5)
        else:
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text="Active object is not a mesh.", duration=5)

        return {'FINISHED'}

# Registration functions
def register():
    bpy.utils.register_class(TRANSFORM_OT_SelectUVIslandBoundaries)
    bpy.ops.transform.select_uv_island_boundaries()

def unregister():
    bpy.utils.unregister_class(TRANSFORM_OT_SelectUVIslandBoundaries)

if __name__ == "__main__":
    register()
