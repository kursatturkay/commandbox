# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Assign All 0 to Group Weight.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_assign_all_to_group_weight(bpy.types.Operator):
    bl_idname = "object.assign_all_to_group_weight"  
    bl_label = "Assign All to Group with Weight"  
    bl_options = {'REGISTER', 'UNDO'}  

    weight: bpy.props.FloatProperty(
        name="Weight",
        description="Weight value to assign to all vertices in the selected group",
        default=0.0,
        min=0.0,
        max=1.0
    )

    def execute(self, context):
        obj = bpy.context.active_object
        if obj and obj.type == 'MESH':
            mesh = obj.data

            active_group = obj.vertex_groups.active

            if active_group:
                
                for vert in mesh.vertices:
                    active_group.add([vert.index], self.weight, 'REPLACE')

                textinfo_ = f"All vertices assigned to group: {active_group.name} with weight {self.weight:.2f}"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'FINISHED'}
            else:
                textinfo_ = "No Active Vertex Group Selected"
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'CANCELLED'}

        else:
            textinfo_ = "No Mesh Selected"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            return {'CANCELLED'}

def register():
    bpy.utils.register_class(OBJECT_OT_assign_all_to_group_weight)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_assign_all_to_group_weight)

if __name__ == "__main__":
    register()
    bpy.ops.object.assign_all_to_group_weight(weight=1.0)
