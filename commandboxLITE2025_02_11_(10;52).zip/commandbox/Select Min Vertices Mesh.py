import bpy

def select_min_vertices_mesh():
    min_vertices = float('inf')
    min_obj = None
    bpy.ops.object.select_all(action='DESELECT')

    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.data.update()
            vertex_count = len(obj.data.vertices)

            if vertex_count < min_vertices:
                min_vertices = vertex_count
                min_obj = obj

    if min_obj:
        min_obj.select_set(True) 
        bpy.context.view_layer.objects.active = min_obj
        min_obj.show_in_front = True

        
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            
            for region in area.regions:
                if region.type == 'WINDOW':
                    
                    with bpy.context.temp_override(area=area, region=region):
                        bpy.ops.view3d.view_selected(use_all_regions=False)
                    break

select_min_vertices_mesh()
