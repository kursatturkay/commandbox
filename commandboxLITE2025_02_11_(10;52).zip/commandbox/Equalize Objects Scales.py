import bpy
from mathutils import Vector

class OBJECT_OT_equalize_bounding_box(bpy.types.Operator):
    """Equalizes the scales of selected objects based on the last selected object."""
    bl_idname = "object.equalize_bounding_box"
    bl_label = "Equalize Bounding Box Scales"
    bl_options = {'REGISTER', 'UNDO'}
    
    def get_bounding_box_size(self, obj):
        """Returns the bounding box size of the object."""
        world_corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        min_corner = Vector((min([v[i] for v in world_corners]) for i in range(3)))
        max_corner = Vector((max([v[i] for v in world_corners]) for i in range(3)))
        
        # Calculate dimensions (max - min)
        return max_corner - min_corner

    def execute(self, context):
        selected_objects = context.selected_objects
        if len(selected_objects) < 2:
            self.report({'WARNING'}, "At least two objects must be selected")
            return {'CANCELLED'}
        
        # Use the last selected object as the reference
        reference_obj = selected_objects[-1]  # Last selected object
        reference_bb_size = self.get_bounding_box_size(reference_obj)

        # Calculate the maximum scale value from the reference object
        max_scale = max(reference_bb_size)

        # Scale other selected objects based on the reference object
        for obj in selected_objects[:-1]:  # Exclude the last selected object
            obj_bb_size = self.get_bounding_box_size(obj)
            if obj_bb_size.length > 0:  # Prevent division by zero
                # Calculate the scaling factor for proportional scaling
                scale_factor = max_scale / max(obj_bb_size)
                # Apply the same scaling factor to all axes
                obj.scale = [scale_factor * s for s in obj.scale]  # Maintain the original proportions

        return {'FINISHED'}

# Register the operator
bpy.utils.register_class(OBJECT_OT_equalize_bounding_box)

# Run the operator directly
if bpy.context.selected_objects:
    bpy.ops.object.equalize_bounding_box()
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select at least two objects.", duration=5)