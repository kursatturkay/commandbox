# https://www.youtube.com/watch?v=LMz_DdrR5Jc
#Select Edge Boundary to Face.
import bpy

bpy.ops.object.mode_set(mode='OBJECT')

obj = bpy.context.active_object
if obj.type != 'MESH':
    raise Exception("Active object is not a mesh")

bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_mode(type='EDGE')
bpy.ops.mesh.loop_to_region()
bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
