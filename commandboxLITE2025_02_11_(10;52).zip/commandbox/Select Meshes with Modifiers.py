import bpy

for obj in bpy.context.scene.objects:
    
    if obj.type == 'MESH' and len(obj.modifiers) > 0:
        
        obj.select_set(True)
    else:
        
        obj.select_set(False)
