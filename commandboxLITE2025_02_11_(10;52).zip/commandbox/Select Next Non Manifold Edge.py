# https://www.youtube.com/watch?v=tj_PhNt8zAI
import bpy
import bmesh


obj = bpy.context.object


if obj and obj.type == 'MESH':
    bpy.ops.object.mode_set(mode='EDIT')  
    bpy.ops.mesh.select_all(action='DESELECT')  
    
    bpy.ops.mesh.select_mode(type='EDGE')
    
    bm = bmesh.from_edit_mesh(obj.data)
    
    if "last_selected_edge" not in obj:
        obj["last_selected_edge"] = -1  
    
    last_selected_index = obj["last_selected_edge"]
    selected = False
    
    for i, e in enumerate(bm.edges):
        if not e.is_manifold and i > last_selected_index:
            e.select = True  
            obj["last_selected_edge"] = i  
            selected = True
            break  
    
    if not selected:
        for i, e in enumerate(bm.edges):
            if not e.is_manifold:
                e.select = True  
                obj["last_selected_edge"] = i  
                break  
    
    bmesh.update_edit_mesh(obj.data)
    
    bpy.ops.object.mode_set(mode='OBJECT')
    
    bpy.ops.object.mode_set(mode='EDIT')
