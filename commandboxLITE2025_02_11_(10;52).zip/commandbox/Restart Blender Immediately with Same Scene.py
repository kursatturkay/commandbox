#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Blender Immediately with Same Scene.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import os
import sys
import time
import subprocess
import tempfile

import bpy
import os
import sys
import time
import tempfile
import subprocess

class RestartBlenderOperator(bpy.types.Operator):
    bl_idname = "wm.restart_blender"
    bl_label = "Restart Blender"
    bl_description = "Closes and restarts Blender, saving and loading the current scene"

    def execute(self, context):
        """ Kapatır ve Blender'ı yeniden başlatır, sahneyi kaydedip yeniden yükler."""
        
        filepath = bpy.data.filepath
        restart_file = None
        if filepath: # Dosya kaydedilmiş ise
            # Mevcut sahneyi kaydet
            bpy.ops.wm.save_mainfile()
            
            # Kaydetme tamamlanana kadar bekle (zaman aşımı ile)
            timeout = 5  # saniye
            start_time = time.time()
            while bpy.data.is_dirty and (time.time() - start_time) < timeout:
                time.sleep(0.05)
            if bpy.data.is_dirty:
                self.report({'ERROR'}, "Dosya kaydedilemedi.")
                return {'CANCELLED'}
            
            restart_file = bpy.data.filepath #Kaydedilmiş dosyanın güncel yolunu al
           
        else: # Dosya kaydedilmemişse
            # Geçici bir dosya adı oluştur
            temp_file = tempfile.NamedTemporaryFile(suffix=".blend", delete=False).name
            # Mevcut sahneyi geçici dosyaya kaydet
            bpy.ops.wm.save_as_mainfile(filepath=temp_file)
           
            # Kaydetme tamamlanana kadar bekle (zaman aşımı ile)
            timeout = 5  # saniye
            start_time = time.time()
            while bpy.data.is_dirty and (time.time() - start_time) < timeout:
               time.sleep(0.05)
            if bpy.data.is_dirty:
                self.report({'ERROR'}, "Dosya kaydedilemedi.")
                return {'CANCELLED'}

            restart_file = temp_file #Geçici dosya yolunu sakla.
        
        # Komut satırı bağımsız değişkenlerini al
        args = sys.argv
        
        # '--' argümanını bulmaya çalış
        try:
            index = args.index("--")
            restart_args = args[index + 1:]
        except ValueError:
            restart_args = [] # '--' yoksa komut satırı argümanlarını ekleme
        
        # Dosya yolunu başlatma argümanlarına ekle (önüne "--" ekleyerek)
        restart_args.append("--")
        restart_args.append(restart_file)
        
        # Blender'ın çalıştırılabilir dosya yolu
        blender_executable = bpy.app.binary_path

        # Yeni Blender işlemini başlat
        subprocess.Popen([blender_executable, *restart_args])

        # Kapanmadan önce kısa bir süre bekle
        time.sleep(1)
        
        # Mevcut Blender'ı kapat (onay istemeden)
        bpy.ops.wm.quit_blender()
        
        # Geçici dosyanın adını sakla(opsiyonel, temizlik için kullanılabilir.)
        self.temp_file = temp_file if not filepath else None

        return {'FINISHED'}
    
    def __del__(self):
    # Geçici dosyayı sil (sadece dosya kaydedilmemişse)
        if hasattr(self, 'temp_file') and self.temp_file:
            try:
                os.remove(self.temp_file)
            except FileNotFoundError:
                pass

def register():
    bpy.utils.register_class(RestartBlenderOperator)

def unregister():
    bpy.utils.unregister_class(RestartBlenderOperator)

if __name__ == "__main__":
    register()
    # Operatör kaydedildi, menüye eklenmedi.
    #
    # Operatörü kullanmak için:
    #   1. Python Konsolu'nu açın ve aşağıdaki komutu yazın:
    #        bpy.ops.wm.restart_blender()
    #   2. Veya, Edit > Preferences > Keymap kısmından bir tuş ataması yapın.
    #      ve tuş kombinasyonunu kullandığınızda Blender yeniden başlayacaktır.

    bpy.ops.wm.restart_blender()