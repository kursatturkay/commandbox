#https://www.youtube.com/watch?v=dcczG5-mnQ0
#① Generates 100 Random Rigids. ② Press SPACEBAR to play animation

# ① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩  
import bpy
import random


mesh_types = [
    "cube", "uv_sphere", "ico_sphere", "cone", "cylinder", "torus", "monkey"
]

num_meshes = 100  

bpy.context.space_data.shading.type = 'SOLID'
bpy.context.space_data.shading.color_type = 'RANDOM'

for i in range(num_meshes):
    
    mesh_type = random.choice(mesh_types)

    
    location = (
        random.uniform(-30, 30),
        random.uniform(-30, 30),
        random.uniform(10, 100)
    )
    scale = random.uniform(2, 3)

    
    if mesh_type == "cube":
        bpy.ops.mesh.primitive_cube_add(location=location, scale=(scale, scale, scale))
    elif mesh_type == "uv_sphere":
        bpy.ops.mesh.primitive_uv_sphere_add(location=location, scale=(scale, scale, scale))
    elif mesh_type == "ico_sphere":
        bpy.ops.mesh.primitive_ico_sphere_add(location=location, scale=(scale, scale, scale))
    elif mesh_type == "cone":
        bpy.ops.mesh.primitive_cone_add(location=location, scale=(scale, scale, scale))
    elif mesh_type == "cylinder":
        bpy.ops.mesh.primitive_cylinder_add(location=location, scale=(scale, scale, scale))
    elif mesh_type == "torus":
        bpy.ops.mesh.primitive_torus_add(location=location)
    elif mesh_type == "grid":
        bpy.ops.mesh.primitive_grid_add(location=location, size=scale)
    elif mesh_type == "monkey":
        bpy.ops.mesh.primitive_monkey_add(location=location, scale=(scale, scale, scale))

    
    obj = bpy.context.active_object

    
    obj.rotation_euler = (
        random.uniform(0, 3.14),
        random.uniform(0, 3.14),
        random.uniform(0, 3.14)
    )

    
    bpy.ops.rigidbody.object_add()
    obj.rigid_body.type = 'ACTIVE'
    obj.rigid_body.friction = 10
    obj.rigid_body.linear_damping = 0.222796


bpy.ops.mesh.primitive_plane_add(size=150, location=(0, 0, -5))

plane = bpy.context.active_object
bpy.ops.rigidbody.object_add()
plane.rigid_body.type = 'PASSIVE'
plane.rigid_body.friction = 10


bpy.context.scene.frame_start = 1
bpy.context.scene.frame_end = 250
#bpy.ops.screen.animation_play()
