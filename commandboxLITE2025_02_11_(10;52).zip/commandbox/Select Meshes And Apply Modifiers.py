# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#①Selects Meshes with Modifiers ② Applies All Modifiers (Bakes Modifiers).If Modifiers cannot be applied they will be removed (eg. subdivision with 0 disabled modifiers)

import bpy

# Etkin view_layer'daki nesneler üzerinde işlem yap
for obj in bpy.context.view_layer.objects:
    # Sadece mesh türündeki nesneleri ve modifiye içerenleri kontrol et
    if obj.type == 'MESH' and len(obj.modifiers) > 0:
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj

        # Tüm modifiyeleri kontrol et ve uygula veya sil
        for modifier in obj.modifiers:
            try:
                bpy.ops.object.modifier_apply(modifier=modifier.name)
            except RuntimeError:
                print(f"Modifier '{modifier.name}' on object '{obj.name}' could not be applied. Removing it.")
                obj.modifiers.remove(modifier)  # Uygulanamayan modifier'ı sil
    else:
        obj.select_set(False)



# for obj in bpy.context.scene.objects:
    
#     if obj.type == 'MESH' and len(obj.modifiers) > 0:
        
#         obj.select_set(True)
        
#         bpy.context.view_layer.objects.active = obj
        
        
#         for modifier in obj.modifiers:
#             bpy.ops.object.modifier_apply(modifier=modifier.name)
#     else:
        
#         obj.select_set(False)
