#https://www.youtube.com/watch?v=c_I2CBDG6y4
#Double Click To Toggle Center On Interest Addon Panel. Focuses on Selected objects (as well as verteces,edges,faces) in the viewport

bl_info = {
    "name": "Center On Interest",
    "blender": (4, 1, 1),
    "category": "Object",
    "location": "View3D > Side Bar (Press N) > Fables Alive Games > Center On Interest",
    "version": (2024, 10, 5),
    "author": "Fables Alive Games",
    "description":"Focus on Selected objects (as well as verteces,edges,faces) in the viewport"
}

import bpy
import bmesh
from mathutils import Vector
import webbrowser


def set_pivot_to_selection(context):
    min_corner = Vector((float('inf'), float('inf'), float('inf')))
    max_corner = Vector((float('-inf'), float('-inf'), float('-inf')))

    def update_bounding_box(point):
        nonlocal min_corner, max_corner
        min_corner = Vector(
            (min(min_corner.x,
                 point.x), min(min_corner.y,
                               point.y), min(min_corner.z, point.z)))
        max_corner = Vector(
            (max(max_corner.x,
                 point.x), max(max_corner.y,
                               point.y), max(max_corner.z, point.z)))

    if context.mode == 'OBJECT':
        selected_objects = context.selected_objects
        if not selected_objects:
            return {'CANCELLED'}

        for obj in selected_objects:
            for corner in obj.bound_box:
                world_corner = obj.matrix_world @ Vector(corner)
                update_bounding_box(world_corner)

    elif context.mode == 'EDIT_MESH':
        obj = context.edit_object
        mesh = bmesh.from_edit_mesh(obj.data)

        if not mesh.select_history:
            return {'CANCELLED'}

        for elem in mesh.select_history:
            if isinstance(elem, bmesh.types.BMVert):
                world_vert = obj.matrix_world @ elem.co
                update_bounding_box(world_vert)
            elif isinstance(elem, bmesh.types.BMEdge):
                for vert in elem.verts:
                    world_vert = obj.matrix_world @ vert.co
                    update_bounding_box(world_vert)
            elif isinstance(elem, bmesh.types.BMFace):
                for vert in elem.verts:
                    world_vert = obj.matrix_world @ vert.co
                    update_bounding_box(world_vert)

    center = (min_corner + max_corner) / 2

    for area in context.screen.areas:
        if area.type == 'VIEW_3D':
            for space in area.spaces:
                if space.type == 'VIEW_3D':
                    region_3d = space.region_3d
                    break

    region_3d.view_location = center

    return {'FINISHED'}

def change_alpha(obj, new_alpha):
    current_color = obj.color
    new_color = (current_color[0], current_color[1], current_color[2], new_alpha)
    obj.color = new_color
    bpy.context.space_data.shading.color_type = 'OBJECT'


def enable_xray_for_selected(context, selected_objs):
    for obj in context.visible_objects:
        if obj in selected_objs:
            obj.show_in_front = True
            obj.show_wire = True
            change_alpha(obj,1)

        else:
            obj.show_in_front = False
            obj.show_wire = False
            
            change_alpha(obj,0.4)

def disable_xray_for_all(context):
    for obj in context.visible_objects:
        obj.show_in_front = False
        obj.show_wire = False
        change_alpha(obj,1)

def update_xray_mode(self, context):
    selected_objects = context.selected_objects
    if context.scene.xray_mode:
        enable_xray_for_selected(context, selected_objects)
    else:
        disable_xray_for_all(context)

class OBJECT_OT_set_pivot_to_selection(bpy.types.Operator):
    bl_idname = "object.set_pivot_to_selection"
    bl_label = "Focus On Interest"
    bl_description = "Focus On Interest"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        result = set_pivot_to_selection(context)
        if result == {'FINISHED'}:
            update_xray_mode(self, context)
        return result

# Operator for toggling panel visibility
class SCENE_OT_toggle_center_on_interest_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_center_on_interest_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.show_center_on_interest_panel = not context.scene.show_center_on_interest_panel

        if(context.scene.show_center_on_interest_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}

class VIEW3D_PT_custom_panel(bpy.types.Panel):
    bl_label = "Center On Interest"
    bl_idname = "VIEW3D_PT_custom_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_description = "Center On Interest Panel"
    bl_category = 'Command Box'


    @classmethod
    def poll(cls, context):
        
        return context.scene.show_center_on_interest_panel

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_center_on_interest_panel", text="", icon ='CANCEL',emboss = False)


    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene, "xray_mode", text="X-Ray Mode")
        layout.operator(OBJECT_OT_set_pivot_to_selection.bl_idname)

addon_keymaps = []


def register():
    bpy.utils.register_class(OBJECT_OT_set_pivot_to_selection)
    bpy.utils.register_class(VIEW3D_PT_custom_panel)
    bpy.utils.register_class(SCENE_OT_toggle_center_on_interest_panel)



    bpy.types.Scene.xray_mode = bpy.props.BoolProperty(
        name="X-Ray Mode for Selected",
        description="Enable X-Ray mode for selected objects",
        default=True,
        update=update_xray_mode)


    bpy.types.Scene.show_center_on_interest_panel = bpy.props.BoolProperty(
    name="Show Select Vertices By Edges Panel",
    default=False)

    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name='3D View', space_type='VIEW_3D')

    kmi = km.keymap_items.new(OBJECT_OT_set_pivot_to_selection.bl_idname,
                              'F',
                              'PRESS',
                              ctrl=True,
                              shift=True)
    addon_keymaps.append((km, kmi))


def unregister():
    bpy.utils.unregister_class(OBJECT_OT_set_pivot_to_selection)
    bpy.utils.unregister_class(VIEW3D_PT_custom_panel)
    bpy.utils.unregister_class(SCENE_OT_toggle_center_on_interest_panel)

    del bpy.types.Scene.xray_mode
    del bpy.types.Scene.show_center_on_interest_panel

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()


# if __name__ == "__main__":
#     register()

# def toggle():
    
#     if hasattr(bpy.types, "VIEW3D_PT_custom_panel"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
#         #unregister() throws mRNA error ? couldnt resolve so commented  
#         bpy.utils.unregister_class(bpy.types.VIEW3D_PT_custom_panel)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
#         register()

# İlk çalıştırma (register yapılacak)
if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_center_on_interest_panel()

