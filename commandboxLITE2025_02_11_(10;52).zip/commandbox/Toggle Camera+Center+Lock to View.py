# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggles (Align Active Camera to View+Lock Camera+Frame Camera Bounds)


import bpy

def toggle_camera_view():
    # Get the current area (view3d) and space data
    area = next((area for area in bpy.context.screen.areas if area.type == 'VIEW_3D'), None)
    if not area:
        print("No 3D Viewport found.")
        return

    space = next((space for space in area.spaces if space.type == 'VIEW_3D'), None)
    if not space:
        print("No VIEW_3D space found.")
        return

    # Check if we're already in camera view
    is_camera_view = space.region_3d.view_perspective == 'CAMERA'

    if is_camera_view:
        # Exit camera view and unlock camera
        #bpy.ops.view3d.view_persportho()
        space.lock_camera = False
        #bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
    else:
        # Enter camera view, lock the camera, and frame the camera bounds
        bpy.ops.view3d.view_camera()
        space.lock_camera = True
        bpy.ops.view3d.view_center_camera()
        #bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

# Toggle camera view
if __name__ == "__main__":
    toggle_camera_view()
