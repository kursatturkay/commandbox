import bpy

class RenameSelectedObjects(bpy.types.Operator):
    """Rename Selected Objects"""
    bl_idname = "object.rename_selected"
    bl_label = "Rename Selected Objects"
    bl_options = {'REGISTER', 'UNDO'}

    prefix: bpy.props.StringProperty(name="Prefix:", default="Obj_")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        selected_objects = bpy.context.selected_objects
        for index, obj in enumerate(selected_objects):
            obj.name = f"{self.prefix}{index + 1}"
        return {'FINISHED'}

def register():
    bpy.utils.register_class(RenameSelectedObjects)

def unregister():
    bpy.utils.unregister_class(RenameSelectedObjects)

if __name__ == "__main__":
    register()
    # Betiği çalıştırmak için:
    bpy.ops.object.rename_selected('INVOKE_DEFAULT')
