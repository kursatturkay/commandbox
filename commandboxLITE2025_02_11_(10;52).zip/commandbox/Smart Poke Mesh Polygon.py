#https://www.youtube.com/watch?v=0-zsoGJH3EQ 
#Smart Poke Mesh Polygon. Looks at selected faces and pokes faces with more than 4 edges
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import bmesh

class SmartPokeOperator(bpy.types.Operator):
    """Looks at selected faces and pokes faces with more than 4 edges"""
    bl_idname = "mesh.smart_poke"
    bl_label = "Smart Poke Operator"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        poke_count = 0  # Counter for the number of faces poked

        if obj and obj.type == 'MESH':
            # Switch to Edit mode from Object mode
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type='FACE')
            bpy.ops.mesh.select_all(action='SELECT')
            
            # Get the BMesh data for modification
            bm = bmesh.from_edit_mesh(obj.data)
            bm.faces.ensure_lookup_table()

            # Check faces and apply poke operation to those with more than 4 edges
            for face in bm.faces:
                if len(face.verts) > 4:
                    bmesh.ops.poke(bm, faces=[face])
                    poke_count += 1  # Increment the counter for each face poked

            # Update BMesh to reflect changes
            bmesh.update_edit_mesh(obj.data)

            # Switch back to Object mode
            bpy.ops.object.mode_set(mode='OBJECT')

            # Report the result
            if poke_count > 0:
                textinfo_= f"Smart Poke applied to {poke_count} faces."
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            else:
                textinfo_= f"No faces were affected by the Smart Poke operation."
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "No mesh object selected.")
            #bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            return {'CANCELLED'}

# Register the operator
def register():
    bpy.utils.register_class(SmartPokeOperator)

def unregister():
    bpy.utils.unregister_class(SmartPokeOperator)

if __name__ == "__main__":
    register()
    # Optionally run the operator right after registration
    bpy.ops.mesh.smart_poke()
