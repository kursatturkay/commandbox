# https://www.youtube.com/watch?v=43vwGM8grPg
#Must be in Edit|Face Mode. Select Face(s). Apply Command. It creates meshes from the edge loop surrounding the selected faces

import bpy

# Mevcut nesneleri listele (sadece Mesh nesnelerini tutalım)
previous_objects = set(obj for obj in bpy.context.scene.objects if obj.type == 'MESH')

# Mevcut seçili yüzeyleri seçin ve ayırın
bpy.ops.mesh.region_to_loop()
bpy.ops.mesh.duplicate()
bpy.ops.mesh.separate(type='SELECTED')

# Object Mode'a geçiş
bpy.ops.object.mode_set(mode='OBJECT')
bpy.ops.object.select_all(action='DESELECT')
# Yeni nesneleri listele (Mevcut nesnelerle karşılaştırarak yeni nesneleri bul)
new_objects = set(obj for obj in bpy.context.scene.objects if obj.type == 'MESH') - previous_objects

# Yeni nesneleri seçili yap
for obj in new_objects:
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']

for obj in selected_objects:
    
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')  
    bpy.ops.mesh.separate(type='LOOSE')  
    bpy.ops.object.mode_set(mode='OBJECT')  
