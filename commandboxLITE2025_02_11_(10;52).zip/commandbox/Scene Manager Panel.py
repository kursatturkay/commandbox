#https://www.youtube.com/watch?v=UUBs_1-yYxY
#Manage scenes: create, clone, rename, delete, and switch between scenes
import bpy

bl_info = {
    "name": "Scene Manager",
    "author": "Kürşat Türkay",
    "version": (1, 5),
    "blender": (4, 3, 2),
    "location": "View3D > Sidebar > Scene Manager",
    "description": "Manage scenes: create, clone, rename, delete, and switch between scenes.",
    "category": "Scene"
}

# List item for UIList
class SCENE_UL_scenes(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        scene = item
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.scale_y = 1.0
            row.operator("scene.set_active", text=scene.name, icon='SCENE_DATA').scene_name = scene.name
        elif self.layout_type == 'GRID':
            layout.alignment = 'CENTER'
            layout.operator("scene.set_active", text="", icon='SCENE_DATA').scene_name = scene.name

# Operator for switching scenes
class SCENE_OT_set_active(bpy.types.Operator):
    """Set the selected scene as active"""
    bl_idname = "scene.set_active"
    bl_label = "Set Active Scene"
    bl_options = {'REGISTER', 'UNDO'}

    scene_name: bpy.props.StringProperty()

    def execute(self, context):
        scene = bpy.data.scenes.get(self.scene_name)
        if scene:
            context.window.scene = scene
            self.report({'INFO'}, f"Switched to scene: {scene.name}")
        else:
            self.report({'WARNING'}, "Scene not found.")
        return {'FINISHED'}

# Operator for toggling panel visibility
class SCENE_OT_toggle_scene_manager_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_scene_manager_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.show_scene_manager = not context.scene.show_scene_manager

        if(context.scene.show_scene_manager):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}

# Panel class
class SCENE_PT_manager(bpy.types.Panel):
    """Scene Manager Panel"""
    bl_label = "Scene Manager"
    bl_idname = "SCENE_PT_manager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_scene_manager

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_scene_manager_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # UIList for scenes
        row = layout.row()
        row.template_list("SCENE_UL_scenes", "", bpy.data, "scenes", scene, "active_index")

        layout.separator()

        # Buttons for operations
        box_ops = layout.box()
        box_ops.label(text="Scene Operations", icon='TOOL_SETTINGS')
        box_ops.operator("scene.rename_dialog", text="Rename Active Scene", icon='TEXT')
        box_ops.operator("scene.create", text="Create New Scene", icon='ADD')
        box_ops.operator("scene.clone", text="Clone Current Scene", icon='DUPLICATE')
        box_ops.operator("scene.delete_current", text="Delete Current Scene", icon='X')

# Operator for renaming scenes
class SCENE_OT_rename_dialog(bpy.types.Operator):
    """Rename the active scene"""
    bl_idname = "scene.rename_dialog"
    bl_label = "Rename Active Scene"
    bl_options = {'REGISTER', 'UNDO'}

    new_name: bpy.props.StringProperty(name="New Scene Name")

    def execute(self, context):
        scene = context.scene
        if self.new_name:
            scene.name = self.new_name
            self.report({'INFO'}, f"Scene renamed to: {self.new_name}")
        else:
            self.report({'WARNING'}, "No name entered for renaming.")
        return {'FINISHED'}

    def invoke(self, context, event):
        self.new_name = context.scene.name
        return context.window_manager.invoke_props_dialog(self)

# Other scene operations
class SCENE_OT_create(bpy.types.Operator):
    """Create a new scene"""
    bl_idname = "scene.create"
    bl_label = "Create New Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.scene.new(type='NEW')
        self.report({'INFO'}, "New scene created")
        return {'FINISHED'}

class SCENE_OT_clone(bpy.types.Operator):
    """Clone the current scene"""
    bl_idname = "scene.clone"
    bl_label = "Clone Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.scene.new(type='FULL_COPY')
        self.report({'INFO'}, "Scene cloned")
        return {'FINISHED'}

class SCENE_OT_delete_current(bpy.types.Operator):
    """Delete the current scene"""
    bl_idname = "scene.delete_current"
    bl_label = "Delete Current Scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        scene_name = scene.name
        if len(bpy.data.scenes) > 1:
            other_scene = next(s for s in bpy.data.scenes if s != scene)
            context.window.scene = other_scene
            bpy.data.scenes.remove(scene)
            self.report({'INFO'}, f"Scene '{scene_name}' deleted.")
        else:
            self.report({'WARNING'}, "Cannot delete the last remaining scene.")
        return {'FINISHED'}

# Registration
classes = (
    SCENE_UL_scenes,
    SCENE_OT_set_active,
    SCENE_OT_toggle_scene_manager_panel,
    SCENE_OT_create,
    SCENE_OT_clone,
    SCENE_OT_delete_current,
    SCENE_OT_rename_dialog,
    SCENE_PT_manager,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
        
    bpy.types.Scene.active_index = bpy.props.IntProperty()
    
    bpy.types.Scene.show_scene_manager = bpy.props.BoolProperty(
        name="Show Scene Manager",
        default=False
    )

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.active_index
    del bpy.types.Scene.show_scene_manager

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_scene_manager_panel()
