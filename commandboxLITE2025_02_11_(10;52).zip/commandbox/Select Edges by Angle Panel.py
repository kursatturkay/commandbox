# https://www.youtube.com/watch?v=ixyebNEiF8Q&t=204s
#Activates Select Edges by Angle Panel.
bl_info = {
    "name": "Select Edge by Angle",
    "blender": (4, 2, 2),
    "category": "Mesh",
}

import bpy
import bmesh
from math import radians
from bpy.props import FloatProperty

def select_edges_by_angle(context):
    obj = context.active_object
    angle_threshold = context.scene.angle_threshold

    if obj is None or obj.type != 'MESH':
        return

    # Ensure we're in edit mode
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='EDGE')  # Set selection mode to EDGE

    bm = bmesh.from_edit_mesh(obj.data)

    # Convert angle threshold to radians
    angle_radians = radians(angle_threshold)

    # Deselect all vertices, edges, and faces
    for vert in bm.verts:
        vert.select = False
    for edge in bm.edges:
        edge.select = False
    for face in bm.faces:
        face.select = False

    # Select edges by angle
    for edge in bm.edges:
        if not edge.is_boundary:
            faces = edge.link_faces
            if len(faces) == 2:  # Edge must have two adjacent faces
                angle = faces[0].normal.angle(faces[1].normal)
                if angle > angle_radians:
                    edge.select = True

    # Update the mesh
    bmesh.update_edit_mesh(obj.data)

# Operator for toggling panel visibility
class SCENE_OT_toggle_select_edge_by_angle_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_select_edge_by_angle_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.select_edge_by_angle_visible = not context.scene.select_edge_by_angle_visible

        if(context.scene.select_edge_by_angle_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class PANEL_PT_SelectEdgeByAngle(bpy.types.Panel):
    """UI Panel for Select Edge by Angle"""
    bl_label = "Select Edges by Angle"
    bl_idname = "PANEL_PT_select_edge_by_angle"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        
        
        return context.scene.select_edge_by_angle_visible 

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_select_edge_by_angle_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        layout.prop(scene, "angle_threshold", text="Angle Threshold")
        layout.separator(type="LINE")
        layout.operator("transform.apply_edge_crease", text="Apply Edge Crease")
        layout.operator("transform.uncrease_all", text="Uncrease All")

class SCENE_OT_UpdateEdgeSelection(bpy.types.Operator):
    """Update edge selection when slider changes"""
    bl_idname = "scene.update_edge_selection"
    bl_label = "Update Edge Selection"

    def execute(self, context):
        select_edges_by_angle(context)
        return {'FINISHED'}

class TRANSFORM_OT_ApplyEdgeCrease(bpy.types.Operator):
    """Apply maximum edge crease to selected edges"""
    bl_idname = "transform.apply_edge_crease"
    bl_label = "Apply Edge Crease"

    def execute(self, context):
        bpy.ops.transform.edge_crease(value=1, snap=False)
        return {'FINISHED'}

class TRANSFORM_OT_UncreaseAll(bpy.types.Operator):
    """Remove all edge creases from the mesh"""
    bl_idname = "transform.uncrease_all"
    bl_label = "Uncrease All"

    def execute(self, context):
        obj = context.active_object

        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "Active object is not a mesh")
            return {'CANCELLED'}

        # Ensure we're in edit mode
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')  # Select all edges
        bpy.ops.transform.edge_crease(value=-1, snap=False)  # Remove crease
        bpy.ops.mesh.select_all(action='DESELECT')  # Deselect all

        self.report({'INFO'}, "All edge creases removed.")
        return {'FINISHED'}

def update_edge_selection(self, context):
    bpy.ops.scene.update_edge_selection()

classes = [
    PANEL_PT_SelectEdgeByAngle,
    SCENE_OT_toggle_select_edge_by_angle_panel,
    SCENE_OT_UpdateEdgeSelection,
    TRANSFORM_OT_ApplyEdgeCrease,
    TRANSFORM_OT_UncreaseAll
]

def register():
    bpy.types.Scene.angle_threshold = FloatProperty(
        name="Angle Threshold",
        description="The angle threshold in degrees",
        default=30.0,
        min=0.0,
        max=180.0,
        update=update_edge_selection
    )

    bpy.types.Scene.select_edge_by_angle_visible = bpy.props.BoolProperty(
    name="Select Edges By Angle Panel Visible",default=False)

    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.angle_threshold
    del bpy.types.Scene.select_edge_by_angle_visible 
    
if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_select_edge_by_angle_panel()   


# def toggle():
    
#     if hasattr(bpy.types, "PANEL_PT_select_edge_by_angle"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        
#         bpy.utils.unregister_class(bpy.types.PANEL_PT_select_edge_by_angle)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
#         register()
#         bpy.ops.scene.update_edge_selection()


# if __name__ == "__main__":
#     toggle()

