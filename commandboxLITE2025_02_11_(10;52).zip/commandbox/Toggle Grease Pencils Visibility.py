# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Grease Pencils Visibility.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

# Toggle visibility for all Grease Pencil objects in the scene
def toggle_grease_pencil_visibility():
    toggle_to = None  # Determine toggle state based on the first object's current state
    
    for obj in bpy.data.objects:
        if obj.type == 'GREASEPENCIL':  # Check if the object is a Grease Pencil
            if toggle_to is None:  # Decide initial toggle state
                toggle_to = not obj.hide_get()
            obj.hide_set(toggle_to)  # Toggle visibility
            print(f"Grease Pencil '{obj.name}' visibility set to {'hidden' if toggle_to else 'visible'}.")

toggle_grease_pencil_visibility()
