
import bpy
import bmesh
from mathutils import Vector
import numpy as np

def gaussian_smooth(obj, sigma=1.0, iterations=10):
    
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    
    
    mesh = bmesh.from_edit_mesh(obj.data)
    
    
    for _ in range(iterations):
        vertices = [v.co.copy() for v in mesh.verts]
        
        for v in mesh.verts:
            
            neighbor_coords = [vertices[e.other_vert(v).index] for e in v.link_edges]
            
            
            if neighbor_coords:
                distances = np.array([np.linalg.norm(v.co - n) for n in neighbor_coords])
                weights = np.exp(-(distances**2) / (2 * sigma**2))
                weights /= weights.sum()  
                
                
                smooth_position = Vector((0.0, 0.0, 0.0))
                for n, w in zip(neighbor_coords, weights):
                    smooth_position += n * w  
                
                
                v.co = v.co * 0.5 + smooth_position * 0.5

        bmesh.update_edit_mesh(obj.data)


obj = bpy.context.active_object
if obj and obj.type == 'MESH':
    gaussian_smooth(obj, sigma=1.0, iterations=1)

bpy.ops.object.mode_set(mode='OBJECT')