#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Restart Blender Immediately.
#autorun=False
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import os
import sys

import bpy
import os
import sys
import time

import bpy
import os
import sys
import time
import subprocess

class RestartBlenderOperator(bpy.types.Operator):
    bl_idname = "wm.restart_blender"
    bl_label = "Restart Blender"
    bl_description = "Closes and restarts Blender"

    def execute(self, context):
        """ Kapatır ve Blender'ı yeniden başlatır."""
        
        # Komut satırı bağımsız değişkenlerini al
        args = sys.argv
        
        # '--' argümanını bulmaya çalış
        try:
            index = args.index("--")
            restart_args = args[index + 1:]
        except ValueError:
            restart_args = [] # '--' yoksa komut satırı argümanlarını ekleme
        
        # Blender'ın çalıştırılabilir dosya yolu
        blender_executable = bpy.app.binary_path

        # Yeni Blender işlemini başlat
        subprocess.Popen([blender_executable, *restart_args])

        # Kapanmadan önce kısa bir süre bekle
        time.sleep(0.5) # 0.5 saniye bekle

        # Mevcut Blender'ı kapat
        bpy.ops.wm.quit_blender()

        return {'FINISHED'}

def register():
    bpy.utils.register_class(RestartBlenderOperator)

def unregister():
    bpy.utils.unregister_class(RestartBlenderOperator)

if __name__ == "__main__":
    register()
    # Operatör kaydedildi, menüye eklenmedi.
    #
    # Operatörü kullanmak için:
    #   1. Python Konsolu'nu açın ve aşağıdaki komutu yazın:
    #        bpy.ops.wm.restart_blender()
    #   2. Veya, Edit > Preferences > Keymap kısmından bir tuş ataması yapın.
    #      ve tuş kombinasyonunu kullandığınızda Blender yeniden başlayacaktır.

bpy.ops.wm.restart_blender()