#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Select NGon Faces. Hold Shift For Append New Selections.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh

class SelectNgonFaces(bpy.types.Operator):
    bl_idname = "mesh.select_ngon_faces"
    bl_label = "Select Faces with 5+ Edges"
    bl_options = {'REGISTER', 'UNDO'}

    shift_pressed: bpy.props.BoolProperty(default=False)

    def execute(self, context):
        obj = context.object

        if obj and obj.type == 'MESH':
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(type="FACE")

            bm = bmesh.from_edit_mesh(obj.data)

            
            if not self.shift_pressed:
                bpy.ops.mesh.select_all(action='DESELECT')

            count = 0
            for face in bm.faces:
                if len(face.verts) >= 5:
                    face.select = True
                    count += 1

            bmesh.update_edit_mesh(obj.data)
            textinfo_ =f"Faces Selected: {count}"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}

    def invoke(self, context, event):
        self.shift_pressed = event.shift
        return self.execute(context)


def register():
    bpy.utils.register_class(SelectNgonFaces)

def unregister():
    bpy.utils.unregister_class(SelectNgonFaces)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.select_ngon_faces('INVOKE_DEFAULT')
