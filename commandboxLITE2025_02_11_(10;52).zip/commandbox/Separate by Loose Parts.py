import bpy

selected_objects = [obj for obj in bpy.context.selected_objects if obj.type == 'MESH']

for obj in selected_objects:
    
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')  
    bpy.ops.mesh.separate(type='LOOSE')  
    bpy.ops.object.mode_set(mode='OBJECT')  
