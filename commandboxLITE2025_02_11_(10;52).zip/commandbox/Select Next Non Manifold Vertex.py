# https://www.youtube.com/watch?v=tj_PhNt8zAI
import bpy
import bmesh


obj = bpy.context.object


if obj and obj.type == 'MESH':
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='DESELECT')
    
    bpy.ops.mesh.select_mode(type='VERT')
 
    bm = bmesh.from_edit_mesh(obj.data)
    
    
    if "last_selected_vertex" not in obj:
        obj["last_selected_vertex"] = -1  
    
    last_selected_index = obj["last_selected_vertex"]
    selected = False
    
    
    for i, v in enumerate(bm.verts):
        if not v.is_manifold and i > last_selected_index:
            v.select = True  
            obj["last_selected_vertex"] = i  
            selected = True
            break  
    
    
    if not selected:
        for i, v in enumerate(bm.verts):
            if not v.is_manifold:
                v.select = True  
                obj["last_selected_vertex"] = i  
                break  
    
    
    bmesh.update_edit_mesh(obj.data)
    
    
    bpy.ops.object.mode_set(mode='EDIT')
