# https://www.youtube.com/watch?v=fFaVtxX0SdA

import bpy
import random

colors = [
    (0.1, 0.1, 0.1),  # Koyu Gri (Maya'nın varsayılan arka planı)
    (0.1, 0.2, 0.3),  # mavimsi
    (0.2, 0.2, 0.2),  # mavimsi
    (0.3, 0.3, 0.3),  # Daha açık gri
    (0.5, 0.5, 0.5),  # Orta gri
    (0.7, 0.7, 0.7),  # Açık gri
    (0.5, 0.7, 1.0)
]

background_types=["SINGLE_COLOR", "LINEAR", "RADIAL"]

background_type=random.choice(background_types)
base_color_high = random.choice(colors)

base_color_gradient = base_color_high
while base_color_gradient == base_color_high:
    base_color_gradient = random.choice(colors)

prefs = bpy.context.preferences

theme = prefs.themes[0]  
view_3d_theme = theme.view_3d  

view_3d_theme.space.gradients.background_type = background_type 

view_3d_theme.space.gradients.high_gradient = base_color_high  
view_3d_theme.space.gradients.gradient = base_color_gradient     

bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Suitable colors have been set for the 3D Viewport background.", duration=5)
