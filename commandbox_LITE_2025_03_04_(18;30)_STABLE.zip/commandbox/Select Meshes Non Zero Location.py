import bpy


tolerance = 1e-6


for obj in bpy.context.scene.objects:
    
    if obj.type == 'MESH':
        
        if abs(obj.location.x) > tolerance or abs(obj.location.y) > tolerance or abs(obj.location.z) > tolerance:
            obj.select_set(True)
        else:
            obj.select_set(False)
