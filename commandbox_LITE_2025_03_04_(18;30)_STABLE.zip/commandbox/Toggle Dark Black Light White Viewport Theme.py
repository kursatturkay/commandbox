#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggle Dark Black Light White Viewport Theme.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import random


BLACK = (0.0, 0.0, 0.0)
WHITE = (1.0, 1.0, 1.0)


prefs = bpy.context.preferences
theme = prefs.themes[0]
view_3d_theme = theme.view_3d


current_color = tuple(view_3d_theme.space.gradients.high_gradient)


if current_color == BLACK:
    new_color = WHITE
else:
    new_color = BLACK


view_3d_theme.space.gradients.background_type = "SINGLE_COLOR"


view_3d_theme.space.gradients.high_gradient = new_color
view_3d_theme.space.gradients.gradient = new_color


bpy.ops.view3d.modal_draw_operator(
    "INVOKE_DEFAULT", 
    text=f"3D Viewport background changed to : {'White' if new_color == WHITE else 'Black'}.", 
    duration=5
)
