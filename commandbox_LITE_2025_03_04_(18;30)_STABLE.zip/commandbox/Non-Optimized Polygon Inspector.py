# https://www.youtube.com/watch?v=sJi6RgtldeM
#① Toggles a Panel that marks high and low-polygons, using red for non-optimized and green for optimized meshes

bl_info = {
    "name": "Non Optimized Polygon Inspector",
    "blender": (4, 1, 1),
    "category": "Object",
    "location": "View3D > Side Bar (Press N) > Fables Alive Games > Non Optimized Polygon Inspector",
    "version": (2024, 10, 5),
    "author": "Fables Alive Games",
    "description": "Colorize objects in the viewport based on their vertex count",
    "homepage": "https://fablesalive.gumroad.com"
}

import bpy

original_colors = {}
original_settings = {}
updating = False

def get_vertex_count(obj):
    if obj.type == 'MESH':
        return len(obj.data.vertices)
    return 0

def get_min_max_vertex_count(objects):
    vertex_counts = [get_vertex_count(obj) for obj in objects if obj.type == 'MESH']
    return min(vertex_counts), max(vertex_counts)

def calculate_color(min_color, mid_color, max_color, factor):
    if factor < 0.5:
        return (
            min_color[0] + factor * 2 * (mid_color[0] - min_color[0]),
            min_color[1] + factor * 2 * (mid_color[1] - min_color[1]),
            min_color[2] + factor * 2 * (mid_color[2] - min_color[2]),
        )
    else:
        return (
            mid_color[0] + (factor - 0.5) * 2 * (max_color[0] - mid_color[0]),
            mid_color[1] + (factor - 0.5) * 2 * (max_color[1] - mid_color[1]),
            mid_color[2] + (factor - 0.5) * 2 * (max_color[2] - mid_color[2]),
        )

def color_objects_by_vertex_count(context, min_color, mid_color, max_color):
    global updating
    if updating:
        return
    updating = True
    
    objects = context.scene.objects
    min_vertex_count, max_vertex_count = get_min_max_vertex_count(objects)
    
    for obj in objects:
        if obj.type == 'MESH':
            if obj.name not in original_colors:
                original_colors[obj.name] = obj.color[:]
            vertex_count = get_vertex_count(obj)
            factor = (vertex_count - min_vertex_count) / (max_vertex_count - min_vertex_count) if max_vertex_count != min_vertex_count else 0
            color = calculate_color(min_color, mid_color, max_color, factor)
            obj.color = (*color, 1)  # (R, G, B, A)
    
    context.view_layer.update()
    updating = False

def restore_original_colors(context):
    objects = context.scene.objects
    for obj in objects:
        if obj.type == 'MESH':
            if obj.name in original_colors:
                obj.color = original_colors[obj.name]
            else:
                obj.color = (0.5, 0.5, 0.5, 1)  # Varsayılan olarak gri
    
    context.view_layer.update()

def store_original_settings():
    space_data = bpy.context.space_data
    original_settings['shading_type'] = space_data.shading.type
    original_settings['shading_light'] = space_data.shading.light
    original_settings['show_overlays'] = space_data.overlay.show_overlays
    original_settings['show_wireframes'] = space_data.overlay.show_wireframes
    original_settings['color_type'] = space_data.shading.color_type

def restore_original_settings():
    space_data = bpy.context.space_data
    space_data.shading.type = original_settings.get('shading_type', 'SOLID')
    space_data.shading.light = original_settings.get('shading_light', 'FLAT')
    space_data.overlay.show_overlays = original_settings.get('show_overlays', True)
    space_data.overlay.show_wireframes = original_settings.get('show_wireframes', True)
    space_data.shading.color_type = original_settings.get('color_type', 'VERTEX')

class VIEW3D_PT_vertex_count_color_panel(bpy.types.Panel):
    bl_label = "Non Optimized Polygon Inspector"
    bl_idname = "VIEW3D_PT_vertex_count_color_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "enable_colorize", text="Enable Colorize")
        
        if scene.enable_colorize:
            layout.prop(scene, "min_color")
            layout.prop(scene, "mid_color")
            layout.prop(scene, "max_color")
            layout.operator("object.vertex_count_color")
        else:
            layout.operator("object.restore_original_color")
        
        layout.separator()
        layout.operator("object.fast_optimize")
        layout.prop(scene, "threshold")

class OBJECT_OT_vertex_count_color(bpy.types.Operator):
    bl_label = "ReInspect Non Optimized Polygons"
    bl_idname = "object.vertex_count_color"
    bl_description = "Color objects in the viewport based on their vertex count with customizable min, mid, and max colors"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        store_original_settings()
        bpy.context.space_data.shading.type = 'SOLID'
        bpy.context.space_data.shading.light = 'FLAT'
        bpy.context.space_data.overlay.show_overlays = True
        bpy.context.space_data.overlay.show_wireframes = True
        bpy.context.space_data.shading.color_type = 'VERTEX'
        scene = context.scene
        if scene.enable_colorize:
            min_color = scene.min_color
            mid_color = scene.mid_color
            max_color = scene.max_color
            color_objects_by_vertex_count(context, min_color, mid_color, max_color)
        return {'FINISHED'}

class OBJECT_OT_restore_original_color(bpy.types.Operator):
    bl_label = "Restore Original Colors"
    bl_idname = "object.restore_original_color"
    bl_description = "Restore original colors of the objects or set to gray"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        restore_original_colors(context)
        restore_original_settings()
        return {'FINISHED'}

class OBJECT_OT_fast_optimize(bpy.types.Operator):
    bl_label = "Fast Optimize"
    bl_idname = "object.fast_optimize"
    bl_description = "Optimize the selected object quickly"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.object
        if obj.mode != 'EDIT':
            bpy.ops.object.editmode_toggle()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles(threshold=context.scene.threshold)
        bpy.ops.mesh.mark_sharp(clear=True)
        bpy.ops.object.editmode_toggle()
        
        # Renkleri tekrar hesapla
        if context.scene.enable_colorize:
            min_color = context.scene.min_color
            mid_color = context.scene.mid_color
            max_color = context.scene.max_color
            color_objects_by_vertex_count(context, min_color, mid_color, max_color)
        
        return {'FINISHED'}

def scene_update_handler(scene, depsgraph):
    global updating
    context = bpy.context
    if updating:
        return
    if context.scene.enable_colorize:
        min_color = context.scene.min_color
        mid_color = context.scene.mid_color
        max_color = context.scene.max_color
        color_objects_by_vertex_count(context, min_color, mid_color, max_color)
    else:
        restore_original_colors(context)
        restore_original_settings()

def load_post_handler(dummy):
    global original_colors, original_settings
    original_colors = {}
    original_settings = {}
    bpy.app.handlers.depsgraph_update_post.append(scene_update_handler)

def register():
    bpy.utils.register_class(OBJECT_OT_vertex_count_color)
    bpy.utils.register_class(OBJECT_OT_restore_original_color)
    bpy.utils.register_class(OBJECT_OT_fast_optimize)
    bpy.utils.register_class(VIEW3D_PT_vertex_count_color_panel)
    bpy.types.Scene.min_color = bpy.props.FloatVectorProperty(
        name="Min Color",
        subtype='COLOR',
        default=(0.0, 1.0, 0.0),
        min=0.0, max=1.0,
        description="Color for minimum vertex count"
    )
    bpy.types.Scene.mid_color = bpy.props.FloatVectorProperty(
        name="Mid Color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0),
        min=0.0, max=1.0,
        description="Color for mid vertex count"
    )
    bpy.types.Scene.max_color = bpy.props.FloatVectorProperty(
        name="Max Color",
        subtype='COLOR',
        default=(1.0, 0.0, 0.0),
        min=0.0, max=1.0,
        description="Color for maximum vertex count"
    )
    bpy.types.Scene.enable_colorize = bpy.props.BoolProperty(
        name="Enable Colorize",
        default=True,
        description="Enable or disable the colorize feature"
    )
    bpy.types.Scene.threshold = bpy.props.FloatProperty(
        name="Threshold",
        default=0.0201,
        description="Threshold for remove doubles"
    )
    bpy.app.handlers.depsgraph_update_post.append(scene_update_handler)
    bpy.app.handlers.load_post.append(load_post_handler)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_vertex_count_color)
    bpy.utils.unregister_class(OBJECT_OT_restore_original_color)
    bpy.utils.unregister_class(OBJECT_OT_fast_optimize)
    bpy.utils.unregister_class(VIEW3D_PT_vertex_count_color_panel)
    del bpy.types.Scene.min_color
    del bpy.types.Scene.mid_color
    del bpy.types.Scene.max_color
    del bpy.types.Scene.enable_colorize
    del bpy.types.Scene.threshold
    bpy.app.handlers.depsgraph_update_post.remove(scene_update_handler)
    bpy.app.handlers.load_post.remove(load_post_handler)

# if __name__ == "__main__":
#     register()


def toggle():
    
    if hasattr(bpy.types, "VIEW3D_PT_vertex_count_color_panel"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented  
        bpy.utils.unregister_class(bpy.types.VIEW3D_PT_vertex_count_color_panel)
    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='Non Optimized Polygon Inspector Panel not exist.Now registering under CommandBox Tab', duration=5)
        register()

# İlk çalıştırma (register yapılacak)
if __name__ == "__main__":
    toggle()
