# https://www.youtube.com/watch?v=ixyebNEiF8Q&t=38s
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Select Overlapping Vertices.

import bpy
import bmesh
import mathutils

def select_duplicate_vertices(threshold=0.0001):
    
    obj = bpy.context.active_object
    if obj is None or obj.type != 'MESH':
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select a mesh object.", duration=5)
        return

    
    if obj.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    mesh = bmesh.from_edit_mesh(obj.data)

    
    kd = mathutils.kdtree.KDTree(len(mesh.verts))
    for i, vert in enumerate(mesh.verts):
        if not vert.hide:  
            kd.insert(vert.co, i)
    kd.balance()

    
    duplicate_indices = set()
    for vert in mesh.verts:
        if vert.index in duplicate_indices or vert.hide:
            continue
        duplicates = kd.find_range(vert.co, threshold)
        if len(duplicates) > 1:  
            for co, index, dist in duplicates:
                duplicate_indices.add(index)

    
    for vert in mesh.verts:
        vert.select = vert.index in duplicate_indices

    
    bmesh.update_edit_mesh(obj.data)
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"{len(duplicate_indices)} overlapping vertices were found and selected.", duration=5)


select_duplicate_vertices(threshold=0.001)
