#https://www.youtube.com/watch?v=L1G9MXTE0oc
#
import bpy
import math

import bpy
import math


# Operator for toggling panel visibility
class TOGGLE_WEIGHT_PAINT_POSE_TESTER_PANEL_OT_Operator(bpy.types.Operator):
    bl_idname = "wm.toggle_weight_paint_pose_tester_panel"
    bl_label = "Toggle Sculpt Panel"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.window_manager.show_weight_paint_pose_tester_panel = not context.window_manager.show_weight_paint_pose_tester_panel

        if (context.window_manager.show_weight_paint_pose_tester_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class WeightPaintPoseTesterPanel(bpy.types.Panel):
    bl_label = "Weight Paint Bone Pose Tester"
    bl_idname = "VIEW3D_PT_weight_paint_pose_tester"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "show_weight_paint_pose_tester_panel", True)

    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_weight_paint_pose_tester_panel",
                        text="",
                        icon='QUESTION',
                        emboss=False)
        
        layout.operator("wm.toggle_weight_paint_pose_tester_panel",
                        text="",
                        icon='CANCEL',
                        emboss=False)   

    def draw(self, context):
        layout = self.layout

        layout.prop(context.scene, "rotation_axis", text="Rotation")

        box = layout.box()
        box.prop(context.scene,
                 "exclude_bone_indices",
                 text="Bone Indices",
                 placeholder="eg. 0 1 2 6 5")

        row = box.row()
        split = row.split(factor=0.25)
        split.label(text="Specific Bones:")
        split.prop(context.scene, "index_mode", text="")

        # Ayırıcı
        layout.separator()

        # Kaydırıcı
        layout.prop(context.scene, "pose_slider", slider=True)

        # Reset Butonu
        layout.separator()
        layout.operator("pose.reset_all_bones",
                        text="Reset All Bone Rotations")


def update_bone_pose(self, context):
    if bpy.context.scene.tool_settings.use_keyframe_insert_auto:
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False

    pose_value = context.scene.pose_slider
    rotation_axis = context.scene.rotation_axis
    exclude_indices = [
        int(i.strip()) for i in context.scene.exclude_bone_indices.split()
        if i.strip().isdigit()
    ]
    mode = context.scene.index_mode

    axis_index = {"X": 0, "Y": 1, "Z": 2}[rotation_axis]

    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE' and obj.pose is not None:
            for idx, bone in enumerate(obj.pose.bones):
                if mode == 'EXCLUDE' and idx in exclude_indices:
                    continue  # EXCLUDE modunda atla
                elif mode == 'INCLUDE' and idx not in exclude_indices:
                    continue  # INCLUDE modunda atla

                if bone.rotation_mode == 'QUATERNION':
                    quat = bone.rotation_quaternion
                    mult = ((pose_value) *  math.log10((idx + 1)))
                    if axis_index == 0:
                        quat[1] = math.sin(math.radians(mult) / 2)
                    elif axis_index == 1:
                        quat[2] = math.sin(math.radians(mult) / 2)
                    elif axis_index == 2:
                        quat[3] = math.sin(math.radians(mult) / 2)

                    quat[0] = math.cos(math.radians(mult) / 2)
                else:
                    euler = bone.rotation_euler
                    euler[axis_index] = math.radians(pose_value)

            obj.update_tag(refresh={'DATA'})


def reset_bone_poses(context):
    for obj in bpy.data.objects:
        if obj.type == 'ARMATURE' and obj.pose is not None:
            for bone in obj.pose.bones:
                if bone.rotation_mode == 'QUATERNION':
                    bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                else:
                    bone.rotation_euler = (0.0, 0.0, 0.0)

            context.scene.pose_slider=0
            obj.update_tag(refresh={'DATA'})


class ResetAllBonesOperator(bpy.types.Operator):
    bl_idname = "pose.reset_all_bones"
    bl_label = "Reset All Bones"
    bl_description = "Reset all bone rotations to their default pose"

    def execute(self, context):
        reset_bone_poses(context)
        self.report({'INFO'}, "All bone rotations have been reset.")
        return {'FINISHED'}


# Register ve unregister fonksiyonları
def register():



    bpy.utils.register_class(TOGGLE_WEIGHT_PAINT_POSE_TESTER_PANEL_OT_Operator)
    bpy.utils.register_class(WeightPaintPoseTesterPanel)
    bpy.utils.register_class(ResetAllBonesOperator)
    bpy.types.Scene.pose_slider = bpy.props.FloatProperty(
        name="Pose Value",
        description="Adjust pose value for all bones",
        min=-90.0,
        max=90.0,
        default=0.0,
        update=update_bone_pose)
    bpy.types.Scene.rotation_axis = bpy.props.EnumProperty(
        name="Rotation Axis",
        description="Choose which axis to apply rotation to",
        items=[
            ("X", "X Axis", "Rotate around the X axis"),
            ("Y", "Y Axis", "Rotate around the Y axis"),
            ("Z", "Z Axis", "Rotate around the Z axis"),
        ],
        default="X",
        update=update_bone_pose)
    bpy.types.Scene.exclude_bone_indices = bpy.props.StringProperty(
        name="Bone Indices",
        description="Space-separated indices of bones to include/exclude",
        default="",
        update=update_bone_pose)
    
    bpy.types.Scene.index_mode = bpy.props.EnumProperty(
        name="Mode",
        description=
        "Choose whether to exclude or include the specified indices",
        items=[
            ("EXCLUDE", "Exclude", "Exclude the specified indices"),
            ("INCLUDE", "Include", "Include only the specified indices"),
        ],
        default="EXCLUDE",
        update=update_bone_pose)
    
    bpy.types.WindowManager.show_weight_paint_pose_tester_panel = bpy.props.BoolProperty(
        default=False)    
    
def unregister():
    bpy.utils.unregister_class(TOGGLE_WEIGHT_PAINT_POSE_TESTER_PANEL_OT_Operator)

    bpy.utils.unregister_class(WeightPaintPoseTesterPanel)
    bpy.utils.unregister_class(ResetAllBonesOperator)
    del bpy.types.Scene.pose_slider
    del bpy.types.Scene.rotation_axis
    del bpy.types.Scene.exclude_bone_indices
    del bpy.types.Scene.index_mode

    del bpy.types.WindowManager.show_weight_paint_pose_tester_panel

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_weight_paint_pose_tester_panel()


# def toggle():

#     if hasattr(bpy.types, "VIEW3D_PT_weight_paint_pose_tester"):
#         bpy.ops.view3d.modal_draw_operator(
#             "INVOKE_DEFAULT",
#             text=
#             'Weight Paint Pose Tester exist. Now removing from under Command Box Tab',
#             duration=5)

#         bpy.utils.unregister_class(
#             bpy.types.VIEW3D_PT_weight_paint_pose_tester)

#     else:
#         bpy.ops.view3d.modal_draw_operator(
#             "INVOKE_DEFAULT",
#             text=
#             'Weight Paint Pose Tester not exist. Now registering under Command Box Tab',
#             duration=5)
#         register()


# if __name__ == "__main__":
#     toggle()
