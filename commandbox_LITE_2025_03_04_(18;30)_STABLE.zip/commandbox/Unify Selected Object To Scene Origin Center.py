#https://www.youtube.com/watch?v=c1Oe5r0RJ_4
#Unify Selected Object.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import math

def unify_deformation(obj):
    bpy.context.view_layer.objects.active = obj  # Objeyi aktif yap
    bpy.ops.object.mode_set(mode='OBJECT')
    
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    
    dimensions = obj.dimensions
    max_dim = max(dimensions)  
    
    scale_factor = 1 / max_dim
    
    obj.scale = (scale_factor, scale_factor, scale_factor)
    
    bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)
    
    obj.location = (0, 0, 0)  # Sahne merkezine taşı

# Tüm seçili objeler için uygula
for obj in bpy.context.selected_objects:
    unify_deformation(obj)
