#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Open CommandBox History Log.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import webbrowser

class OpenWebpageOperator(bpy.types.Operator):
    """Open a Web Page in Default Browser"""
    bl_idname = "wm.open_webpage"
    bl_label = "Open Web Page"
    
    url: bpy.props.StringProperty(
        name="URL",
        default="https://bit.ly/commandboxlog",
        description="Web page to open"
    )

    def execute(self, context):
        webbrowser.open(self.url)
        self.report({'INFO'}, f"Opened {self.url}")
        return {'FINISHED'}


def register():
    bpy.utils.register_class(OpenWebpageOperator)

def unregister():
    bpy.utils.unregister_class(OpenWebpageOperator)

if __name__ == "__main__":
    register()
    
    bpy.ops.wm.open_webpage()
