#https://www.youtube.com/watch?v=1pjMA7jrgP0
#Split meshes using multiple cutting planes simultaneously. Cutting planes can overlap and create complex intersections. Note: Only plane objects are supported as slicers - other mesh types may cause unexpected results.

import bpy
import math

bl_info = {
    "name": "Mesh Slicer Cutter Panel",
    "author": "fables alive games",
    "version": (1, 0),
    "blender": (4, 3, 2),
    "location": "View3D > Command Box",
    "description": "Split meshes using multiple cutting planes simultaneously. Cutting planes can overlap and create complex intersections. Note: Only plane objects are supported as slicers - other mesh types may cause unexpected results.",
    "category": "Command Box",
}

class SlicerContainer:

    if bpy.app.version <= (4, 3, 2):    
        def __init__(self, left=None, right=None):
            self.left = left
            self.right = right
    else:
        def __init__(self, left=None, right=None,*args, **kwargs):
            super().__init__(*args, **kwargs)
            self.left = left
            self.right = right

class GENERATE_SLICERS_OT(bpy.types.Operator):
    bl_idname = 'mesh.generate_slicer'
    bl_label = 'Generate slicer'
    bl_options = {"REGISTER", "UNDO"}
    bl_description = 'Generate slicing plane'
    slicerContainers = []
        
    def execute(self, context):
        selected = bpy.context.selected_objects
        
        if len(selected) == 0:
            self.report({"ERROR"}, "Please select an object first!")
            return {"CANCELLED"}
            
        active_obj = bpy.context.active_object
        if not active_obj:
            self.report({"ERROR"}, "No active object!")
            return {"CANCELLED"}
            
        location = active_obj.location.copy()
        
        bpy.ops.mesh.primitive_plane_add(size=1.0, location=location)
        slicer = bpy.context.active_object 
        slicer.name = "Slicer"
        
        scale_factor = 3.0  # Ölçek katsayısı
        scale_values = (
            active_obj.scale.x * scale_factor,  
            active_obj.scale.y * scale_factor,  
            active_obj.scale.z * scale_factor   
        )
        
        bpy.ops.transform.resize(value=scale_values)
        
        return {'FINISHED'}

class SLICE_OT(bpy.types.Operator):
    bl_idname = "mesh.slice"
    bl_label = "Slice"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = 'Slice selected mesh'
    slicerContainers = []
    
    def makeSlicers(self, srcObject):
        container = SlicerContainer()
        bpy.ops.mesh.primitive_cube_add(size=1, location=srcObject.location)
        ob = bpy.context.active_object 
        ob.parent = srcObject
        ob.location = (0,0,0.5)
        container.left = ob
        
        bpy.ops.mesh.primitive_cube_add(size=1, location=srcObject.location)
        ob = bpy.context.active_object 
        ob.parent = srcObject
        ob.location = (0,0,-0.5)
        container.right = ob
        self.slicerContainers.append(container)
    
    def cloneObject(self, objectToClone):
        ob = objectToClone.copy()
        ob.data = objectToClone.data.copy()
        bpy.data.collections["Collection"].objects.link(ob)
        bpy.ops.object.select_all(action='DESELECT')
        ob.select_set(True)
        bpy.context.view_layer.objects.active = ob
        ob.name = "Clone"
        return ob
    
    def doBool(self, src, object, operation):
        boolmod = src.modifiers.new("Bool", 'BOOLEAN')
        boolmod.object = object
        boolmod.solver = 'EXACT'
        boolmod.operation = operation
        bpy.ops.object.modifier_apply(modifier='Bool')
    
    def centerOrigin(self, obj):
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.context.view_layer.objects.active = obj
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        # Convert to mesh after centering origin
        bpy.ops.object.convert(target='MESH')
    
    def execute(self, context):
        self.slicerContainers.clear()
        selectedObjects = bpy.context.selected_objects
        
        if(len(selectedObjects) < 2):
             self.report({"ERROR"}, "You need to select at least two objects!")
             return {"CANCELLED"}
        
        activeObjects = []
        original_object = bpy.context.active_object
        activeObjects.append(original_object)
        selectedObjects.remove(activeObjects[0])
        
        # Store slicer objects to delete later
        slicerObjects = [obj for obj in selectedObjects if obj.name.startswith("Slicer")]
        
        for src in selectedObjects:
            self.makeSlicers(src)
        
        for index in range(len(selectedObjects)):
            newActiveObjects = []
      
            for active in activeObjects:
                newObj = self.cloneObject(active)
                self.doBool(newObj,self.slicerContainers[index].left,'DIFFERENCE')
   
                if(len(newObj.data.vertices) == 0):
                    bpy.ops.object.delete()
                else:
                    newActiveObjects.append(newObj)
                
                newObj = self.cloneObject(active)
                self.doBool(newObj,self.slicerContainers[index].right,'DIFFERENCE')
                
                if(len(newObj.data.vertices) == 0):
                    bpy.ops.object.delete()
                else:
                    newActiveObjects.append(newObj)

                activeObjects = newActiveObjects
        
        # Delete original object
        bpy.data.objects.remove(original_object, do_unlink=True)
        
        # Clean up temporary objects
        for container in self.slicerContainers:
            bpy.data.objects.remove(container.left, do_unlink=True)
            bpy.data.objects.remove(container.right, do_unlink=True)
        self.slicerContainers.clear()
        
        # Delete all slicer objects
        for slicer in slicerObjects:
            bpy.data.objects.remove(slicer, do_unlink=True)
        
        # Name and center origins for all resulting pieces
        for i in range(len(activeObjects)):
            activeObjects[i].name = "Bool result " + str(i)
            self.centerOrigin(activeObjects[i])
                
        return {'FINISHED'}
    

# Operator for toggling panel visibility
class SCENE_OT_toggle_mesh_slicer_cutter_panel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_mesh_slicer_cutter_panel"
    bl_label = "Toggle Mesh Slider Panel"

    def execute(self, context):
        context.scene.show_mesh_slicer_cutter_panel = not context.scene.show_mesh_slicer_cutter_panel

        if(context.scene.show_mesh_slicer_cutter_panel):
            bpy.ops.view3d.toggle_n_panel_command_box()
            
        return {'FINISHED'}
    
class SLICE_PT_Panel(bpy.types.Panel):
    bl_label = "Mesh Slicer Cutter Panel"
    bl_idname = "SLICE_PT_PANEL"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'
    
    @classmethod
    def poll(cls, context):
        
        return context.scene.show_mesh_slicer_cutter_panel

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_mesh_slicer_cutter_panel", text="", icon ='CANCEL',emboss = False)


    def draw(self, context):
        layout = self.layout

        row = layout.row()
        row.operator(GENERATE_SLICERS_OT.bl_idname, text="🔪 Create Slicer")
       
        if(len(bpy.context.selected_objects) == 1):
            row.enabled = True
        else:
            row.enabled = False

        row = layout.row()
        
        objName = "Slice"
        if(len(bpy.context.selected_objects) > 0):
            objName = "Target: " + str(bpy.context.active_object.name)
        
        row.operator(SLICE_OT.bl_idname, text=f'✂️{objName}')
        if(len(bpy.context.selected_objects) > 1):
            row.enabled = True
        else:
            row.enabled = False
            
def register():
    bpy.utils.register_class(SCENE_OT_toggle_mesh_slicer_cutter_panel)
    bpy.utils.register_class(SLICE_PT_Panel)
    bpy.utils.register_class(SLICE_OT)
    bpy.utils.register_class(GENERATE_SLICERS_OT)
    bpy.types.Scene.show_mesh_slicer_cutter_panel = bpy.props.BoolProperty(default=False)


def unregister():
    
    bpy.utils.unregister_class(SLICE_PT_Panel)
    bpy.utils.unregister_class(SLICE_OT)
    bpy.utils.unregister_class(GENERATE_SLICERS_OT)
    bpy.utils.unregister_class(SCENE_OT_toggle_mesh_slicer_cutter_panel)
    del bpy.types.Scene.show_mesh_slicer_cutter_panel
if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_mesh_slicer_cutter_panel()