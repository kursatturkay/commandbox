#https://www.youtube.com/watch?v=h3-CKi7bTMA
#Click On Surfaces To Create Vertices as New Mesh. ESC Or Right Mouse To Complete.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
from bpy_extras import view3d_utils
from mathutils import Vector

class AddVertexOnClickOperator(bpy.types.Operator):
    bl_idname = "object.add_vertex_on_click"
    bl_label = "Add Vertex on Click"
    
    if bpy.app.version <= (4, 3, 2):    
        def __init__(self):
            self.vertex_objects = []
            self.current_vertex = None
            self.is_dragging = False
    else:
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)

            self.vertex_objects = []
            self.current_vertex = None
            self.is_dragging = False
    
    def get_hit_point(self, context, mouse_pos):
        region = context.region
        rv3d = context.region_data
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, mouse_pos)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, mouse_pos)
        
        depsgraph = context.evaluated_depsgraph_get()
        hit, location, normal, index, object, matrix = context.scene.ray_cast(depsgraph, ray_origin, view_vector)
        
        return hit, location if hit else None
    
    def create_vertex_object(self, context, location):
        mesh = bpy.data.meshes.new(name=f"Vertex_{len(self.vertex_objects)}")
        obj = bpy.data.objects.new(f"VertexObj_{len(self.vertex_objects)}", mesh)
        context.collection.objects.link(obj)
        
        bm = bmesh.new()
        bm.verts.new(location)
        bm.verts.ensure_lookup_table()
        bm.to_mesh(mesh)
        bm.free()
        
        self.vertex_objects.append(obj)
        return obj
    
    def update_vertex_position(self, obj, location):
        if obj and obj.data:
            bm = bmesh.new()
            bm.from_mesh(obj.data)
            bm.verts.ensure_lookup_table()
            
            if len(bm.verts) > 0:
                bm.verts[0].co = location
                bm.to_mesh(obj.data)
            
            bm.free()
            obj.data.update()
    
    def join_vertices(self, context):
        if not self.vertex_objects:
            return None
            
        # Yeni mesh oluştur
        mesh = bpy.data.meshes.new(name="CombinedVertices")
        bm = bmesh.new()
        
        try:
            # Her vertex objesinden konum al
            for obj in self.vertex_objects:
                if obj and obj.data:
                    vertex_bm = bmesh.new()
                    vertex_bm.from_mesh(obj.data)
                    vertex_bm.verts.ensure_lookup_table()
                    
                    if vertex_bm.verts:
                        world_pos = obj.matrix_world @ vertex_bm.verts[0].co
                        bm.verts.new(world_pos)
                    
                    vertex_bm.free()
            
            # BMesh'i güncelleyip mesh'e aktar
            bm.verts.ensure_lookup_table()
            bm.to_mesh(mesh)
            
        finally:
            bm.free()
        
        # Yeni obje oluştur
        obj = bpy.data.objects.new("CombinedVertices", mesh)
        context.collection.objects.link(obj)
        
        # Eski vertex objelerini temizle
        for v_obj in self.vertex_objects:
            bpy.data.objects.remove(v_obj, do_unlink=True)
        
        return obj
    
    def modal(self, context, event):
        if event.type == 'LEFTMOUSE':
            if event.value == 'PRESS' and not self.is_dragging:
                mouse_pos = (event.mouse_region_x, event.mouse_region_y)
                hit, location = self.get_hit_point(context, mouse_pos)
                
                if location:
                    self.is_dragging = True
                    self.current_vertex = self.create_vertex_object(context, location)
                
            elif event.value == 'RELEASE' and self.is_dragging:
                self.is_dragging = False
                self.current_vertex = None
        
        elif event.type == 'MOUSEMOVE' and self.is_dragging:
            mouse_pos = (event.mouse_region_x, event.mouse_region_y)
            hit, location = self.get_hit_point(context, mouse_pos)
            
            if location and self.current_vertex:
                self.update_vertex_position(self.current_vertex, location)
        
        elif event.type in {'RIGHTMOUSE', 'ESC','RET'}:
            # Join işlemini gerçekleştir
            final_obj = self.join_vertices(context)
            
            if final_obj:
                # Son objeyi seç
                bpy.ops.object.select_all(action='DESELECT')
                final_obj.select_set(True)
                context.view_layer.objects.active = final_obj

                bpy.ops.object.mode_set(mode='EDIT')  

                bpy.ops.mesh.select_mode(type='VERT')  
                bpy.ops.mesh.select_all(action='SELECT')
            
            return {'CANCELLED'}
        
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            self.vertex_objects = []
            self.current_vertex = None
            self.is_dragging = False
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D needed")
            return {'CANCELLED'}


def register():
    bpy.utils.register_class(AddVertexOnClickOperator)

def unregister():
    bpy.utils.unregister_class(AddVertexOnClickOperator)

if __name__ == "__main__":
    register()
    textinfo_="Click On Surfaces To Create Vertices as New Mesh. ESC Or Right Mouse To Complete."
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

    bpy.ops.object.add_vertex_on_click('INVOKE_DEFAULT')