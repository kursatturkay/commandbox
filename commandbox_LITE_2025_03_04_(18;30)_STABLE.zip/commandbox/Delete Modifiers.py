
import bpy


selected_objects = bpy.context.selected_objects


for obj in selected_objects:
    
    if obj.type == 'MESH':
        
        for modifier in obj.modifiers:
            obj.modifiers.remove(modifier)

bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="All modifiers have been removed from the selected meshes.", duration=5)
