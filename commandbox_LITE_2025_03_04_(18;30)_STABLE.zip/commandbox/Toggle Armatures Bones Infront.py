#https://www.youtube.com/watch?v=I6NLiXsX1jY
import bpy

def toggle_armature_show_in_front():
    
    selected_armatures = [obj for obj in bpy.context.selected_objects if obj.type == 'ARMATURE']
    
    if selected_armatures:
        
        has_show_in_front = any(armature.show_in_front for armature in selected_armatures)
        
        
        for armature in selected_armatures:
            armature.show_in_front = not has_show_in_front
    else:
        
        all_armatures = [obj for obj in bpy.data.objects if obj.type == 'ARMATURE']
        
        
        has_show_in_front = any(armature.show_in_front for armature in all_armatures)
        
        
        for armature in all_armatures:
            armature.show_in_front = not has_show_in_front

toggle_armature_show_in_front()
