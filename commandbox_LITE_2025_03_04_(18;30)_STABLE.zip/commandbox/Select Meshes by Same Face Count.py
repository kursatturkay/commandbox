#https://www.youtube.com/watch?v=VN6uwJvfx9A
#Select Meshes by Same Face Count.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_select_same_face_count(bpy.types.Operator):
    """Select objects with the same face count as the selected ones"""
    bl_idname = "object.select_same_face_count"
    bl_label = "Select Same Face Count" 
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.selected_objects and all(obj.type == 'MESH' for obj in context.selected_objects))

    def execute(self, context):
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not selected_meshes:
            self.report({'WARNING'}, "No mesh objects selected.")
            return {'CANCELLED'}

        # Get all unique face counts from selected meshes
        face_counts = {len(obj.data.polygons) for obj in selected_meshes}
        selected_count = 0

        for obj in bpy.context.view_layer.objects:
            if obj.type == 'MESH' and obj not in selected_meshes:
                if len(obj.data.polygons) in face_counts:
                    obj.select_set(True)
                    selected_count += 1
        
        if selected_count > 0:
            self.report({'INFO'}, f"Selected {selected_count} objects with matching face count.")
        else:
            self.report({'WARNING'}, "No objects found with the same face count.")
        
        return {'FINISHED'}


def register():
    bpy.utils.register_class(OBJECT_OT_select_same_face_count)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_select_same_face_count)

if __name__ == "__main__":
    register()
    bpy.ops.object.select_same_face_count()
