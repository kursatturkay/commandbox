#https://www.youtube.com/watch?v=1RE-N7a-MNw
#Creates XPose Animation. Select All Relevant Polygons Before Press. Swipe / Scroll 'XPose Control' after Press to see the effect. Or Move in Timeline

bl_info = {
    "name":
    "XPose",
    "blender": (4, 1, 1),
    "category":
    "Object",
    "location":
    "View3D > Side Bar (Press N) > Fables Alive Games > XPose",
    "version": (2024, 10, 5),
    "author":
    "Fables Alive Games",
    "description":
    "XPoses Selected Objects in the viewport.To see affect Scroll Timeline left / right"
}

import bpy
import math
import mathutils
import webbrowser

original_positions = {}
animation_start_frame = 0
animation_end_frame = 0
xpose_active = False


def calculate_center(objects):
    center = mathutils.Vector((0, 0, 0))
    for obj in objects:
        center += obj.location
    center /= len(objects)
    return center


def expose_view(context, animation_length=100, distance=30.0, rotation=0.0):
    global xpose_active, animation_start_frame, animation_end_frame
    selected_objects = context.selected_objects

    if xpose_active:
        delete_xpose(context)

    frame_start = context.scene.frame_current
    animation_start_frame = frame_start
    frame_end = frame_start + animation_length
    animation_end_frame = frame_end

    center = calculate_center(selected_objects)

    bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')

    for obj in selected_objects:

        #obj.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')
        

        if obj.name not in original_positions:
            original_positions[obj.name] = obj.location.copy()
        obj["xposed"] = True
        obj.keyframe_insert(data_path="location", frame=frame_start)
        obj.keyframe_insert(data_path="rotation_euler", frame=frame_start)

        direction = (obj.location - center).normalized()
        obj.location += direction * distance

        obj.rotation_euler.z += math.radians(rotation)

        obj.keyframe_insert(data_path="location", frame=frame_end)
        obj.keyframe_insert(data_path="rotation_euler", frame=frame_end)

    xpose_active = True

    #context.scene.xpose_control_max = animation_length


def delete_xpose(context):
    global xpose_active, animation_start_frame, animation_end_frame

    context.scene.frame_set(animation_start_frame)

    for obj in bpy.data.objects:
        if obj.get("xposed"):
            if obj.animation_data and obj.animation_data.action:
                fcurves = obj.animation_data.action.fcurves
                for fcurve in fcurves:
                    if fcurve.data_path in {"location", "rotation_euler"}:
                        fcurves.remove(fcurve)
            del obj["xposed"]

    original_positions.clear()
    xpose_active = False


def update_xpose_control(self, context):
    if xpose_active:
        frame = animation_start_frame + self.xpose_control
        context.scene.frame_set(frame)


class OBJECT_OT_expose_view(bpy.types.Operator):
    bl_idname = "object.expose_view"
    bl_label = "Xpose View"
    bl_description = "Creates XPose Animation.\nSelect All Relevant Polygons Before Press.\n\nSwipe / Scroll \"XPose Control\" after Press to see the effect.\nOr Move in Timeline"

    def execute(self, context):
        expose_view(context, context.scene.xpose_animation_length,
                    context.scene.xpose_distance, context.scene.xpose_rotation)
        return {'FINISHED'}


class OBJECT_OT_delete_xpose(bpy.types.Operator):
    bl_idname = "object.delete_xpose"
    bl_label = "Delete XPose"
    bl_description = "Delete XPose Animation"

    def execute(self, context):
        delete_xpose(context)
        return {'FINISHED'}

class OBJECT_PT_toggle_xpose_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_xpose_panel"
    bl_label = "Toggle Sculpt Panel"
    bl_options = {'REGISTER'}

    def execute(self, context):
        context.window_manager.xpose_panel_visible = not context.window_manager.xpose_panel_visible

        if (context.window_manager.xpose_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    

class OBJECT_PT_xpose_panel(bpy.types.Panel):
    bl_idname = "OBJECT_PT_xpose_panel"
    bl_label = "XPose"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "xpose_panel_visible", True)

    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_xpose_panel",
                        text="",
                        icon='CANCEL',
                        emboss=False)
        
    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.use_property_split = True
        layout.use_property_decorate = False  # No animation.
        #box=layout.box()
        #box.alignment ='CENTER'
        
        col = layout.column(align=True)

        col.prop(scene, "xpose_animation_length")
        col.prop(scene, "xpose_distance")
        col.prop(scene, "xpose_rotation")
        
        col.separator(type='SPACE')

        col=layout.column()
        col.scale_y=2.0

        box=col.box()

        col=box.column_flow(columns=2)
        col.operator("object.expose_view")
        col.operator("object.delete_xpose")

        #layout.separator(type='LINE')

        #box=layout.grid_flow(columns=2)
        #box.scale_y=2.0
        row=layout.row(align=True)
        box=row.box()
        #box.alignment='CENTER'
        #laaa=box.label(text="Animate")

        row = box.row(align=True)
        row.alignment = 'CENTER'  # Satır içeriğini ortala
        row.label(text="Animate")

        box.prop(scene, "xpose_control")
        #col=layout.column()
        #col.scale_y=2.0



def register():
    bpy.types.Scene.xpose_animation_length = bpy.props.IntProperty(
        name="Animation Length",
        default=100,
        min=0,
        description="Set Animation Length",
    )
    bpy.types.Scene.xpose_distance = bpy.props.FloatProperty(
        name="Distance",
        default=30,
        min=0.0,
        description="Set XPose Max Distance",
    )
    bpy.types.Scene.xpose_rotation = bpy.props.FloatProperty(
        name="Rotation",
        default=0.0,
        min=0.0,
        soft_max=720.0,
        description=
        "Set XPose Animation Rotation Value \nDuring Animation.\nCan be set more than 720",
    )
    bpy.types.Scene.xpose_control = bpy.props.IntProperty(
        name="XPose Control",
        default=0,
        min=0,
        #soft_max=50,  # Default max value; this will be updated dynamically
        update=update_xpose_control)
    #bpy.types.Scene.xpose_control_max = bpy.props.IntProperty(
    #    name="XPose Control Max",
    #    default=50,
    #    min=0
    #)
    bpy.utils.register_class(OBJECT_OT_expose_view)
    bpy.utils.register_class(OBJECT_OT_delete_xpose)
    bpy.utils.register_class(OBJECT_PT_xpose_panel)
    bpy.utils.register_class(OBJECT_PT_toggle_xpose_panel)

    bpy.types.WindowManager.xpose_panel_visible = bpy.props.BoolProperty(
        default=False)    

def unregister():
    bpy.utils.unregister_class(OBJECT_PT_toggle_xpose_panel)
    bpy.utils.unregister_class(OBJECT_OT_expose_view)
    bpy.utils.unregister_class(OBJECT_OT_delete_xpose)
    bpy.utils.unregister_class(OBJECT_PT_xpose_panel)
    del bpy.types.Scene.xpose_animation_length
    del bpy.types.Scene.xpose_distance
    del bpy.types.Scene.xpose_rotation
    del bpy.types.Scene.xpose_control
    #del bpy.types.Scene.xpose_control_max
    del bpy.types.WindowManager.xpose_panel_visible


if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_xpose_panel()

# def toggle():
    
#     if hasattr(bpy.types, "OBJECT_PT_xpose_panel"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
#         #unregister() throws mRNA error ? couldnt resolve so commented  
#         bpy.utils.unregister_class(bpy.types.OBJECT_PT_xpose_panel)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
#         register()

# # İlk çalıştırma (register yapılacak)
# if __name__ == "__main__":
#     toggle()

