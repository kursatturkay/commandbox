bl_info = {
    "name": "Sphere Sculpt Tool",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (4, 3, 2),
    "category": "Sculpt",
}

import bpy
import bmesh

from bpy.types import Panel
from bpy.types import Operator

from mathutils import Vector, Matrix, Quaternion
from bpy_extras.view3d_utils import region_2d_to_origin_3d, region_2d_to_vector_3d

primitive_items = [
    ('SPHERE', 'UV Sphere', 'Add UV Sphere', 'MESH_UVSPHERE', 0),
    ('CUBE', 'Cube', 'Add Cube', 'MESH_CUBE', 1),
    ('CYLINDER', 'Cylinder', 'Add Cylinder', 'MESH_CYLINDER', 2),
    ('CONE', 'Cone', 'Add Cone', 'MESH_CONE', 3),
    ('TORUS', 'Torus', 'Add Torus', 'MESH_TORUS', 4),
    ('ICOSPHERE', 'Icosphere', 'Add Icosphere', 'MESH_ICOSPHERE', 5),
]

orientation_items = [
    ('VIEW', 'View Aligned', 'Align with view direction', 'VIEW3D', 0),
    ('NORMAL', 'Surface Normal', 'Align with surface normal', 'NORMALS_FACE', 1),
]

class DeleteEmptyMeshesOperator(bpy.types.Operator):
    bl_idname = "object.delete_empty_meshes"
    bl_label = "Delete Empty Meshes"
    bl_description = "Deletes all mesh objects with no vertices, edges, or faces"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        count = 0
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                mesh = obj.data
                if len(mesh.vertices) < 2 or len(mesh.edges) <2 or len(mesh.polygons) <2:
                    bpy.data.objects.remove(obj, do_unlink=True)
                    count += 1

        textinfo_=f"{count} empty mesh objects deleted."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}


class MESH_OT_delete_linked_faces(Operator):
    bl_idname = "mesh.delete_linked_faces"
    bl_label = "Delete Linked Faces"
    bl_description = "Click This Button Then Click On A Face To Delete Connected Faces"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            # Bilgilendirme mesajı
            textinfo_ = "Click on a face to delete all connected faces (islands). Right click or ESC to cancel."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            
            # Timer'ı başlat
            wm = context.window_manager
            self._timer = wm.event_timer_add(0.1, window=context.window)
            
            # Modal handler'ı ekle
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D dışında çalıştırılamaz")
            return {'CANCELLED'}

    def modal(self, context, event):
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            # Get the mouse coordinates and view information
            region = context.region
            rv3d = context.space_data.region_3d
            coord = (event.mouse_region_x, event.mouse_region_y)

            # Get the ray from the viewport to the mouse
            view_vector = region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = region_2d_to_origin_3d(region, rv3d, coord)

            # Perform ray cast
            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = context.scene.ray_cast(
                depsgraph, ray_origin, view_vector)

            if result and obj and obj.type == 'MESH':
                try:
                    # Switch to object mode if necessary
                    if context.active_object and context.active_object.mode != 'OBJECT':
                        bpy.ops.object.mode_set(mode='OBJECT')
                        context.view_layer.update()

                    # Make the hit object active and go to edit mode
                    context.view_layer.objects.active = obj
                    bpy.ops.object.mode_set(mode='EDIT')
                    context.view_layer.update()

                    # Get the BMesh
                    bm = bmesh.from_edit_mesh(obj.data)
                    bm.faces.ensure_lookup_table()

                    # Deselect all faces first
                    for face in bm.faces:
                        face.select = False

                    # Select the hit face and linked faces
                    if 0 <= index < len(bm.faces):
                        # Select the initial face
                        start_face = bm.faces[index]
                        
                        # Create a list to store faces to process
                        faces_to_process = [start_face]
                        processed_faces = set()

                        # Process faces using flood fill
                        while faces_to_process:
                            current_face = faces_to_process.pop()
                            if current_face not in processed_faces:
                                current_face.select = True
                                processed_faces.add(current_face)
                                
                                # Add connected faces through edges
                                for edge in current_face.edges:
                                    for linked_face in edge.link_faces:
                                        if linked_face not in processed_faces:
                                            faces_to_process.append(linked_face)

                        # Update the mesh
                        bmesh.update_edit_mesh(obj.data)
                        
                        # Delete the selected faces
                        bpy.ops.mesh.delete(type='FACE')
                        context.view_layer.update()
                        
                        # Return to object mode
                        bpy.ops.object.mode_set(mode='OBJECT')
                        context.view_layer.update()

                    # Timer'ı temizle
                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None
                    #self.cleanup(context)
                    return {'FINISHED'}

                except Exception as e:
                    self.report({'ERROR'}, f"Operation failed: {str(e)}")
                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None
                    #self.cleanup(context)
                    return {'CANCELLED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            # Timer'ı temizle
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None
            #self.cleanup(context)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}
    
##################################################
class SCULPT_OT_insert_mesh(Operator):
    bl_idname = "sculpt.insert_mesh"
    bl_label = "Insert Mesh"
    bl_description = "Insert A Primitive Mesh. \nClick This Button Than Mouse Down to Target and Drag to Scale."
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    start_mouse: Vector = (0, 0)
    sphere_obj = None
    start_location = None
    target_obj = None
    
    # Scale control properties
    base_scale: float = 0.1
    last_scale: float = 0.1
    sensitivity: float = 0.005
    smooth_factor: float = 0.15
    
    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            textinfo_ = "Now Start Mouse Down On A Mesh Surface And Drag to Insert Mesh."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            
            # Initialize properties
            wm = context.window_manager
            self._timer = wm.event_timer_add(0.1, window=context.window)
            self.start_mouse = Vector((event.mouse_x, event.mouse_y))
            self.sphere_obj = None
            self.start_location = None
            self.target_obj = None
            self.join_geometry = context.scene.join_geometry
            
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D not found")
            return {'CANCELLED'}

    def get_normal_rotation(self, normal):
        rot_quat = normal.to_track_quat('Z', 'Y')
        return rot_quat.to_matrix().to_4x4()

    def get_view_rotation(self, view_vector):
        rot_quat = view_vector.to_track_quat('-Z', 'Y')
        return rot_quat.to_matrix().to_4x4()

    def remove_uv_maps(self, obj):
        active_mode = bpy.context.active_object.mode if bpy.context.active_object else 'OBJECT'
        if active_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.context.view_layer.update()

        bpy.context.view_layer.objects.active = obj
        while obj.data.uv_layers:
            bpy.ops.mesh.uv_texture_remove()

    def duplicate_active_object(self, context, location, view_vector, normal):
        active_obj = context.active_object
        if not active_obj or active_obj.type != 'MESH':
            return None

        new_obj = active_obj.copy()
        new_obj.data = active_obj.data.copy()
        new_obj.animation_data_clear()
        context.scene.collection.objects.link(new_obj)
        
        if context.scene.mesh_orientation == 'VIEW':
            rotation_matrix = self.get_view_rotation(view_vector)
        else:
            rotation_matrix = self.get_normal_rotation(normal)

        new_obj.matrix_world = Matrix.Translation(location) @ rotation_matrix
        return new_obj

    def create_primitive(self, context, location, view_vector, normal):
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        
        if context.scene.insert_active_mesh and context.active_object:
            obj = self.duplicate_active_object(context, location, view_vector, normal)
        else:
            primitive_type = context.scene.primitive_type

            if primitive_type == 'SPHERE':
                bpy.ops.mesh.primitive_uv_sphere_add(radius=0.1, location=location)
            elif primitive_type == 'CUBE':
                bpy.ops.mesh.primitive_cube_add(size=0.2, location=location)
            elif primitive_type == 'CYLINDER':
                bpy.ops.mesh.primitive_cylinder_add(radius=0.1, depth=0.2, location=location)
            elif primitive_type == 'CONE':
                bpy.ops.mesh.primitive_cone_add(radius1=0.1, depth=0.2, location=location)
            elif primitive_type == 'TORUS':
                bpy.ops.mesh.primitive_torus_add(location=location, major_radius=0.1, minor_radius=0.03)
            elif primitive_type == 'ICOSPHERE':
                bpy.ops.mesh.primitive_ico_sphere_add(radius=0.1, location=location)

            obj = context.active_object

        if context.scene.mesh_orientation == 'VIEW':
            rotation_matrix = self.get_view_rotation(view_vector)
        else:
            rotation_matrix = self.get_normal_rotation(normal)

        obj.matrix_world = Matrix.Translation(location) @ rotation_matrix
        self.remove_uv_maps(obj)
        return obj

    def modal(self, context, event):
        bpy.context.preferences.edit.use_global_undo = False
        
        if event.type == 'MOUSEMOVE' and self.sphere_obj:
            current_mouse = Vector((event.mouse_x, event.mouse_y))
            delta = (current_mouse - self.start_mouse).length
            
            target_scale = self.base_scale + (delta * self.sensitivity)
            new_scale = self.last_scale + (target_scale - self.last_scale) * self.smooth_factor
            new_scale = max(0.1, min(3.0, new_scale))
            
            self.sphere_obj.scale = Vector((new_scale, new_scale, new_scale))
            self.last_scale = new_scale
            
            context.view_layer.update()
            bpy.context.preferences.edit.use_global_undo = True
            return {'RUNNING_MODAL'}

        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                region = context.region
                rv3d = context.space_data.region_3d
                coord = (event.mouse_region_x, event.mouse_region_y)

                view_vector = region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = region_2d_to_origin_3d(region, rv3d, coord)

                depsgraph = context.evaluated_depsgraph_get()
                result, location, normal, index, obj, matrix = context.scene.ray_cast(
                    depsgraph, ray_origin, view_vector)

                if result:
                    self.start_mouse = Vector((event.mouse_x, event.mouse_y))
                    self.start_location = location
                    self.target_obj = obj if obj and obj.type == 'MESH' else None

                    try:
                        original_active = context.active_object if context.scene.insert_active_mesh else None
                        
                        self.sphere_obj = self.create_primitive(context, location, view_vector, normal)
                        if self.sphere_obj:
                            name_prefix = "Sculpt Clone" if context.scene.insert_active_mesh else f"Sculpt {context.scene.primitive_type.capitalize()}"
                            self.sphere_obj.name = name_prefix
                            
                            if original_active and not self.join_geometry:
                                bpy.ops.object.select_all(action='DESELECT')
                                original_active.select_set(True)
                                context.view_layer.objects.active = original_active
                            
                    except Exception as e:
                        self.report({'ERROR'}, f"Failed to create primitive: {str(e)}")
                        if self.sphere_obj:
                            bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
                        if self._timer:
                            context.window_manager.event_timer_remove(self._timer)
                            self._timer = None
                        context.view_layer.update()
                        bpy.context.preferences.edit.use_global_undo = True
                        return {'CANCELLED'}
                bpy.context.preferences.edit.use_global_undo = True
                return {'RUNNING_MODAL'}
                
            elif event.value == 'RELEASE':
                if self.sphere_obj:
                    try:
                        if self.sphere_obj and self.target_obj and self.join_geometry:
                            bpy.ops.object.mode_set(mode='OBJECT')
                            context.view_layer.update()
                            context.view_layer.objects.active = self.target_obj
                            self.sphere_obj.select_set(True)
                            self.target_obj.select_set(True)
                            bpy.ops.object.join()
                            context.view_layer.update()

                    except Exception as e:
                        self.report({'ERROR'}, f"Operation failed: {str(e)}")
                        if self.sphere_obj:
                            bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
                        if self._timer:
                            context.window_manager.event_timer_remove(self._timer)    
                            self._timer = None
                        bpy.context.preferences.edit.use_global_undo = True                   
                        return {'CANCELLED'}

                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None
                    bpy.context.preferences.edit.use_global_undo = True
                    return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.sphere_obj:
                bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None
            bpy.context.preferences.edit.use_global_undo = True
            return {'CANCELLED'}
            
        bpy.context.preferences.edit.use_global_undo = True
        return {'RUNNING_MODAL'}
##################################################


class SCULPT_OT_insert_mesh_and_clay_sculpt(Operator):
    bl_idname = "sculpt.insert_mesh_and_clay_sculpt"
    bl_label = "Insert Mesh And Clay Sculpt"
    bl_description = "Insert A Primitive Mesh. \nClick This Button Than Mouse Down to Target and Drag to Scale. \n Automatically Starts Sculpting"
    bl_options = {'REGISTER', 'UNDO'}
    #bl_options = {'REGISTER'}

    
    _timer = None
    start_mouse: Vector = (0, 0)
    sphere_obj = None
    start_location = None
    target_obj = None

    def invoke(self, context, event):
        if context.area.type == 'VIEW_3D':
            # Bilgilendirme mesajı
            textinfo_ = "Now Start Mouse Down On A Mesh Surface And Drag to Insert Mesh. As you mouse up, sculpting will start."
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            
            # Timer'ı başlat
            wm = context.window_manager
            self._timer = wm.event_timer_add(0.1, window=context.window)
            
            # Başlangıç değerlerini ayarla
            self.start_mouse = Vector((event.mouse_x, event.mouse_y))
            self.sphere_obj = None
            self.start_location = None
            self.target_obj = None
            self.join_geometry = context.scene.join_geometry
            
            # Modal handler'ı ekle
            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "View3D dışında çalıştırılamaz")
            return {'CANCELLED'}

    def modal(self, context, event):
        bpy.context.preferences.edit.use_global_undo = False
        if event.type == 'MOUSEMOVE' and self.sphere_obj:
            # Fare hareketi işlemi
            delta = Vector((event.mouse_x, event.mouse_y)) - self.start_mouse
            # scale = max(0.1, abs(delta.x) / 100.0)
            scale = max(0.1, abs(delta.x) / 100.0)

            self.sphere_obj.scale = Vector((scale, scale, scale))
            context.view_layer.update()
            bpy.context.preferences.edit.use_global_undo = True
            return {'RUNNING_MODAL'}

        elif event.type == 'LEFTMOUSE':
            if event.value == 'PRESS':
                # Fare tıklama işlemi
                region = context.region
                rv3d = context.space_data.region_3d
                coord = (event.mouse_region_x, event.mouse_region_y)

                view_vector = region_2d_to_vector_3d(region, rv3d, coord)
                ray_origin = region_2d_to_origin_3d(region, rv3d, coord)

                depsgraph = context.evaluated_depsgraph_get()
                result, location, normal, index, obj, matrix = context.scene.ray_cast(
                    depsgraph, ray_origin, view_vector)

                if result:
                    self.start_location = location
                    self.target_obj = obj if obj and obj.type == 'MESH' else None

                    try:
                        self.sphere_obj = self.create_primitive(context, location, view_vector, normal)
                        if self.sphere_obj:
                            name_prefix = "Sculpt Clone" if context.scene.insert_active_mesh else f"Sculpt {context.scene.primitive_type.capitalize()}"
                            self.sphere_obj.name = name_prefix
                    except Exception as e:
                        self.report({'ERROR'}, f"Failed to create primitive: {str(e)}")
                       
                        if self.sphere_obj:
                            bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
                        if self._timer:
                            context.window_manager.event_timer_remove(self._timer)
                            self._timer = None

                        #self.cleanup(context)
                        context.view_layer.update()
                        bpy.context.preferences.edit.use_global_undo = True
                        return {'CANCELLED'}
                bpy.context.preferences.edit.use_global_undo = True
                return {'RUNNING_MODAL'}
                
            elif event.value == 'RELEASE':
                if self.sphere_obj:
                    try:
                        if self.sphere_obj and self.target_obj and self.join_geometry:
                            bpy.ops.object.mode_set(mode='OBJECT')
                            context.view_layer.update()
                            context.view_layer.objects.active = self.target_obj
                            self.sphere_obj.select_set(True)
                            self.target_obj.select_set(True)
                            bpy.ops.object.join()
                            context.view_layer.update()
                        bpy.ops.object.mode_set(mode='SCULPT')
                        context.view_layer.update()
                        if not context.sculpt_object.use_dynamic_topology_sculpting:
                            bpy.ops.sculpt.dynamic_topology_toggle()

                    except Exception as e:
                        self.report({'ERROR'}, f"Operation failed: {str(e)}")


                        if self.sphere_obj:
                            bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
                        if self._timer:
                            context.window_manager.event_timer_remove(self._timer)    
                            self._timer = None

                        #self.cleanup(context)
                        bpy.context.preferences.edit.use_global_undo = True                   
                        return {'CANCELLED'}

                    # Timer'ı temizle
                   
                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None

                    #self.cleanup(context)
                    bpy.context.preferences.edit.use_global_undo = True
                    return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            # İşlemi iptal et
            if self.sphere_obj:
                bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None

            #self.cleanup(context)
            bpy.context.preferences.edit.use_global_undo = True
            return {'CANCELLED'}
        bpy.context.preferences.edit.use_global_undo = True
        return {'RUNNING_MODAL'}

    # create_primitive, get_normal_rotation, get_view_rotation ve remove_uv_maps 
    # metodları aynı kalacak şekilde buraya eklenecek...

    def get_normal_rotation(self, normal):
        """Calculate rotation matrix to align Z axis with surface normal"""
        rot_quat = normal.to_track_quat('Z', 'Y')
        return rot_quat.to_matrix().to_4x4()

    def get_view_rotation(self, view_vector):
        """Calculate rotation matrix to align with view direction"""
        rot_quat = view_vector.to_track_quat('-Z', 'Y')
        return rot_quat.to_matrix().to_4x4()

    def remove_uv_maps(self, obj):
        """Remove all UV maps from the given object"""
        active_mode = bpy.context.active_object.mode if bpy.context.active_object else 'OBJECT'
        if active_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.context.view_layer.update()

        bpy.context.view_layer.objects.active = obj

        while obj.data.uv_layers:
            bpy.ops.mesh.uv_texture_remove()

    def duplicate_active_object(self, context, location, view_vector, normal):
        """Duplicate the active object and place it at the given location"""
        active_obj = context.active_object
        if not active_obj or active_obj.type != 'MESH':
            return None

        # Create a duplicate of the active object
        new_obj = active_obj.copy()
        new_obj.data = active_obj.data.copy()
        new_obj.animation_data_clear()
        context.scene.collection.objects.link(new_obj)
        
        # Apply rotation based on selected orientation
        if context.scene.mesh_orientation == 'VIEW':
            rotation_matrix = self.get_view_rotation(view_vector)
        else:  # NORMAL
            rotation_matrix = self.get_normal_rotation(normal)

        new_obj.matrix_world = Matrix.Translation(location) @ rotation_matrix
        
        return new_obj

    def create_primitive(self, context, location, view_vector, normal):
        if bpy.context.object and bpy.context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        """Create a new primitive mesh at the given location with proper orientation"""
        if context.scene.insert_active_mesh and context.active_object:
            obj=self.duplicate_active_object(context, location, view_vector, normal)

        else:
            primitive_type = context.scene.primitive_type

            if primitive_type == 'SPHERE':
                bpy.ops.mesh.primitive_uv_sphere_add(radius=0.1, location=location)
            elif primitive_type == 'CUBE':
                bpy.ops.mesh.primitive_cube_add(size=0.2, location=location)
            elif primitive_type == 'CYLINDER':
                bpy.ops.mesh.primitive_cylinder_add(radius=0.1, depth=0.2, location=location)
            elif primitive_type == 'CONE':
                bpy.ops.mesh.primitive_cone_add(radius1=0.1, depth=0.2, location=location)
            elif primitive_type == 'TORUS':
                bpy.ops.mesh.primitive_torus_add(location=location, major_radius=0.1, minor_radius=0.03)
            elif primitive_type == 'ICOSPHERE':
                bpy.ops.mesh.primitive_ico_sphere_add(radius=0.1, location=location)

            obj = context.active_object

        # Apply rotation based on selected orientation
        if context.scene.mesh_orientation == 'VIEW':
            rotation_matrix = self.get_view_rotation(view_vector)
        else:  # NORMAL
            rotation_matrix = self.get_normal_rotation(normal)

        obj.matrix_world = Matrix.Translation(location) @ rotation_matrix

        # Remove UV maps from the newly created primitive
        self.remove_uv_maps(obj)
        return obj

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE' and self.sphere_obj:
            delta = Vector((event.mouse_x, event.mouse_y)) - self.start_mouse
            # scale = max(0.1, abs(delta.x) / 100.0)
            scale = max(0.1, abs(delta.x) / 100.0)

            self.sphere_obj.scale = Vector((scale, scale, scale))
            context.view_layer.update()

        elif event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            region = context.region
            rv3d = context.space_data.region_3d
            coord = (event.mouse_region_x, event.mouse_region_y)

            view_vector = region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = region_2d_to_origin_3d(region, rv3d, coord)

            depsgraph = context.evaluated_depsgraph_get()
            result, location, normal, index, obj, matrix = context.scene.ray_cast(
                depsgraph, ray_origin, view_vector)

            if result:
                self.start_location = location
                self.target_obj = obj if obj and obj.type == 'MESH' else None

                # Create the new primitive or duplicate active object
                self.sphere_obj = self.create_primitive(context, location, view_vector, normal)
                if self.sphere_obj:
                    name_prefix = "Sculpt Clone" if context.scene.insert_active_mesh else f"Sculpt {context.scene.primitive_type.capitalize()}"
                    self.sphere_obj.name = name_prefix

        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            if self.sphere_obj:
                if self.sphere_obj and self.target_obj and self.join_geometry:
                    context.view_layer.objects.active = self.target_obj
                    bpy.ops.object.mode_set(mode='OBJECT')
                    context.view_layer.update()
                    self.sphere_obj.select_set(True)
                    self.target_obj.select_set(True)

                    bpy.ops.object.join()
                    context.view_layer.update()

                    while self.target_obj.data.uv_layers:
                        bpy.ops.mesh.uv_texture_remove()

                bpy.ops.object.mode_set(mode='SCULPT')
                context.view_layer.update()
                bpy.ops.sculpt.dynamic_topology_toggle()

                bpy.ops.brush.asset_activate(
                    asset_library_type='ESSENTIALS',
                    asset_library_identifier="",
                    relative_asset_identifier="brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\Elastic Snake Hook"
                )


            # if self.sphere_obj:
            #     bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None        
            
            #self.cleanup(context)
            context.view_layer.update()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.sphere_obj:
                bpy.data.objects.remove(self.sphere_obj, do_unlink=True)
            if self._timer:
                context.window_manager.event_timer_remove(self._timer)
                self._timer = None
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

class SCULPT_OT_toggle_panel(Operator):
    bl_idname = "sculpt.toggle_sculpt_ot_panel"
    bl_label = "Toggle Sculpt Panel"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.window_manager.sculpt_panel_visible = not context.window_manager.sculpt_panel_visible

        if (context.window_manager.sculpt_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}

class SCULPT_PT_sculpt_panel(Panel):
    bl_label = "Insert Mesh And Clay Sculpt "
    bl_idname = "SCULPT_PT_sculpt_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "sculpt_panel_visible", True)

    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("sculpt.toggle_sculpt_ot_panel",
                        text="",
                        icon='CANCEL',
                        emboss=False)

    def draw(self, context):
        layout = self.layout
        box = layout.box()

        box = box.column()
        # Insert active mesh checkbox
        box.prop(context.scene, "insert_active_mesh", text="Insert Active Mesh")

        # Primitive type and insert button (only show if insert_active_mesh is False)
        if not context.scene.insert_active_mesh:
            row = box.row(align=True)
            row.prop(context.scene, "primitive_type", text="")
            icon = next(item[3] for item in primitive_items
                        if item[0] == context.scene.primitive_type)
        else:
            icon = 'OUTLINER_OB_MESH'

        # Orientation option
        box.prop(context.scene, "mesh_orientation", text="")

        # Join geometry option
        box.prop(context.scene, "join_geometry", text="Join Geometry")

        box.operator("sculpt.insert_mesh", text=SCULPT_OT_insert_mesh.bl_label, icon=icon)
        box.operator("sculpt.insert_mesh_and_clay_sculpt", text=SCULPT_OT_insert_mesh_and_clay_sculpt.bl_label, icon=icon)
        box.operator("mesh.delete_linked_faces", text="Delete Linked Faces", icon='X')
        box.operator("object.delete_empty_meshes", text="Delete Empty Meshes", icon='DRIVER_TRANSFORM')
        sep = layout.separator(type="LINE")

        col = layout.column()
        #row = layout.row(align=True)
        col.label(text="F : Brush Size", icon="INFO")
        #row = layout.row(align=True)
        col.label(text="R : Details Size", icon="INFO")
        #row = layout.row(align=True)
        col.label(text="Ctrl+R : Remesh", icon="INFO")
        col.label(text="Numpad + : Insert Mesh", icon="INFO")
        col.label(text="Ctrl Shift Numpad + : Insert Mesh and Sculpt", icon="INFO")
        col.label(text="Alt+Q : Switch Sculpting Mesh", icon="INFO")
        #row = layout.row(align=True)
        col.label(text="Alt+Click : Switch Sculpting Mesh", icon="INFO" )
        col.label(text="        ( if Edit > Lock Object is Modes OFF )",)

def register():
    bpy.utils.register_class(SCULPT_OT_insert_mesh_and_clay_sculpt)
    bpy.utils.register_class(SCULPT_OT_insert_mesh)
    bpy.utils.register_class(DeleteEmptyMeshesOperator)
    bpy.utils.register_class(MESH_OT_delete_linked_faces)
    bpy.utils.register_class(SCULPT_OT_toggle_panel)
    bpy.utils.register_class(SCULPT_PT_sculpt_panel)

    bpy.types.WindowManager.sculpt_panel_visible = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.join_geometry = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.insert_active_mesh = bpy.props.BoolProperty(
        name="Insert Active Mesh",
        description="Insert a copy of the active mesh instead of creating a primitive",
        default=False
    )
    bpy.types.Scene.primitive_type = bpy.props.EnumProperty(
        items=primitive_items,
        name="Primitive Type",
        description="Select primitive type to add",
        default='SPHERE')
    bpy.types.Scene.mesh_orientation = bpy.props.EnumProperty(
        items=orientation_items,
        name="Mesh Orientation",
        description="Choose how to orient the inserted mesh",
        default='NORMAL')

    kc = bpy.context.window_manager.keyconfigs.addon.keymaps.new(
        name="3D View", space_type='VIEW_3D')

    global km1, km2

    km1 = kc.keymap_items.new("sculpt.insert_mesh",
                             type='NUMPAD_PLUS',
                             value='PRESS',
                             ctrl=False,
                             shift=False)
    
    km2 = kc.keymap_items.new("sculpt.insert_mesh_and_clay_sculpt",
                             type='NUMPAD_PLUS',
                             value='PRESS',
                             ctrl=True,
                             shift=True)

def unregister():
    global km1, km2
    bpy.context.window_manager.keyconfigs.addon.keymaps.remove(km1)
    bpy.context.window_manager.keyconfigs.addon.keymaps.remove(km2)
    bpy.utils.unregister_class(DeleteEmptyMeshesOperator)
    bpy.utils.unregister_class(SCULPT_OT_insert_mesh_and_clay_sculpt)
    bpy.utils.unregister_class(SCULPT_OT_insert_mesh)
    bpy.utils.unregister_class(SCULPT_OT_toggle_panel)
    bpy.utils.unregister_class(SCULPT_PT_sculpt_panel)
    bpy.utils.unregister_class(MESH_OT_delete_linked_faces)
    del bpy.types.WindowManager.sculpt_panel_visible
    del bpy.types.Scene.join_geometry
    del bpy.types.Scene.insert_active_mesh
    del bpy.types.Scene.primitive_type
    del bpy.types.Scene.mesh_orientation

if __name__ == "__main__":
    register()
    bpy.ops.sculpt.toggle_sculpt_ot_panel()