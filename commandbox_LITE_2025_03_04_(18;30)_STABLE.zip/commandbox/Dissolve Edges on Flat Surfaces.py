#https://www.youtube.com/watch?v=k8a5kEOMO80
#Dissolve Edges on Flat Surfaces.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
from mathutils import Vector
import math

class SelectFlatEdgesOperator(bpy.types.Operator):
    """Select and dissolve edges on flat surfaces for all selected mesh objects"""
    bl_idname = "mesh.dissolve_flat_edges_multiple"
    bl_label = "Dissolve Flat Edges on All Selected Objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    angle_threshold: bpy.props.FloatProperty(
        name="Angle Threshold",
        description="Edges flatter than this angle will be selected and dissolved (degrees)",
        default=5.0,
        min=0.0,
        max=180.0
    )
    
    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        if not selected_objects:
            self.report({'ERROR'}, "Please select at least one mesh object")
            return {'CANCELLED'}
        
        original_active = context.active_object
        
        angle_threshold_rad = math.radians(self.angle_threshold)
        
        for obj in selected_objects:
            context.view_layer.objects.active = obj
            
            if context.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')
            
            me = obj.data
            bm = bmesh.new()
            bm.from_mesh(me)
            bm.edges.ensure_lookup_table()
            
            for edge in bm.edges:
                faces = edge.link_faces
                
                if len(faces) == 2:
                    
                    angle = faces[0].normal.angle(faces[1].normal)
                    
                    if angle < angle_threshold_rad:
                        edge.select = True
            
            bm.to_mesh(me)
            bm.free()
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.dissolve_edges()
            
            bpy.ops.object.mode_set(mode='OBJECT')
        
        if original_active:
            context.view_layer.objects.active = original_active
        
        if original_active and original_active.mode == 'EDIT':
            bpy.ops.object.mode_set(mode='EDIT')
            
        return {'FINISHED'}

def register():
    bpy.utils.register_class(SelectFlatEdgesOperator)

def unregister():
    bpy.utils.unregister_class(SelectFlatEdgesOperator)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.dissolve_flat_edges_multiple()