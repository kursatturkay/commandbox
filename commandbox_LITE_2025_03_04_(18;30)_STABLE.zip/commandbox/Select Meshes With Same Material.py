import bpy

active_obj = bpy.context.object

if active_obj and active_obj.type == 'MESH':      
    active_materials = set(active_obj.data.materials)
    bpy.ops.object.select_all(action='DESELECT')

    for obj in bpy.data.objects:
        if obj.type == 'MESH':  
            if set(obj.data.materials) & active_materials:  
                obj.select_set(True)  

    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text=f"'Objects Selected with same material as {active_obj.name}' ", duration=5)
else:
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Select A Mesh!", duration=5)
