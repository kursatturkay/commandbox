#https://www.youtube.com/watch?v=6IPjyIB7xpg
#Create & Assign Double Sided Material.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

# Operator for toggling panel visibility
class ToggleDoubleSidedMaterialPanel(bpy.types.Operator):
    """Toggle the visibility of the Scene Manager Panel"""
    bl_idname = "scene.toggle_double_sided_material_panel"
    bl_label = "Toggle Scene Manager Panel"

    def execute(self, context):
        context.scene.show_double_sided_material = not context.scene.show_double_sided_material

        if(context.scene.show_double_sided_material):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class DoubleSidedMaterialPanel(bpy.types.Panel):
    bl_label = "Create & Assign Double Sided Material"
    bl_idname = "OBJECT_PT_double_sided_material"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    @classmethod
    def poll(cls, context):
        
        return context.scene.show_double_sided_material

    def draw_header_preset(self,context):
        layout = self.layout
        layout.operator("scene.toggle_double_sided_material_panel", text="", icon ='CANCEL',emboss = False)

    def draw(self, context):
        layout = self.layout
        mat_settings = context.scene.double_sided_material_settings
        
        layout.prop(mat_settings, "color_front")
        layout.prop(mat_settings, "color_back")
        layout.operator("object.create_double_sided_material")

class DoubleSidedMaterialProperties(bpy.types.PropertyGroup):
    color_front: bpy.props.FloatVectorProperty(
        name="Front Color", subtype='COLOR', size=4, default=(0.12289, 0.484627, 1, 1), min=0, max=1)
    color_back: bpy.props.FloatVectorProperty(
        name="Back Color", subtype='COLOR', size=4, default=(1, 0.153803, 0.12289, 1), min=0, max=1)

class CreateDoubleSidedMaterial(bpy.types.Operator):
    bl_idname = "object.create_double_sided_material"
    bl_label = "Create/Update Double Sided Material"
    
    def execute(self, context):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            self.report({'WARNING'}, "Select a mesh object")
            return {'CANCELLED'}
        
        mat = None
        for slot in obj.material_slots:
            if slot.material and slot.material.name.startswith("DoubleSidedMaterial"):
                mat = slot.material
                break
        
        if mat is None:
            mat = bpy.data.materials.new(name="DoubleSidedMaterial")
            obj.data.materials.append(mat)
            mat.use_nodes = True
        
        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        if "Mix Shader" not in nodes:
            nodes.clear()
            
            output = nodes.new(type='ShaderNodeOutputMaterial')
            output.location = (400, 0)
            
            mix_shader = nodes.new(type='ShaderNodeMixShader')
            mix_shader.location = (200, 0)
            
            front_shader = nodes.new(type='ShaderNodeBsdfDiffuse')
            front_shader.location = (0, 100)
            back_shader = nodes.new(type='ShaderNodeBsdfDiffuse')
            back_shader.location = (0, -100)
            
            geom = nodes.new(type='ShaderNodeNewGeometry')
            geom.location = (-200, 0)
            
            links.new(geom.outputs['Backfacing'], mix_shader.inputs[0])
            links.new(front_shader.outputs['BSDF'], mix_shader.inputs[1])
            links.new(back_shader.outputs['BSDF'], mix_shader.inputs[2])
            links.new(mix_shader.outputs['Shader'], output.inputs['Surface'])
        else:
            front_shader = nodes.get("Diffuse BSDF")
            back_shader = nodes.get("Diffuse BSDF.001")
        
        settings = context.scene.double_sided_material_settings
        if front_shader and back_shader:
            front_shader.inputs['Color'].default_value = settings.color_front
            back_shader.inputs['Color'].default_value = settings.color_back
        
        bpy.context.space_data.shading.type = 'MATERIAL'
        return {'FINISHED'}

classes = [
    DoubleSidedMaterialPanel,
    DoubleSidedMaterialProperties,
    CreateDoubleSidedMaterial,
    ToggleDoubleSidedMaterialPanel
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.double_sided_material_settings = bpy.props.PointerProperty(type=DoubleSidedMaterialProperties)
    
    bpy.types.Scene.show_double_sided_material = bpy.props.BoolProperty(
        default=False
    )
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.double_sided_material_settings
    del bpy.types.Scene.show_double_sided_material

if __name__ == "__main__":
    register()
    bpy.ops.scene.toggle_double_sided_material_panel()