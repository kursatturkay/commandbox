#https://www.youtube.com/watch?v=dh7hnsGiICs
#Cancel animation, expand frame range to 5000, and reset to start frame and start play
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy

class ANIM_OT_reset_expand_play_zoom_animation_5000(bpy.types.Operator):
    """Cancel animation, expand frame range to 5000, reset to start frame, play, and zoom out dopesheet"""
    bl_idname = "anim.reset_expand_play_zoom_animation_5000"
    bl_label = "Reset Expand Play & Zoom Animation to 5000"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.screen.animation_cancel()
        context.scene.frame_end = 5000
        context.scene.frame_set(context.scene.frame_start)
        bpy.ops.screen.animation_play()

        # ✅ Dopesheet Zoom Out (View All)
        dopesheet_found = False
        for window in context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                if area.type == 'DOPESHEET_EDITOR':  # Dopesheet bölmesini bul
                    for region in area.regions:
                        if region.type == 'WINDOW':  # Doğru region'ı bul
                            _ovr = {
                                "window": window,
                                "area": area,
                                "region": region
                            }
                            try:
                                if bpy.app.version < (3, 2):
                                    bpy.ops.action.view_all(_ovr)  # Eski yöntem
                                else:
                                    with context.temp_override(**_ovr):  # Yeni yöntem
                                        bpy.ops.action.view_all()
                                dopesheet_found = True
                            except RuntimeError as e:
                                print(f"Hata: {e}")

        if not dopesheet_found:
            self.report({'WARNING'}, "Dopesheet açık değil, zoom işlemi atlandı.")

        return {'FINISHED'}

def register():
    bpy.utils.register_class(ANIM_OT_reset_expand_play_zoom_animation_5000)

def unregister():
    bpy.utils.unregister_class(ANIM_OT_reset_expand_play_zoom_animation_5000)

if __name__ == "__main__":
    register()
    bpy.ops.anim.reset_expand_play_zoom_animation_5000()
