# Toggle Curves Visiblity
import bpy

curves = [obj for obj in bpy.context.scene.objects if obj.type == 'CURVE']

if curves:  
    
    first_curve_visible = curves[0].hide_get()

    
    for obj in curves:
        obj.hide_set(not first_curve_visible)
