# https://www.youtube.com/watch?v=ixyebNEiF8Q&t=38s
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Select Overlapping Vertices And Merge.

import bpy
import bmesh
import mathutils

def select_and_merge_overlapping_vertices(threshold=0.0001):
    
    obj = bpy.context.active_object
    if obj is None or obj.type != 'MESH':
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Please select a mesh object.", duration=5)
        return

    
    if obj.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    mesh = bmesh.from_edit_mesh(obj.data)

    
    initial_vertex_count = len(mesh.verts)

    
    kd = mathutils.kdtree.KDTree(len(mesh.verts))
    for i, vert in enumerate(mesh.verts):
        if not vert.hide:  
            kd.insert(vert.co, i)
    kd.balance()

    
    merge_indices = set()
    for vert in mesh.verts:
        if vert.index in merge_indices or vert.hide:
            continue
        duplicates = kd.find_range(vert.co, threshold)
        if len(duplicates) > 1:  
            for co, index, dist in duplicates:
                merge_indices.add(index)

    
    for vert in mesh.verts:
        vert.select = vert.index in merge_indices

    
    bpy.ops.mesh.remove_doubles(threshold=threshold)

    
    mesh = bmesh.from_edit_mesh(obj.data)
    final_vertex_count = len(mesh.verts)

    
    removed_count = initial_vertex_count - final_vertex_count
    
    comment_=f"{removed_count} overlapped vertex merged and selected."
    bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=comment_, duration=5)

select_and_merge_overlapping_vertices(threshold=0.001)
