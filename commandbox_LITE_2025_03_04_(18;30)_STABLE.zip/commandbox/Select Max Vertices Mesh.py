#Select Max Vertices Mesh
import bpy

class MESH_OT_SelectMaxVertices(bpy.types.Operator):
    bl_idname = "mesh.select_max_vertices"
    bl_label = "Select Mesh with Most Vertices"
    bl_description = "Selects the mesh object with the highest vertex count and displays its vertex and face count"
    
    def execute(self, context):
        max_vertices = 0
        max_obj = None
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                obj.data.update()
                vertex_count = len(obj.data.vertices)
                
                if vertex_count > max_vertices:
                    max_vertices = vertex_count
                    max_obj = obj
        
        if max_obj:
            max_obj.select_set(True)
            bpy.context.view_layer.objects.active = max_obj
            max_obj.show_in_front = True

            
            face_count = len(max_obj.data.polygons)

            
            textinfo_= f"Selected: {max_obj.name} | Vertices: {max_vertices}, Faces: {face_count}"
            bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
            
            
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    for region in area.regions:
                        if region.type == 'WINDOW':
                            with bpy.context.temp_override(area=area, region=region):
                                bpy.ops.view3d.view_selected(use_all_regions=False)
                            break

        return {'FINISHED'}


def register():
    bpy.utils.register_class(MESH_OT_SelectMaxVertices)

def unregister():
    bpy.utils.unregister_class(MESH_OT_SelectMaxVertices)


if __name__ == "__main__":
    register()
    bpy.ops.mesh.select_max_vertices()
