
import bpy


if bpy.context.selected_objects:
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            obj.show_in_front = False

else:
    for obj in bpy.data.objects:
        if obj.type == 'MESH':
            obj.show_in_front = False
