import bpy


tolerance = 1e-6


for obj in bpy.context.scene.objects:
    
    if obj.type == 'MESH':
        
        if abs(obj.rotation_euler.x) > tolerance or abs(obj.rotation_euler.y) > tolerance or abs(obj.rotation_euler.z) > tolerance:
            obj.select_set(True)
        else:
            obj.select_set(False)
