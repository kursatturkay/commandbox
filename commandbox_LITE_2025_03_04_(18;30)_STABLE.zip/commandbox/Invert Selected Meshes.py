#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Invert Selected Meshes.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy

class OBJECT_OT_invert_selected_meshes(bpy.types.Operator):
    """Invert Selected Meshes and Show Notification"""
    bl_idname = "object.invert_selected_meshes"
    bl_label = "Invert Selected Meshes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        all_mesh_objects = {obj for obj in context.scene.objects if obj.type == 'MESH'}
        
        
        selected_objects = set(context.selected_objects)

        
        deselected_count = len(selected_objects)
        newly_selected_count = len(all_mesh_objects - selected_objects)

        
        bpy.ops.object.select_all(action='DESELECT')

        
        for obj in all_mesh_objects - selected_objects:
            obj.select_set(True)

        
        textinfo_ = f"Selected: {newly_selected_count}, Deselected: {deselected_count}"

        
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

        return {'FINISHED'}



def register():
    bpy.utils.register_class(OBJECT_OT_invert_selected_meshes)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_invert_selected_meshes)

if __name__ == "__main__":
    register()
    bpy.ops.object.invert_selected_meshes()
