import bpy
import bmesh

def select_shortest_connected_edge():
    obj = bpy.context.object
    if obj is None or obj.type != 'MESH':
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="Select a Mesh.", duration=5)
        return
    
    if obj.mode != 'EDIT':
        bpy.ops.object.mode_set(mode='EDIT')
    
    bpy.ops.object.mode_set(mode='OBJECT')
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    
    selected_edges = [edge for edge in bm.edges if edge.select]
    if not selected_edges:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text="No Edges Selected.", duration=5)
        bm.free()
        return
    
    for edge in selected_edges:
        connected_edges = list(edge.verts[0].link_edges) + list(edge.verts[1].link_edges)
        connected_edges = [e for e in connected_edges if e != edge]  
        
        if not connected_edges:
            continue
        
        shortest_edge = min(connected_edges, key=lambda e: e.calc_length())
        shortest_edge.select = True   
    
    bm.to_mesh(obj.data)
    bm.free()
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.merge(type='CENTER')
    bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text={'INFO'}, "Edges merged to center", duration=5) 

# Blender’da kodun tekrar çağrılabilir olmasını sağlayan yapı
def register():
    bpy.utils.register_class(select_shortest_connected_edge)

def unregister():
    bpy.utils.unregister_class(select_shortest_connected_edge)

# Shift+R ile çalıştırılabilir olması için
if __name__ == "__main__":
    select_shortest_connected_edge()
