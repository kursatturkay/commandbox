# https://www.youtube.com/watch?v=RxjwS8TlJlc
#Pivot To Extreme Panel.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh


class OBJECT_PT_PivotToExtremePanel (bpy.types.Panel):
    bl_label = "Pivot Point Setter"
    bl_idname = "OBJECT_PT_PivotToExtremePanel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Command Box'

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)

        # X ekseni için Min ve Max butonları
        col.label(text="X Axis:")
        row = col.row(align=True)
        
        # X ekseninin min ve max butonları
        op = row.operator("object.set_pivot", text="Min")
        op.axis = "x"
        op.direction = "min"
        
        op = row.operator("object.set_pivot", text="Max")
        op.axis = "x"
        op.direction = "max"

        # Y ekseni için Min ve Max butonları
        col.label(text="Y Axis:")
        row = col.row(align=True)
        
        # Y ekseninin min ve max butonları
        op = row.operator("object.set_pivot", text="Min")
        op.axis = "y"
        op.direction = "min"
        
        op = row.operator("object.set_pivot", text="Max")
        op.axis = "y"
        op.direction = "max"

        # Z ekseni için Min ve Max butonları
        col.label(text="Z Axis:")
        row = col.row(align=True)
        
        # Z ekseninin min ve max butonları
        op = row.operator("object.set_pivot", text="Min")
        op.axis = "z"
        op.direction = "min"
        
        op = row.operator("object.set_pivot", text="Max")
        op.axis = "z"
        op.direction = "max"


class SetPivotOperator(bpy.types.Operator):
    bl_idname = "object.set_pivot"
    bl_label = "Set Pivot"
    
    axis: bpy.props.StringProperty()
    direction: bpy.props.StringProperty()

    def execute(self, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            # Vertex verisini al
            mesh = obj.data
            bm = bmesh.new()
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()

            # Vertex'lerin dünya uzayındaki koordinatları
            world_coords = [obj.matrix_world @ v.co for v in bm.verts]
            
            # Axis ve Direction parametrelerine göre min/max hesapla
            if self.axis == "x":
                axis_index = 0
            elif self.axis == "y":
                axis_index = 1
            elif self.axis == "z":
                axis_index = 2
            else:
                self.report({'ERROR'}, "Invalid axis")
                return {'CANCELLED'}

            if self.direction == "min":
                pivot = min(world_coords, key=lambda v: v[axis_index])
            elif self.direction == "max":
                pivot = max(world_coords, key=lambda v: v[axis_index])
            else:
                self.report({'ERROR'}, "Invalid direction")
                return {'CANCELLED'}

            # Pivot noktasını ayarla
            self.set_pivot(obj, pivot)
            return {'FINISHED'}

        return {'CANCELLED'}

    def set_pivot(self, obj, target_coord):
        # Nesneyi aktif yap
        bpy.context.view_layer.objects.active = obj
        
        # Orijini geometrinin ortasına sıfırla
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        
        # Edit mode'a geç
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()

        # Vertex'lerin dünya uzayındaki koordinatları
        world_coords = [obj.matrix_world @ v.co for v in bm.verts]

        # Pivotu belirle
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Pivot noktasını belirlemek için dünyadaki koordinatları kullan
        cursor_location = obj.location.copy()
        setattr(cursor_location, self.axis, getattr(target_coord, self.axis))
        bpy.context.scene.cursor.location = cursor_location
        
        # Pivot noktası olarak 3D Cursor'u kullanarak orijini ayarla
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR')


def register():
    bpy.utils.register_class(OBJECT_PT_PivotToExtremePanel)
    bpy.utils.register_class(SetPivotOperator)


def unregister():
    bpy.utils.unregister_class(OBJECT_PT_PivotToExtremePanel)
    bpy.utils.unregister_class(SetPivotOperator)


# if __name__ == "__main__":
#     register()

def toggle():
    
    if hasattr(bpy.types, "OBJECT_PT_PivotToExtremePanel"):
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
        #unregister() throws mRNA error ? couldnt resolve so commented
        #unregister()
        bpy.utils.unregister_class(bpy.types.OBJECT_PT_PivotToExtremePanel)
        
        #bpy.utils.unregister_class(SetPivotOperator)
        

    
    else:
        bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
        register()

# İlk çalıştırma (register yapılacak)
if __name__ == "__main__":
    toggle()
