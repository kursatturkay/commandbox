#https://www.youtube.com/watch?v=GQtJJ8kKAGg
#Adjusts the 3D Viewport's clipping planes in Blender based on the nearest and farthest visible objects within the camera's view direction.
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)

import bpy
import mathutils
from bpy.types import Operator
from bpy.props import FloatProperty

class CAMERA_OT_adjust_clipping(Operator):
    """Adjust camera and viewport clipping based on visible objects"""
    bl_idname = "camera.adjust_clipping"
    bl_label = "Adjust Camera Clipping"
    bl_options = {'REGISTER', 'UNDO'}
    
    min_factor: FloatProperty(
        name="Min Distance Factor",
        description="Factor to multiply minimum distance",
        default=0.1,
        min=0.001,
        max=1.0
    )
    
    max_factor: FloatProperty(
        name="Max Distance Factor",
        description="Factor to multiply maximum distance",
        default=2.0,
        min=1.0,
        max=10.0
    )
    
    def execute(self, context):
        # Get all objects in the scene
        objects = context.scene.objects
        
        # Get active camera
        scene = context.scene
        camera = scene.camera
        
        if not camera:
            self.report({'ERROR'}, "No active camera in the scene")
            return {'CANCELLED'}
        
        # Find current 3D Viewport
        space = context.space_data
        if space.type != 'VIEW_3D':
            self.report({'ERROR'}, "Must be executed in a 3D Viewport")
            return {'CANCELLED'}
        
        region_3d = space.region_3d
        
        # Get camera's position and direction
        camera_matrix_world = camera.matrix_world
        camera_position = camera_matrix_world.translation
        camera_direction = camera_matrix_world.to_quaternion() @ mathutils.Vector((0.0, 0.0, -1.0))
        
        # Initialize nearest and farthest distances
        min_distance = float('inf')
        max_distance = -float('inf')
        
        # Check all objects
        for obj in objects:
            if obj.visible_get() and obj != camera:  # Only visible objects, exclude camera itself
                # Get object bounds
                if obj.type == 'MESH':
                    # For mesh objects, check all vertices
                    world_matrix = obj.matrix_world
                    for vertex in obj.data.vertices:
                        vertex_world = world_matrix @ vertex.co
                        
                        # Calculate distance from camera to vertex
                        direction_to_vertex = (vertex_world - camera_position)
                        distance = direction_to_vertex.length
                        
                        # Is it in camera's direction?
                        direction_normalized = direction_to_vertex.normalized()
                        dot_product = camera_direction.dot(direction_normalized)
                        
                        if dot_product > 0:  # Only consider objects in the field of view
                            min_distance = min(min_distance, distance)
                            max_distance = max(max_distance, distance)
                else:
                    # For non-mesh objects, use object location
                    obj_location = obj.location
                    direction_to_obj = (obj_location - camera_position)
                    distance = direction_to_obj.length
                    
                    # Is it in camera's direction?
                    direction_normalized = direction_to_obj.normalized()
                    dot_product = camera_direction.dot(direction_normalized)
                    
                    if dot_product > 0:  # Only consider objects in the field of view
                        min_distance = min(min_distance, distance)
                        max_distance = max(max_distance, distance)
        
        # Set Clip Start and Clip End values for viewport
        if min_distance < float('inf'):  # If an object was found
            space.clip_start = min_distance * self.min_factor
        if max_distance > -float('inf'):
            space.clip_end = max_distance * self.max_factor
        
        # Also set camera clipping values
        if camera and min_distance < float('inf') and max_distance > -float('inf'):
            camera.data.clip_start = min_distance * self.min_factor
            camera.data.clip_end = max_distance * self.max_factor
        
        textinfo_ = f"Updated Camera: Clip Start = {camera.data.clip_start:.4f}, Clip End = {camera.data.clip_end:.4f}\n"
        textinfo_ += f"Updated View: Clip Start = {space.clip_start:.4f}, Clip End = {space.clip_end:.4f}"
        
        # Display the information in the viewport
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT',
                                           text=textinfo_,
                                           duration=5)
        
        return {'FINISHED'}

def register():
    bpy.utils.register_class(CAMERA_OT_adjust_clipping)

def unregister():
    bpy.utils.unregister_class(CAMERA_OT_adjust_clipping)

if __name__ == "__main__":
    register()
    bpy.ops.camera.adjust_clipping()