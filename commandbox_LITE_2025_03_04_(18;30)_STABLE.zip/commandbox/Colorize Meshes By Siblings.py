#https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Colorize Meshes By Siblings.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import random

import bpy
import random

class OBJECT_OT_ColorizeBySiblings(bpy.types.Operator):
    """Seçili objeleri parentlarına göre renklendirir ve seçili objelerin çocuklarını da dahil eder"""
    bl_idname = "object.colorize_by_siblings"
    bl_label = "Colorize Meshes By Siblings"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        all_mesh_objects = [obj for obj in context.scene.objects if obj.type == 'MESH']
        
        # Eğer hiçbir şey seçili değilse
        if not selected_objects:
            has_colored = any(obj.color != (1.0, 1.0, 1.0, 1.0) for obj in all_mesh_objects)
            
            if has_colored:
                # Eğer en az biri renkliyse tüm renkleri sıfırla
                for obj in all_mesh_objects:
                    obj.color = (1.0, 1.0, 1.0, 1.0)
                
                textinfo_="All colors reset."
                bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
                return {'FINISHED'}
            else:
                # Eğer hiçbirinde renk yoksa hepsini renklendir
                selected_objects = all_mesh_objects
        
        # Seçili objelerin çocuklarını da ekle
        def get_children(obj):
            return [child for child in context.scene.objects if child.parent == obj]
        
        expanded_selection = set(selected_objects)
        for obj in selected_objects:
            expanded_selection.update(get_children(obj))
        
        # Viewport shading ayarlarını güncelle
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                space = area.spaces.active
                if space.shading.type != 'SOLID':
                    space.shading.type = 'SOLID'
                space.shading.light = 'STUDIO'
        
        context.space_data.shading.color_type = 'OBJECT'

        parent_groups = {}
        for obj in expanded_selection:
            if obj.type == 'MESH':
                parent = obj.parent if obj.parent else obj
                if parent not in parent_groups:
                    parent_groups[parent] = []
                parent_groups[parent].append(obj)

        total_colored = 0
        for group in parent_groups.values():
            random_color = (random.random(), random.random(), random.random(), 1.0)
            for obj in group:
                obj.color = random_color
                total_colored += 1
        
        
        textinfo_=f"Colored {total_colored} objects."
        bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
        return {'FINISHED'}

# Operatörü kaydetme
def register():
    bpy.utils.register_class(OBJECT_OT_ColorizeBySiblings)

def unregister():
    bpy.utils.unregister_class(OBJECT_OT_ColorizeBySiblings)

if __name__ == "__main__":
    register()
    bpy.ops.object.colorize_by_siblings()
