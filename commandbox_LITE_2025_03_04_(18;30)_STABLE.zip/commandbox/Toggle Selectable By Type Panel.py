# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#Toggles a panel in Blender's "Command Box" tab to toggle the selectability of objects by their type (e.g., MESH, LIGHT, CAMERA) using checkboxes.
    
import bpy

class OBJECT_PT_toggle_selectable_by_type_panel(bpy.types.Operator):
    bl_idname = "wm.toggle_selectable_by_type_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.toggle_selectable_by_type_panel_visible = not context.window_manager.toggle_selectable_by_type_panel_visible

        if(context.window_manager.toggle_selectable_by_type_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}


class OBJECT_PT_ToggleSelectablePanel(bpy.types.Panel):
    """Panel for toggling selectable properties of objects"""
    bl_label = "Toggle Selectable by Object Type Panel"
    bl_idname = "OBJECT_PT_ToggleSelectablePanel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "toggle_selectable_by_type_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_selectable_by_type_panel", text="", icon='CANCEL', emboss=False)
        
    def draw(self, context):
        layout = self.layout
        layout.label(text="Toggle Selectable by Object Type:")
        
        # Object türlerini tanımla ve alfabetik olarak sırala
        object_types = ['ARMATURE', 'CAMERA', 'CURVE', 'EMPTY', 'GREASEPENCIL', 'LATTICE', 'LIGHT', 
                    'LIGHT_PROBE', 'MESH', 'META', 'SPEAKER', 'SURFACE', 'TEXT', 'VOLUME']
        
        # Her bir satırda kaç öğe olacağını belirle
        items_per_row = 3
        
        # Her bir property için gerekirse property'leri oluştur
        for obj_type in object_types:
            property_name = f"toggle_selectable_{obj_type.lower()}"
            if not hasattr(context.scene, property_name):
                setattr(context.scene, property_name, bpy.props.BoolProperty(
                    name=f"Toggle {obj_type}",
                    description=f"Toggle selectable for {obj_type} objects",
                    default=True
                ))
        
        # Yan yana görünüm için grid/row sistemi kullan
        row_index = 0
        while row_index < len(object_types):
            row = layout.row()
            for i in range(items_per_row):
                if row_index + i < len(object_types):
                    obj_type = object_types[row_index + i]
                    property_name = f"toggle_selectable_{obj_type.lower()}"
                    row.prop(context.scene, property_name, text=obj_type)
            row_index += items_per_row
        
        layout.operator("object.toggle_selectable_by_type", text="Apply All")



class OBJECT_OT_ToggleSelectableByType(bpy.types.Operator):
    """Toggle selectable property for objects by type"""
    bl_idname = "object.toggle_selectable_by_type"
    bl_label = "Toggle Selectable by Type"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        for obj in bpy.data.objects:
            obj_type = obj.type.lower()
            toggle_property = f"toggle_selectable_{obj_type}"
            if hasattr(context.scene, toggle_property):
                toggle_value = getattr(context.scene, toggle_property)
                obj.hide_select = not toggle_value
        
        return {'FINISHED'}



def register():
    
    bpy.utils.register_class(OBJECT_PT_ToggleSelectablePanel)
    bpy.utils.register_class(OBJECT_PT_toggle_selectable_by_type_panel)

    bpy.types.WindowManager.toggle_selectable_by_type_panel_visible = bpy.props.BoolProperty(default=False)
    
    object_types = ['MESH', 'LIGHT', 'CAMERA', 'CURVE', 'EMPTY', 'ARMATURE', 'LATTICE', 'TEXT','GREASEPENCIL', 'SURFACE', 'META', 'SPEAKER', 'LIGHT_PROBE', 'VOLUME']
    for obj_type in object_types:
        property_name = f"toggle_selectable_{obj_type.lower()}"
        if not hasattr(bpy.types.Scene, property_name):
            
            setattr(bpy.types.Scene, property_name, bpy.props.BoolProperty(
                name=f"Toggle {obj_type}",
                description=f"Toggle selectable for {obj_type} objects",
                default=True
            ))



def unregister():

    del bpy.types.WindowManager.toggle_selectable_by_type_panel_visible

    bpy.utils.unregister_class(OBJECT_PT_toggle_selectable_by_type_panel)
    bpy.utils.unregister_class(OBJECT_PT_ToggleSelectablePanel)
    bpy.utils.unregister_class(OBJECT_OT_ToggleSelectableByType)

    
    object_types = ['MESH', 'LIGHT', 'CAMERA', 'CURVE', 'EMPTY', 'ARMATURE', 'LATTICE', 'TEXT', 'GREASEPENCIL','SURFACE', 'META', 'SPEAKER', 'LIGHT_PROBE', 'VOLUME']
    for obj_type in object_types:
        property_name = f"toggle_selectable_{obj_type.lower()}"
        if hasattr(bpy.types.Scene, property_name):
            delattr(bpy.types.Scene, property_name)


if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_selectable_by_type_panel()

# def toggle():
    
#     if hasattr(bpy.types, "OBJECT_PT_ToggleSelectablePanel"):
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='exist. now removing', duration=5)
#         #unregister() throws mRNA error ? couldnt resolve so commented  
#         bpy.utils.unregister_class(bpy.types.OBJECT_PT_ToggleSelectablePanel)
    
#     else:
#         bpy.ops.view3d.modal_draw_operator("INVOKE_DEFAULT", text='not exist.now registering', duration=5)
#         register()

# # İlk çalıştırma (register yapılacak)
# if __name__ == "__main__":
#     toggle()
