#https://www.youtube.com/watch?v=dh7hnsGiICs
#Vertex Spring Generator Panel.
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
bl_info = {
    "name": "Vertex Spring Generator",
    "author": "Claude",
    "version": (1, 1),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > Springs",
    "description": "Creates a spring mesh between two selected vertices with cloth physics and skin modifier",
    "warning": "",
    "doc_url": "",
    "category": "Mesh",
}

import bpy
import bmesh
import math
from mathutils import Vector

class HowToCollapsiblePanel(bpy.types.PropertyGroup):
    show_help: bpy.props.BoolProperty(
        name="Show Help",
        description="Expand to see usage instructions",
        default=False
    )

class SpringProperties(bpy.types.PropertyGroup):
    show_help: bpy.props.BoolProperty(
        name="Show Help",
        description="Expand to see usage instructions",
        default=False
    )

class SpringProperties(bpy.types.PropertyGroup):
    subdivisions: bpy.props.IntProperty(
        name="Subdivisions",
        description="Number of segments in the spring",
        default=10,
        min=1,
        max=100
    )
    spring_radius: bpy.props.FloatProperty(
        name="Spring Radius",
        description="Radius of the spring",
        default=0.05,
        min=0.001,
        max=10.0
    )
    spring_loops: bpy.props.IntProperty(
        name="Spring Loops",
        description="Number of loops in the spring",
        default=5,
        min=1,
        max=50
    )
    skin_thickness: bpy.props.FloatProperty(
        name="Skin Thickness",
        description="Thickness of the skin modifier",
        default=0.01,
        min=0.001,
        max=1.0
    )
    use_skin: bpy.props.BoolProperty(
        name="Use Skin Modifier",
        description="Add a skin modifier to give thickness to the spring",
        default=True
    )
    tension: bpy.props.FloatProperty(
        name="Tension",
        description="Tension of the cloth physics",
        default=15.0,
        min=0.0,
        max=50.0
    )
    mass: bpy.props.FloatProperty(
        name="Mass",
        description="Mass of the cloth vertices",
        default=0.3,
        min=0.01,
        max=10.0
    )

    # New properties for subdivision
    use_subdivision: bpy.props.BoolProperty(
        name="Use Subdivision",
        description="Apply Subdivision Surface modifier to smooth the spring",
        default=False
    )
    subdivision_levels: bpy.props.IntProperty(
        name="Subdivision Levels",
        description="Number of subdivision levels",
        default=2,
        min=0,
        max=5
    )

class MESH_OT_create_vertex_spring(bpy.types.Operator):
    """Create a spring between two selected vertices with cloth physics"""
    bl_idname = "mesh.create_vertex_spring"
    bl_label = "Create Vertex Spring"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH' or obj.mode != 'EDIT':
            return False
            
        # Check if exactly 2 vertices are selected
        if obj.type == 'MESH':
            bm = bmesh.from_edit_mesh(obj.data)
            selected_verts = [v for v in bm.verts if v.select]
            return len(selected_verts) == 2
            
        return False
    
    def execute(self, context):
        
        bpy.ops.screen.animation_cancel()  # Animasyonu durdur
        bpy.context.scene.frame_set(bpy.context.scene.frame_start)

        props = context.scene.spring_properties
        
        # Get active object and its data
        obj = context.active_object
        me = obj.data
        
        # Get selected vertices
        bm = bmesh.from_edit_mesh(me)
        selected_verts = [v for v in bm.verts if v.select]
        
        if len(selected_verts) != 2:
            self.report({'ERROR'}, "Please select exactly two vertices as start end points")
            return {'CANCELLED'}
        
        # Get vertex positions in world space
        v1_pos = obj.matrix_world @ selected_verts[0].co
        v2_pos = obj.matrix_world @ selected_verts[1].co
        
        # Switch to object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Create spring mesh
        spring_mesh = self.create_spring_mesh(
            v1_pos, 
            v2_pos, 
            props.subdivisions, 
            props.spring_radius, 
            props.spring_loops
        )
        
        # Create spring object
        spring_obj = bpy.data.objects.new("VertexSpring", spring_mesh)
        context.collection.objects.link(spring_obj)
        
        # Create vertex group for endpoints
        endpoint_group = spring_obj.vertex_groups.new(name="Endpoints")
        
        # Get indices of first and last vertices
        first_index = 0
        last_index = len(spring_mesh.vertices) - 1
        
        # Add vertices to group with weight 1.0
        endpoint_group.add([first_index], 1.0, 'ADD')
        endpoint_group.add([last_index], 1.0, 'ADD')
        
        # Make spring object active
        bpy.context.view_layer.objects.active = spring_obj
        
        # Add skin modifier if enabled
        if props.use_skin:
            bpy.ops.object.modifier_add(type='SKIN')
            skin_mod = spring_obj.modifiers["Skin"]
            
            # Set skin thickness by entering edit mode and using the skin_set_radius operator
            bpy.ops.object.mode_set(mode='EDIT')
            
            # Select all vertices
            bpy.ops.mesh.select_all(action='SELECT')
            
            # Set skin radius for all selected vertices
            bpy.ops.transform.skin_resize(
                value=(props.skin_thickness, props.skin_thickness, props.skin_thickness),
                orient_type='GLOBAL',
                orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
                orient_matrix_type='GLOBAL',
                constraint_axis=(False, False, False),
                mirror=True,
                use_proportional_edit=False,
                proportional_edit_falloff='SMOOTH',
                proportional_size=1
            )
            
            # Return to object mode
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Add cloth physics
        bpy.ops.object.modifier_add(type='CLOTH')
        cloth_modifier = spring_obj.modifiers["Cloth"]
        
        # Set cloth settings
        cloth_settings = cloth_modifier.settings
        cloth_settings.quality = 5
        cloth_settings.mass = props.mass
        cloth_settings.tension_stiffness = props.tension
        cloth_settings.compression_stiffness = props.tension
        cloth_settings.tension_damping = 5.0
        cloth_settings.compression_damping = 5.0
        
        # Set shape vertex group to endpoints
        cloth_settings.vertex_group_mass = "Endpoints"
        
        # Set modifier order if skin modifier is used
        if props.use_skin:
            # Move cloth modifier before skin modifier
            for i in range(len(spring_obj.modifiers)):
                if spring_obj.modifiers[i].type == 'CLOTH':
                    bpy.ops.object.modifier_move_up(modifier=cloth_modifier.name)
        
         # Add subdivision surface modifier if enabled
        if props.use_subdivision:
            bpy.ops.object.modifier_add(type='SUBSURF')
            subsurf_mod = spring_obj.modifiers["Subdivision"]
            subsurf_mod.levels = props.subdivision_levels
            subsurf_mod.render_levels = props.subdivision_levels
            
            # Ensure smooth modifier is after cloth and skin modifiers
            while subsurf_mod != spring_obj.modifiers[-1]:
                bpy.ops.object.modifier_move_down(modifier=subsurf_mod.name)


        # Select the spring object
        bpy.ops.object.select_all(action='DESELECT')
        spring_obj.select_set(True)
        context.view_layer.objects.active = spring_obj
        
        return {'FINISHED'}
    
    def create_spring_mesh(self, start_pos, end_pos, subdivisions, radius, loops):
        # Create a new mesh
        mesh = bpy.data.meshes.new("SpringMesh")
        
        # Calculate direction and length
        direction = end_pos - start_pos
        length = direction.length
        
        # Create vertices of the spring path
        vertices = []
        
        # Add vertices along the path
        for i in range(subdivisions + 1):
            t = i / subdivisions
            
            # Calculate position along the line
            pos = start_pos + t * direction
            
            # Add some spiral effect (except at the endpoints)
            if i > 0 and i < subdivisions:
                # Calculate spiral offset
                angle = t * 2 * math.pi * loops
                
                # Create a local coordinate system
                forward = direction.normalized()
                
                # Find an arbitrary perpendicular vector
                if abs(forward.x) < abs(forward.y) and abs(forward.x) < abs(forward.z):
                    perp = Vector((1, 0, 0))
                else:
                    perp = Vector((0, 1, 0))
                    
                right = forward.cross(perp).normalized()
                up = forward.cross(right).normalized()
                
                # Calculate spiral point
                spiral_x = math.cos(angle) * radius
                spiral_y = math.sin(angle) * radius
                
                # Add the offset to the position
                pos = pos + right * spiral_x + up * spiral_y
            
            vertices.append(pos)
        
        # Create edges connecting the vertices
        edges = [(i, i+1) for i in range(len(vertices)-1)]
        
        # Create the mesh from vertices and edges
        mesh.from_pydata(vertices, edges, [])
        mesh.update()
        
        return mesh


class OBJECT_PT_toggle_VertexSpringGeneratorPanel(bpy.types.Operator):
    bl_idname = "wm.toggle_vertex_spring_generator_panel"
    bl_label = "Toggle Omni Scatter Panel"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        context.window_manager.vertex_spring_generator_panel_visible = not context.window_manager.vertex_spring_generator_panel_visible

        if(context.window_manager.vertex_spring_generator_panel_visible):
            bpy.ops.view3d.toggle_n_panel_command_box()

        return {'FINISHED'}
    
class VIEW3D_PT_vertex_spring_panel(bpy.types.Panel):
    bl_label = "Vertex Spring Generator"
    bl_idname = "VIEW3D_PT_vertex_spring"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Command Box"

    @classmethod
    def poll(cls, context):
        return getattr(context.window_manager, "vertex_spring_generator_panel_visible", True)
    
    def draw_header_preset(self, context):
        layout = self.layout
        layout.operator("wm.toggle_vertex_spring_generator_panel", text="", icon='CANCEL', emboss=False)

    
    def draw(self, context):
        layout = self.layout
        props = context.scene.spring_properties
        howto_props = context.scene.howto_collapsible_panel
        
        layout.label(text="Select exactly two vertices as start and end points")
        layout.prop(props, "subdivisions")
        layout.prop(props, "spring_radius")
        layout.prop(props, "spring_loops")
        
        layout.separator()
        layout.prop(props, "use_skin")
        if props.use_skin:
            layout.prop(props, "skin_thickness")
        
        layout.separator()
        layout.label(text="Physics Properties:")
        layout.prop(props, "tension")
        layout.prop(props, "mass")
        
        layout.separator()       
        layout.prop(props, "use_subdivision")
        if props.use_subdivision:
            layout.prop(props, "subdivision_levels")

        layout.separator()
        col = layout.column()
        col.operator("mesh.create_vertex_spring")
        
        layout.separator()


        # Açılır/Kapanır Yardım Paneli (Sağ & Aşağı Ok ile)
        row = layout.row()
        icon = "TRIA_DOWN" if howto_props.show_help else "TRIA_RIGHT"
        row.prop(howto_props, "show_help", text="How to Use", icon=icon, toggle=True)
        
        if howto_props.show_help:  # Eğer açık ise, içeriği göster
            box = layout.box()
            col = box.column(align=True)  # Etiketler arası boşluğu azaltır
            
            # Sıkılaştırılmış Liste (Daha Az Boşluk)
            for text in [
                " 1. Select two vertices in Edit Mode",
                " 2. Set parameters",
                " 3. Click 'Create Vertex Spring'",
                " 4. Play Animation In Timeline.",
                "✌️. The spring will follow the vertices"
            ]:
                row = col.row(align=True)
                row.label(text=text)


classes = (
    HowToCollapsiblePanel,
    SpringProperties,
    OBJECT_PT_toggle_VertexSpringGeneratorPanel,
    MESH_OT_create_vertex_spring,
    VIEW3D_PT_vertex_spring_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    #bpy.utils.register_class(HowToCollapsiblePanel)
    bpy.types.WindowManager.vertex_spring_generator_panel_visible = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.spring_properties = bpy.props.PointerProperty(type=SpringProperties)
    bpy.types.Scene.howto_collapsible_panel = bpy.props.PointerProperty(type=HowToCollapsiblePanel)
def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.spring_properties
    del bpy.types.WindowManager.vertex_spring_generator_panel_visible

if __name__ == "__main__":
    register()
    bpy.ops.wm.toggle_vertex_spring_generator_panel()