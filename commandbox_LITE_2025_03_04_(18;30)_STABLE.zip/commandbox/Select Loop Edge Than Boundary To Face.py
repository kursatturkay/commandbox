# 1st line for youtube url link like https://youtube.com/playlist?list=PLNizloUxMUXLHNHn2-0Wmdf2YtygXcmop 
#① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨ ⑩ 2nd line as description for Select Loop Edge Than Boundary To Face.

import bpy

bpy.ops.object.mode_set(mode='OBJECT')

obj = bpy.context.active_object
if obj.type != 'MESH':
    raise Exception("Active object is not a mesh")

bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_mode(type='EDGE')
bpy.ops.mesh.loop_multi_select(ring=False)
bpy.ops.mesh.loop_to_region()
bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')