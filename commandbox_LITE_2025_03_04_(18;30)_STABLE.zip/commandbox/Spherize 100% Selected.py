#https://www.youtube.com/watch?v=H2cAPNsjJAM
#Spherize Edge Loop..
#autorun=False
#|▮∎ ∥ ⫴① ② ③ ④ ⑤ ⑥ ⑦ ⑧ ⑨
#bpy.ops.view3d.modal_draw_operator('INVOKE_DEFAULT', text=textinfo_, duration=5)
import bpy
import bmesh
import math
from mathutils import Vector
from bpy.props import FloatProperty

class SpherizeEdgeLoopOperator(bpy.types.Operator):
    bl_idname = "mesh.spherize_edge_loop"
    bl_label = "Spherize Edge Loop"
    bl_options = {'REGISTER', 'UNDO'}
    
    factor: FloatProperty(
        name="Factor",
        description="Spherize factor",
        default=1.0,
        min=0.0,
        max=2.0,
    )
    
    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            return {'CANCELLED'}
        
        # Edit mode'da BMesh oluştur
        bm = bmesh.from_edit_mesh(obj.data)
        
        # Seçili edge'leri al
        selected_edges = [e for e in bm.edges if e.select]
        if not selected_edges:
            return {'CANCELLED'}
            
        # Edge loop'daki vertexleri topla
        verts = []
        for edge in selected_edges:
            for vert in edge.verts:
                if vert not in verts:
                    verts.append(vert)
        
        # Merkez noktayı hesapla
        center = Vector((0, 0, 0))
        for v in verts:
            center += v.co
        center /= len(verts)
        
        # Ortalama yarıçap hesapla
        radius = 0
        for v in verts:
            radius += (v.co - center).length
        radius /= len(verts)
        
        # Vertexleri spherize et
        for v in verts:
            direction = (v.co - center).normalized()
            original_pos = v.co.copy()
            spherized_pos = center + (direction * radius)
            # Factor ile interpolate
            v.co = original_pos.lerp(spherized_pos, self.factor)
        
        # Mesh'i güncelle
        bmesh.update_edit_mesh(obj.data)
        return {'FINISHED'}

class SpherizeEdgeLoopPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_spherize_edge_loop"
    bl_label = "Spherize Edge Loop"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'
    
    def draw(self, context):
        layout = self.layout
        layout.operator("mesh.spherize_edge_loop")

def register():
    bpy.utils.register_class(SpherizeEdgeLoopOperator)
    bpy.utils.register_class(SpherizeEdgeLoopPanel)

def unregister():
    bpy.utils.unregister_class(SpherizeEdgeLoopOperator)
    bpy.utils.unregister_class(SpherizeEdgeLoopPanel)

if __name__ == "__main__":
    register()
    bpy.ops.mesh.spherize_edge_loop('INVOKE_DEFAULT')