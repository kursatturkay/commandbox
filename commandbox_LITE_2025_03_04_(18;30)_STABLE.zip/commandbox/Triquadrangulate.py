# Applies Triangulate Than Quadrangulate Operations in Object Mode. without going Edit Mode
import bpy

def tri_quad_converter():
    for obj in bpy.context.selected_objects:
        if obj.type == 'MESH':
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.quads_convert_to_tris()
            bpy.ops.mesh.tris_convert_to_quads(face_threshold=3.14159,shape_threshold=3.14159)
            bpy.ops.object.mode_set(mode='OBJECT')

tri_quad_converter()


#bpy.ops.mesh.tris_convert_to_quads(face_threshold=3.14159, shape_threshold=3.14159)
